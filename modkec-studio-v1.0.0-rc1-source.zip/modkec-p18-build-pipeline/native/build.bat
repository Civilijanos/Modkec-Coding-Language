@echo off
setlocal
cd /d "%~dp0.."
if not exist bin mkdir bin
where cl >nul 2>nul
if errorlevel 1 (
  echo Microsoft C compiler ^(cl^) was not found.
  echo Install Visual Studio Build Tools with the Desktop development with C++ workload.
  exit /b 1
)
cl /nologo /std:c11 /O2 /W4 /WX native\modkec_native.c /Fe:bin\modkec-native.exe
if errorlevel 1 exit /b %errorlevel%
del modkec_native.obj 2>nul
endlocal
