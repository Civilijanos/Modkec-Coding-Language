#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p bin
cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic native/modkec_native.c -o bin/modkec-native
printf 'Built %s\n' "$PWD/bin/modkec-native"
