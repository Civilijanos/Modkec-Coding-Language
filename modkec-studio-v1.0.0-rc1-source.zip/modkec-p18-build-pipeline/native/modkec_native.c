/*
 * Modkec native runtime kernel — P14, chunk 1.
 * This is a standalone C implementation of a deliberately small, documented
 * core-language subset. It does not invoke Python. Unsupported syntax fails
 * explicitly rather than being silently ignored.
 */
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#define MK_MKDIR(path) _mkdir(path)
#else
#include <dirent.h>
#define MK_MKDIR(path) mkdir(path, 0777)
#endif

#define MAX_LINE 8192
#define MAX_VARS 1024
#define MAX_NAME 128
#define MAX_VALUE 4096

typedef struct { char name[MAX_NAME]; char value[MAX_VALUE]; int used; } Variable;
static Variable vars[MAX_VARS];
static int stopped = 0;
static char source_path[4096];
static int decode_value(char *raw, char *out, size_t cap);

static int decode_arg(char *raw, char *out, size_t cap) {
    return decode_value(raw, out, cap);
}

static int write_persistent(const char *key, const char *value) {
    char path[4096], temp[4096];
    const char *slash1 = strrchr(source_path, '/');
    const char *slash2 = strrchr(source_path, '\\');
    const char *slash = slash1;
    if (!slash || (slash2 && slash2 > slash)) slash = slash2;
    size_t dirlen = slash ? (size_t)(slash-source_path+1) : 0;
    if (dirlen + sizeof(".modkec_store.json") >= sizeof(path)) return 0;
    memcpy(path, source_path, dirlen); path[dirlen]='\0';
    strcat(path, ".modkec_store.json");
    snprintf(temp, sizeof(temp), "%s.tmp", path);
    FILE *f = fopen(temp, "wb"); if (!f) return 0;
    /* Keep existing flat JSON entries when rewriting a key. */
    FILE *old = fopen(path, "rb");
    int first = 1; fprintf(f, "{\n");
    if (old) {
        char buf[16384]; size_t n = fread(buf,1,sizeof(buf)-1,old); buf[n]='\0'; fclose(old);
        char *p=buf;
        while ((p=strchr(p,'"')) != NULL) {
            char *ks=p+1, *ke=strchr(ks,'"'); if (!ke) break;
            char k[MAX_NAME]; size_t kl=(size_t)(ke-ks); if (kl>=sizeof(k)) { p=ke+1; continue; }
            memcpy(k,ks,kl); k[kl]='\0'; p=ke+1;
            while (*p && (*p==':' || isspace((unsigned char)*p))) p++;
            char *vs=p, *ve=NULL;
            if (*p=='"') { p++; while (*p && *p!='"') { if (*p=='\\' && p[1]) p++; p++; } if (*p=='"') { p++; ve=p; } }
            else { while (*p && *p!=',' && *p!='}' && !isspace((unsigned char)*p)) p++; ve=p; }
            if (!ve || !strcmp(k,key)) continue;
            if (!first) fprintf(f, ",\n");
            first=0;
            fprintf(f,"  \"%s\": ",k); fwrite(vs,1,(size_t)(ve-vs),f);
        }
    }
    if (!first) fprintf(f, ",\n");
    fprintf(f,"  \"%s\": ",key);
    char *end=NULL; errno=0; (void)strtod(value,&end);
    if (value[0] && end && *end=='\0' && end!=value && errno!=ERANGE) fprintf(f,"%s",value);
    else {
        fputc('"',f);
        for (const unsigned char *p=(const unsigned char*)value; *p; p++) {
            if (*p=='"' || *p=='\\') { fputc('\\',f); fputc(*p,f); }
            else if (*p=='\n') fputs("\\n",f); else if (*p=='\r') fputs("\\r",f); else if (*p=='\t') fputs("\\t",f); else fputc(*p,f);
        }
        fputc('"',f);
    }
    fprintf(f,"\n}\n");
    if (fclose(f)!=0) { remove(temp); return 0; }
    if (rename(temp,path)!=0) { remove(temp); return 0; }
    return 1;
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    size_t n = strlen(s);
    while (n && isspace((unsigned char)s[n-1])) s[--n] = '\0';
    return s;
}
static int valid_name(const char *s) {
    if (!s || !(isalpha((unsigned char)*s) || *s == '_')) return 0;
    for (s++; *s; s++) if (!(isalnum((unsigned char)*s) || *s == '_')) return 0;
    return 1;
}
static Variable *find_var(const char *name, int create) {
    int free_slot = -1;
    for (int i=0; i<MAX_VARS; i++) {
        if (vars[i].used && strcmp(vars[i].name, name)==0) return &vars[i];
        if (!vars[i].used && free_slot < 0) free_slot = i;
    }
    if (!create || free_slot < 0) return NULL;
    Variable *v = &vars[free_slot];
    memset(v, 0, sizeof(*v)); v->used = 1;
    snprintf(v->name, sizeof(v->name), "%s", name);
    return v;
}
static int split_call(char *line, char *name, size_t name_cap, char *args, size_t args_cap) {
    char *open = strchr(line, '('), *close = strrchr(line, ')');
    if (!open || !close || close < open || trim(close+1)[0] != '\0') return 0;
    *open = '\0'; char *n = trim(line); if (!valid_name(n)) return 0;
    size_t nl = strlen(n), al = (size_t)(close-open-1);
    if (nl >= name_cap || al >= args_cap) return 0;
    memcpy(name, n, nl+1); memcpy(args, open+1, al); args[al]='\0'; return 1;
}
static int split_two(char *args, char *a, size_t ac, char *b, size_t bc) {
    int quoted = 0, escaped = 0;
    for (char *p=args; *p; p++) {
        if (quoted) { if (escaped) escaped=0; else if (*p=='\\') escaped=1; else if (*p=='"') quoted=0; }
        else if (*p=='"') quoted=1;
        else if (*p==',') {
            *p='\0'; char *left=trim(args), *right=trim(p+1);
            if (strlen(left)>=ac || strlen(right)>=bc) return 0;
            strcpy(a,left); strcpy(b,right); return 1;
        }
    }
    return 0;
}
static int decode_value(char *raw, char *out, size_t cap) {
    raw=trim(raw); size_t n=strlen(raw);
    if (n>=2 && raw[0]=='"' && raw[n-1]=='"') {
        raw[n-1]='\0'; raw++;
        size_t j=0;
        for (size_t i=0; raw[i]; i++) {
            if (j+1 >= cap) return 0;
            if (raw[i]=='\\' && raw[i+1]) { i++; out[j++] = raw[i]=='n' ? '\n' : raw[i]=='t' ? '\t' : raw[i]; }
            else out[j++]=raw[i];
        }
        out[j]='\0'; return 1;
    }
    if (!strcmp(raw,"t")) { snprintf(out,cap,"true"); return 1; }
    if (!strcmp(raw,"f")) { snprintf(out,cap,"false"); return 1; }
    char *end=NULL; errno=0; double parsed=strtod(raw,&end);
    if (raw[0] && end && *trim(end)=='\0' && end!=raw && errno!=ERANGE && isfinite(parsed)) {
        snprintf(out,cap,"%s",raw); return 1;
    }
    if (valid_name(raw)) { Variable *v=find_var(raw,0); if (!v) return 0; snprintf(out,cap,"%s",v->value); return 1; }
    return 0;
}

static int read_persistent(const char *key, char *out, size_t cap) {
    char path[4096];
    const char *s1=strrchr(source_path,'/'), *s2=strrchr(source_path,'\\'), *slash=s1;
    if (!slash || (s2 && s2>slash)) slash=s2;
    size_t d=slash ? (size_t)(slash-source_path+1) : 0;
    if (d+sizeof(".modkec_store.json")>=sizeof(path)) return 0;
    memcpy(path,source_path,d); path[d]='\0'; strcat(path,".modkec_store.json");
    FILE *f=fopen(path,"rb"); if (!f) return 0;
    char buf[16384]; size_t n=fread(buf,1,sizeof(buf)-1,f); fclose(f); buf[n]='\0';
    char *p=buf;
    while ((p=strchr(p,'"'))!=NULL) {
        char *ks=p+1, *ke=strchr(ks,'"'); if (!ke) break;
        char k[MAX_NAME]; size_t kl=(size_t)(ke-ks); if (kl>=sizeof(k)) { p=ke+1; continue; }
        memcpy(k,ks,kl); k[kl]='\0'; p=ke+1;
        while (*p && (*p==':' || isspace((unsigned char)*p))) p++;
        char raw[MAX_VALUE]; size_t j=0;
        if (*p=='"') {
            p++;
            while (*p && *p!='"' && j+2<sizeof(raw)) { if (*p=='\\' && p[1]) { p++; raw[j++]=*p=='n'?'\n':*p=='t'?'\t':*p; p++; } else raw[j++]=*p++; }
            if (*p=='"') p++;
            raw[j]='\0';
        } else {
            while (*p && *p!=',' && *p!='}' && !isspace((unsigned char)*p) && j+1<sizeof(raw)) raw[j++]=*p++;
            raw[j]='\0';
        }
        if (!strcmp(k,key)) { if (strlen(raw)>=cap) return 0; strcpy(out,raw); return 1; }
    }
    return 0;
}

/* File commands use explicit quoted paths and UTF-8 text files. */
static int run_file_command(const char *name, char *args, unsigned long lineno,
                            char *result, size_t result_cap, int capture) {
    char a[MAX_VALUE], b[MAX_VALUE], raw_a[MAX_VALUE], raw_b[MAX_VALUE];
    if (!strcmp(name,"read_file") || !strcmp(name,"file_exists") || !strcmp(name,"create_folder")) {
        if (!decode_arg(args,a,sizeof(a))) goto bad_args;
        if (!strcmp(name,"read_file")) {
            FILE *f=fopen(a,"rb"); if (!f) { fprintf(stderr,"Line %lu: cannot read file '%s': %s\n",lineno,a,strerror(errno)); return 0; }
            if (capture) {
                size_t n=fread(result,1,result_cap-1,f);
                if (ferror(f)) { fclose(f); return 0; }
                if (!feof(f)) { fclose(f); fprintf(stderr,"Line %lu: file is too large to capture into a Modkec value\n",lineno); return 0; }
                result[n]='\0'; fclose(f); return 1;
            }
            char buf[4096]; size_t n; while ((n=fread(buf,1,sizeof(buf),f))>0) if (fwrite(buf,1,n,stdout)!=n) { fclose(f); return 0; }
            if (ferror(f)) { fclose(f); return 0; } fclose(f); putchar('\n'); return 1;
        }
        if (!strcmp(name,"file_exists")) { struct stat st; int exists=stat(a,&st)==0 && S_ISREG(st.st_mode); if (capture) snprintf(result,result_cap,"%s",exists?"true":"false"); else puts(exists?"true":"false"); return 1; }
        if (MK_MKDIR(a)!=0 && errno!=EEXIST) { fprintf(stderr,"Line %lu: cannot create folder '%s': %s\n",lineno,a,strerror(errno)); return 0; } return 1;
    }
    if (!split_two(args,raw_a,sizeof(raw_a),raw_b,sizeof(raw_b)) || !decode_arg(raw_a,a,sizeof(a)) || !decode_arg(raw_b,b,sizeof(b))) goto bad_args;
    if (!strcmp(name,"write_file")) {
        FILE *f=fopen(a,"wb"); if (!f) { fprintf(stderr,"Line %lu: cannot write file '%s': %s\n",lineno,a,strerror(errno)); return 0; }
        size_t n=strlen(b); int ok=fwrite(b,1,n,f)==n && fclose(f)==0;
        if (!ok) { fprintf(stderr,"Line %lu: failed writing '%s'\n",lineno,a); return 0; } return 1;
    }
    if (!strcmp(name,"copy_file")) {
        FILE *in=fopen(a,"rb"); if (!in) { fprintf(stderr,"Line %lu: cannot read '%s': %s\n",lineno,a,strerror(errno)); return 0; }
        FILE *out=fopen(b,"wb"); if (!out) { fclose(in); fprintf(stderr,"Line %lu: cannot write '%s': %s\n",lineno,b,strerror(errno)); return 0; }
        char buf[4096]; size_t n; int ok=1; while ((n=fread(buf,1,sizeof(buf),in))>0) if (fwrite(buf,1,n,out)!=n) { ok=0; break; }
        if (ferror(in)) ok=0;
        if (fclose(in)!=0) ok=0;
        if (fclose(out)!=0) ok=0;
        return ok;
    }
    if (!strcmp(name,"rename_file")) { if (rename(a,b)!=0) { fprintf(stderr,"Line %lu: cannot rename '%s' to '%s': %s\n",lineno,a,b,strerror(errno)); return 0; } return 1; }
    return 0;
bad_args:
    fprintf(stderr,"Line %lu: %s received invalid arguments\n",lineno,name); return 0;
}
static int run_line(char *line, unsigned long lineno) {
    line=trim(line); if (!*line || *line=='#') return 1;
    if (!strncmp(line,"import(",7)) {
        if (!strcmp(line,"import(core)") || !strcmp(line,"import(files)")) return 1;
        fprintf(stderr,"Line %lu: native kernel does not yet implement modules: %s\n",lineno,line); return 0;
    }
    /* `command(...) -> variable` captures a supported command's return value.
       This deliberately starts with scalar-producing commands; unsupported
       commands still fail rather than pretending to return a value. */
    char result_name[MAX_NAME] = "";
    char *arrow = strstr(line, "->");
    if (arrow) {
        *arrow = '\0';
        char *dest = trim(arrow + 2);
        if (!valid_name(dest) || strlen(dest) >= sizeof(result_name)) {
            fprintf(stderr,"Line %lu: result assignment expects a variable name after ->\n",lineno); return 0;
        }
        strcpy(result_name, dest);
        line = trim(line);
    }
    int capture = result_name[0] != '\0';
    char name[MAX_NAME], args[MAX_LINE];
    if (!split_call(line,name,sizeof(name),args,sizeof(args))) {
        fprintf(stderr,"Line %lu: unsupported syntax in native kernel\n",lineno); return 0;
    }
    if (capture && strcmp(name,"say") && strcmp(name,"get") &&
        strcmp(name,"read_file") && strcmp(name,"file_exists")) {
        fprintf(stderr,"Line %lu: command '%s' does not return a capturable value in the native kernel\n",lineno,name);
        return 0;
    }
    if (!strcmp(name,"stop")) { stopped=1; return 1; }
    if (!strcmp(name,"comment")) return 1;
    if (!strcmp(name,"say") || !strcmp(name,"get")) {
        char value[MAX_VALUE];
        if (!decode_value(args,value,sizeof(value))) {
            char *key=trim(args);
            if (strcmp(name,"get") || !valid_name(key) || !read_persistent(key,value,sizeof(value))) { fprintf(stderr,"Line %lu: unknown or unsupported value: %s\n",lineno,args); return 0; }
        }
        if (capture) {
            Variable *v=find_var(result_name,1); if (!v) { fprintf(stderr,"Variable table is full\n"); return 0; }
            snprintf(v->value,sizeof(v->value),"%s",value);
        } else puts(value);
        return 1;
    }
    if (!strcmp(name,"set")) {
        char rawname[MAX_NAME], rawvalue[MAX_VALUE], value[MAX_VALUE];
        if (!split_two(args,rawname,sizeof(rawname),rawvalue,sizeof(rawvalue)) || !valid_name(rawname) || !decode_value(rawvalue,value,sizeof(value))) {
            fprintf(stderr,"Line %lu: set expects set(valid_name, literal_or_existing_variable)\n",lineno); return 0;
        }
        Variable *v=find_var(rawname,1); if (!v) { fprintf(stderr,"Variable table is full\n"); return 0; }
        snprintf(v->value,sizeof(v->value),"%s",value); return 1;
    }
    if (!strcmp(name,"store")) {
        char key[MAX_NAME], raw[MAX_VALUE], value[MAX_VALUE];
        if (!split_two(args,key,sizeof(key),raw,sizeof(raw)) || !valid_name(key) || !decode_value(raw,value,sizeof(value))) { fprintf(stderr,"Line %lu: store expects store(valid_name, value)\n",lineno); return 0; }
        Variable *v=find_var(key,1); if (!v) { fprintf(stderr,"Variable table is full\n"); return 0; }
        snprintf(v->value,sizeof(v->value),"%s",value);
        if (!write_persistent(key,value)) { fprintf(stderr,"Line %lu: failed to save persistent data\n",lineno); return 0; } return 1;
    }
    if (!strcmp(name,"read_file") || !strcmp(name,"write_file") || !strcmp(name,"file_exists") || !strcmp(name,"copy_file") || !strcmp(name,"rename_file") || !strcmp(name,"create_folder")) {
        char value[MAX_VALUE] = "";
        if (!run_file_command(name,args,lineno,value,sizeof(value),capture)) return 0;
        if (capture) {
            Variable *v=find_var(result_name,1); if (!v) { fprintf(stderr,"Variable table is full\n"); return 0; }
            snprintf(v->value,sizeof(v->value),"%s",value);
        }
        return 1;
    }
    if (!strcmp(name,"delete")) {
        char *key=trim(args); if (!valid_name(key)) { fprintf(stderr,"Line %lu: delete expects a variable name\n",lineno); return 0; }
        Variable *v=find_var(key,0); if (v) memset(v,0,sizeof(*v)); return 1;
    }
    if (!strcmp(name,"increment") || !strcmp(name,"decrement")) {
        char *key=trim(args); if (!valid_name(key)) { fprintf(stderr,"Line %lu: %s expects a variable name\n",lineno,name); return 0; }
        Variable *v=find_var(key,0); if (!v) { fprintf(stderr,"Line %lu: unknown variable '%s'\n",lineno,key); return 0; }
        char *end=NULL; errno=0; double number=strtod(v->value,&end);
        if (errno || end==v->value || *end || !isfinite(number)) { fprintf(stderr,"Line %lu: variable '%s' is not numeric\n",lineno,key); return 0; }
        number += !strcmp(name,"increment") ? 1.0 : -1.0;
        /* Do not cast out-of-range doubles to integers: that conversion is undefined. */
        if (number >= (double)LLONG_MIN && number < 9223372036854775808.0 && number==(double)(long long)number)
            snprintf(v->value,sizeof(v->value),"%lld",(long long)number);
        else snprintf(v->value,sizeof(v->value),"%.15g",number);
        return 1;
    }
    fprintf(stderr,"Line %lu: command '%s' is not implemented by the native kernel yet\n",lineno,name); return 0;
}
int main(int argc, char **argv) {
    if (argc!=2) { fprintf(stderr,"Usage: %s program.modkec\n",argv[0]); return 2; }
    if (strlen(argv[1])>=sizeof(source_path)) { fprintf(stderr,"Source path is too long\n"); return 2; }
    strcpy(source_path,argv[1]);
    FILE *f=fopen(argv[1],"rb"); if (!f) { perror(argv[1]); return 2; }
    char line[MAX_LINE]; unsigned long lineno=0; int ok=1;
    while (!stopped && fgets(line,sizeof(line),f)) {
        lineno++;
        if (!strchr(line,'\n') && !feof(f)) { fprintf(stderr,"Line %lu: line exceeds native kernel limit\n",lineno); ok=0; break; }
        if (!run_line(line,lineno)) { ok=0; break; }
    }
    if (ferror(f)) { perror("Reading source"); ok=0; }
    fclose(f); return ok ? 0 : 1;
}
