@echo off
setlocal
cd /d "%~dp0.."
if "%~1"=="" (
  echo Usage: run_native.bat program.modkec
  exit /b 2
)
if not exist bin\modkec-native.exe (
  echo No prebuilt Windows native runtime is included in this preview.
  echo A Windows build must be produced before this launcher can run native Modkec.
  echo No compiler is needed to run a prebuilt executable, but this ZIP does not yet contain one.
  exit /b 127
)
bin\modkec-native.exe %*
exit /b %errorlevel%
