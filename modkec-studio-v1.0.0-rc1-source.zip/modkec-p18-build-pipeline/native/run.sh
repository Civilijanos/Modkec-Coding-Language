#!/bin/sh
# Run the bundled native Modkec kernel. No compiler is needed for normal use.
set -eu
cd "$(dirname "$0")/.."
PROGRAM=${1:-}
if [ -z "$PROGRAM" ]; then
  echo "Usage: ./run_native.sh program.modkec" >&2
  exit 2
fi
if [ ! -x ./bin/modkec-native ]; then
  echo "Bundled native runtime is missing for this platform." >&2
  echo "This package currently includes a prebuilt Linux x86-64 runtime." >&2
  echo "Building from source requires a C compiler; normal Linux use does not." >&2
  exit 127
fi
exec ./bin/modkec-native "$PROGRAM"
