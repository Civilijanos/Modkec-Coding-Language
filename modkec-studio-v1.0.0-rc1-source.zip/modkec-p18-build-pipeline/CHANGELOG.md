## v1.0.0-p17 — Standalone Python/Tkinter runtime builder

- Added a per-platform PyInstaller build pipeline that bundles Python, Tkinter, Tcl/Tk, and Modkec source assets into a standalone application directory.
- Added runtime self-checking and OS-specific build launchers for Linux, Windows, and macOS.
- Native Windows/macOS bundles must be built on their respective operating systems; this source package does not claim to contain prebuilt native binaries.


- Routed the standard Linux and Windows Studio launchers through `studio/entry.modkec`. The Modkec entry explicitly opts into the existing embedded-Python bridge to start the current desktop host, making Modkec the startup orchestrator while retaining Python for unported GUI behavior.
- Updated bootstrap validation and regression tests for the Modkec entry point. This is an incremental migration; the GUI, translator, and core application behavior remain Python-backed.
## v1.0.0-p14 — Modkec-first startup bridge
- Bundled a statically linked Linux x86-64 native runtime so running the supported kernel no longer requires installing a C compiler.
- Changed the native launcher to use the bundled executable instead of compiling at launch.
- Clarified that the Windows native executable and dependency-free full desktop Studio are not yet available.
- Removed generated Python and pytest caches from the release package.

## v1.0.0-p9 — Reusable source modules

- Added `include("path.modkec")` to load reusable action and custom-command definitions into the active runtime.
- Added relative path resolution, nested includes, duplicate-load protection, and circular-include detection.
- Restricted module top-level content to imports, includes, declarations, comments, and blank lines so including a library cannot silently execute arbitrary program statements.
- Added module loading diagnostics for missing files, invalid extensions, malformed definitions, and unsupported top-level code.
- Added source-module examples and regression tests.
- This expands the Modkec runtime but does not remove Python from the Studio host or runtime.

## v1.0.0-p8 — Source integration and migration hardening

- Added an integrated validation pass for the application settings, theme, command reference, menus, toolbar, workbench, starter program, and partnered-extension registry.
- Studio now checks that the complete set of source-backed definitions is present and valid before building the main interface.
- Updated the application version and progress indicator to p8 while preserving the existing interface and launcher behavior.
- Added integration tests for the complete definition set and failure handling when a required source file is missing or invalid.

This is not yet a fully self-hosted application. The desktop interface and language engine still rely on the existing host implementation; replacing those requires a separate runtime and UI rewrite.

## v1.0.0-p7 — Self-hosting prototype 7

- Added `studio/application.modkec` as the source of truth for the application title, window sizes, startup splash text, and displayed prototype version.
- Replaced the embedded Python starter-program string with `studio/starter.modkec`, loaded directly into the editor.
- Added strict validation for application settings, duplicate declarations, and safe window dimensions.
- Kept the existing UI layout, theme, and launcher behavior unchanged; updated the progress indicator to `7/8` for the expanded finalization plan.
- Added tests for application settings validation and execution of the Modkec starter program.

This is a real step toward source-level ownership, not a completed self-hosting conversion: the desktop UI host and runtime are still being migrated and are the focus of p8.

## v1.0.0-p6 — Self-hosting prototype 6

- Moved the default Studio color palette into `studio/theme.modkec`; the same 18 base colors are retained so the interface appearance remains stable.
- Added a restricted parser that accepts only known palette keys and six-digit hexadecimal colors, rejecting unknown keys, duplicates, malformed declarations, and incomplete palettes.
- Kept user profile background/button color overrides and contrast-color behavior intact.
- Updated the status bar and About dialog to `v1.0.0-p6`, and updated release documentation.
- Added tests for the theme definition and parser validation.

Tkinter still renders the interface and applies the palette. This part moves base theme configuration into editable Modkec source without changing the visual design.

## v1.0.0-p5 — Self-hosting prototype 5

- Moved the optional partnered-extension catalog and expected command names from a Python dictionary into `bundled_extensions/registry.modkec`.
- Added a restricted loader that validates declaration names, argument types/counts, extension IDs, local ZIP filenames, command identifiers, duplicate IDs, and empty registries.
- Added a package/catalog consistency check so a bundled extension is removed and rejected if its declared command list does not match the Modkec registry.
- Kept extension installation opt-in; catalog declarations cannot execute Python or install packages.
- Updated the status bar to `Self-hosting: 5/7` and updated release metadata.
- Added tests for catalog contents and invalid registry declarations.

The extension handlers still use the existing Python extension API. This stage moves catalog and registration metadata into Modkec source without changing command execution.

## v1.0.0-p4 — Self-hosting prototype 4

- Moved activity-rail button glyphs and labels into `studio/workbench.modkec`.
- Moved bottom-panel tab labels/identifiers and the Run action label/callback identifier into the same Modkec definition file.
- Added a restricted parser with validation for declaration types, argument counts, duplicate activity/tab identifiers, and required controls.
- Updated the status bar to `Self-hosting: 4/7` and added parser/definition tests.

The visible layout and actions are intended to remain unchanged. Tkinter still creates the widgets and Python still handles their callbacks; this stage moves more workbench declarations into Modkec source.

## v1.0.0-p3 — Self-hosting prototype 3

- Moved the in-app command reference and descriptions from a hardcoded Python dictionary into `studio/command_help.modkec`.
- Added a restricted parser for `studio_help(command, description)` declarations, including validation for malformed entries, duplicate commands, and empty definitions.
- Updated the status bar to `Self-hosting: 3/7`.
- Added tests for reference content and invalid declaration handling.

The help panel is still rendered by Tkinter; this stage moves the reference data into Modkec source without changing command execution.

## v1.0.0-p2 — Self-hosting prototype 2

- Moved the top command toolbar's buttons, target selector, and target label into `studio/toolbar.modkec`.
- Added a constrained parser and explicit callback allowlist for toolbar declarations; source declarations cannot invoke arbitrary Python.
- Added a visible `Self-hosting: 2/7` status-bar indicator so the prototype stage is clear in the running app.
- Added tests for toolbar declarations and rejection of unknown operations, invalid argument types, and wrong argument counts.

The Tkinter widgets and underlying Studio actions still run in Python; this stage moves the toolbar's layout declaration into Modkec, not its rendering engine.

## v1.0.0-p1 — Self-hosting prototype 1

- Moved the Studio's top-level menu structure and menu item declarations into `studio/menus.modkec`.
- Added a constrained declarative loader that validates declarations and maps them to an explicit allowlist of existing Studio callbacks.
- Kept the Tkinter renderer and event bindings in Python for this first migration stage.
- Added tests for menu parsing, invalid declarations, argument types, and argument counts.

This prototype begins the migration toward a Modkec-defined Studio. It does not yet make the interpreter, full interface, or extension runtime self-hosted.

## v0.9.9 development update
- Added a prominent safety warning when editing source-code files inside the Modkec Studio project.
- Disabled Auto Save for those project source files and guarded the autosave callback so already-scheduled autosaves cannot overwrite them.
- Kept manual Save, Save As, and Save All available; ordinary source files outside the Modkec Studio project retain normal autosave behavior.
- Added GUI tests for warning visibility, autosave protection, and normal behavior for external files.

## v0.9.8 development update
- Added an in-app startup screen that runs quick diagnostics in a background thread before showing the editor.
- Startup checks cover essential files, interpreter arithmetic/output, controlled error handling, all configured translation targets, Visele drawing, and extension loading.
- Added a compact diagnostic report to the Studio output panel; failed checks are reported without blocking access to the editor.
- Added automated coverage for the startup diagnostic checks.

## v0.9.7 development update
- Added pre-1.0 release hardening tests covering core expressions, unsafe/unsupported AST expressions, error messages, line numbers, argument splitting, actions, loops, storage, Visele instruction recording, translation/export, and CLI behavior.
- Fixed boolean `and` / `or` evaluation to short-circuit instead of evaluating both operands.
- Added an exponent magnitude guardrail to prevent extreme power expressions from consuming excessive resources.
- Added `pytest.ini` so both `pytest -q` and `python -m pytest -q` resolve the project package consistently.
- Added a pre-1.0 release checklist covering editor/project workflows, Visele, extensions, portability, security, documentation, and release evidence.
- Removed generated cache artifacts from the release package.
- This is still a development build. GUI smoke tests and cross-platform verification remain required before 1.0.

## v0.9.6 development update
- Moved Compact Kit template definitions out of Python and into `templates.modkec`, using Modkec-style `template(command, variant, source)` declarations.
- Added support for `.modkec` files inside validated extension ZIP packages so template definitions ship with Compact Kit.
- Updated Compact Kit documentation and tests for adding custom template variants by editing Modkec source.

## v0.9.5 development update
- Added a local partnered-extension catalog, beginning with Compact Kit, without auto-installing or auto-activating bundled extensions.
- Added explicit install/uninstall controls for partnered extensions through the existing validated community extension manager.
- Added Compact Kit source templates for basic/scientific calculators, game score/health, and random-number utilities. Generated source is returned as editable text.
- Added bare identifier arguments for extension commands, enabling template variants such as `calculator(basic)`.
- Added tests for catalog visibility, installation lifecycle, activation, and template generation.

## v0.9.4 development update
- Removed Compact Kit from the built-in Extensions menu and extension catalog; it is now a fork-maintained customization. Added a guide for reintroducing it in a personal fork.
- Added `code(language)` / `code(language) end` blocks to the interpreter for explicitly marked native source. Python blocks run in the Modkec Python namespace; other supported languages launch their installed runtime/compiler as a subprocess with a timeout.
- Added source-language-aware translation for a deliberately limited Python subset inside `code(python)` blocks. The matching close marker returns translation to Modkec syntax. Mismatched/missing markers and unsupported conversions now produce errors.
- Added Command Maker Save, Insert, and Close controls. Custom command definitions persist under the user's configuration directory and can be reinserted from Program → Insert Saved Command.
- Added regression tests for mixed-language translation, missing/mismatched block markers, unsupported Python syntax, and Python-block execution.

## v0.9.3 development update
- Replaced the single-document editor buffer with document tabs that retain each file's source, path, and dirty state; added per-tab close and Save All.
- Changed the project explorer to lazily populate folders recursively and avoid traversing directory symlinks.
- Added an interactive native console with live output, stdin entry, Stop, and process exit codes; routed common compiled-language run output through it.
- Added a versioned community extension API (`register(api)`, `api.register_command`) with explicit local ZIP installation, command manifests, safe ZIP-path checks, archive size/count limits, and lazy loading on `import(extension_id)`.
- Added a runnable sample extension package and tests for command registration and archive path traversal.
- Made `store(name, value)` persist values in `.modkec_store.json` beside the source file; `get()` reads saved values and `delete()` removes them.
- Connected `play_sound`, `stop_sound`, `volume`, and `play_video` to available native audio/video players, with relative paths resolved beside the script; dispatch now happens in program order and looping is supported on Windows WAV playback and ffplay.
- Replaced the Visele image placeholder with Tk image loading for supported formats, with an explicit error placeholder for unsupported/missing images.
- Implemented basic HTTP POST behavior for `send(url, data, optional_content_type)` and included nested script media actions in the caller.
- Added regression coverage for persistent storage, media dispatch, extension ZIP installation, and path traversal.

## v0.9.2 development update
- Added a button-color setting and automatic light/dark text selection based on background and button brightness.
- F5 now auto-runs native files by extension and saves dirty native-source buffers before launch; renamed the misleading Save All entry to Save Current File.
- Removed Modkec-specific syntax colors from native-language files rather than applying incorrect highlighting.
- Expanded background color changes across Studio surfaces and updated syntax colors for light backgrounds.
- Redirected Python bytecode caches into `.pytest_cache/pycache`; added cache settings to launch scripts and test startup.
- Expanded the Extensions manager to show native language support separately from translation/export packs, including detected runtime status for 41 catalog entries.
- Bound Ctrl+F to a Find window with next/previous search and a Close action that clears search highlights and the selection.
- Replaced the placeholder-insertion flow with a dedicated Command Maker script panel that inserts a command wrapper only after the user writes and submits a body.
- Removed the duplicate Extensions menu so Compact Kit and the extension manager share one menu.
- Changed Source Control to inspect the active project/workspace and explain its purpose; it now reports that staging, commits, diffs, and history remain unimplemented.
- Added native-run paths for C#, Visual Basic, and F# through temporary .NET projects, added more native language catalog entries, and fixed compiler output naming for Windows.
- Added extension-registry and contrast-selection tests.
- Blocked Modkec-only tools (Command Maker, Compact Kit, preview, translation, and export) from accidentally parsing or modifying an open native-language file.

## v0.9.1 development update
- Reworked Beatmaker into a larger step-pad sequencer with clearer track colors and controls.
- Fixed project-tree folder behavior: Studio no longer toggles folders a second time on mouse release.
- Expanded the custom background color setting from the editor to the main Studio surfaces.
- Moved Compact Kit templates from Program to Extensions → Compact Kit Extension.
- Added New Source File with common language choices and Run Native for saved source files when their system runtime/compiler is installed.
- Added native-run mappings for Python, JavaScript, TypeScript (tsx), Lua, Luau, Ruby, PHP, Perl, R, Julia, Go, Rust, Java, Kotlin, Swift, Dart, Scala, Clojure, Elixir, Haskell, Bash, PowerShell, Lisp, Scheme, Fortran, C, C++, SQL, and browser-openable HTML/CSS/SVG.
- Native programs run with the user's normal operating-system permissions; this is not a sandbox. Runtime availability varies by operating system.

## v0.9 development build
- Added explicit built-in module dependency resolution, automatic dependency imports, duplicate-import handling, dependency tracking, and circular-dependency errors. `import(media)` now imports `visele` automatically.
- Added regression tests for module dependency loading, duplicate imports, unknown modules, and circular dependencies.
- Made the Explorer, Search, Source Control, and Extensions activity buttons functional.
- Added single-click project opening and arrow-key/Enter navigation in the project tree.
- Reworked Quick Start into a scrollable window to prevent text overflow.
- Combined Problems and Output into one panel tab and made the editor/bottom-panel divider resizable.
- Added an initial Compact Kit menu with editable templates for basic calculators, game score/health, and random utilities.
- Added a dependency-free 16-step beatmaker with synthesized audio and WAV export; playback uses an available system player when possible.
- Added an initial translation-target extension manager and GitHub fork browser. Forks are shown for discovery only and are not downloaded or executed automatically.
- Added a custom background color control.
- Expanded C translation to support basic action definitions and conditional action calls.
- Improved HTML translation so simple action/condition programs can execute in the generated page and display their output.

## v0.8.4
- Added native scientific expression evaluation, including trigonometry, inverse trigonometry, logarithms, exponentials, factorials, powers, constants, and safe arithmetic expressions.
- Added button-specific Visele actions using `button(label, x, y, action_name)`, passing the clicked label into the action.
- Added named Visele text elements and `update_text(name, value)` for interactive displays.
- Added a native Modkec scientific calculator example.
- Added tests for scientific evaluation and button actions.

## v0.8.3
- Implemented timed Visele preview animations for element position, size, radius, opacity, and rotation.
- Implemented `fade()`, `rotate()`, and target-specific or global `stop_animation()` behavior in the Studio preview.
- Expanded native website building with semantic text, buttons, images, links, theme colors, and custom CSS commands.
- Added tests for animation tracks, stopping animations, and generated native-site components.

# Changelog

## v0.8.2
- Fixed Python translation for `ask()`, `equal()`, `greater()`, `less()`, `and()`, `or()`, and `not()` commands.
- Added translation support for conditional action calls inside action/command bodies.
- Preserved Modkec shared-variable behavior in generated Python functions by emitting global declarations for variables already defined before an action.
- Added regression tests that compile and run a translated calculator, including modulus, invalid-operation, and division-by-zero cases.
- Verified Python export writes syntactically valid Python files.

## v0.8.1
- Added a native Modkec website builder under `import(web)` using semantic `site_*` commands.
- Added standalone HTML generation with generated responsive styling and search interactions; website authors do not write raw HTML/CSS/JavaScript.
- Added `examples/community_hub.modkec` and automated site-builder tests.

## v0.8.0
- Added `command(name, parameters...) ... end()` for user-defined commands that can be called directly.
- Added a Studio menu wizard: Program → Create Custom Command…
- Added opt-in Python blocks using `import(py)`, `python() ... end_python()`.
- Python blocks share variables with Modkec and forward `print()` output to the Studio output.
- Added Python-target passthrough in the translator; non-Python targets reject native Python blocks explicitly.
- Added custom-command and Python interop examples and automated tests.

## v0.7.2
- Added web-source blocks for assembling HTML/CSS/JavaScript into HTML pages or JavaScript bundles.
- Retained the v0.7 language-core improvements.


## v1.0.0-p10
- Added the `application` module and a host callback bridge for declarative desktop windows, controls, values, events, dialogs, file pickers, and closing.
- Added control validation, missing-control errors, event-to-action dispatch, and host exception wrapping.

## v1.0.0-p11
- Added `studio/shell.modkec` as a restricted source definition for Studio branding, status-bar text, and the high-visibility source-file warning.
- The desktop host now reads those presentation strings from the Modkec source definition instead of hardcoding them in the UI builder.
- Added validation for missing, duplicate, malformed, and unsupported shell declarations, plus integration checks.
- This is an incremental UI migration: Tkinter still creates the widgets and handles desktop events; the source definition supplies presentation text only.

## v1.0.0-p12
- Extracted workspace serialization, workspace validation, and UTF-8 source-file I/O into `modkec.studio_core`, a host-independent core service module.
- Routed workspace open/save and active-document save operations through the shared core services.
- Added regression coverage for workspace round trips, malformed/unsupported workspace data, missing folders, and UTF-8 source files.
- This is an architectural separation step; the services are still implemented in Python and do not yet make Studio self-hosted.

## v1.0.0-p13
- Added `studio/bootstrap.modkec` as the source-controlled bootstrap manifest for the Studio entry point, required Studio definitions, and declared host capabilities.
- Added strict bootstrap validation for duplicate declarations, malformed arguments, unsafe paths, missing/empty UTF-8 source files, unsupported capabilities, and version mismatches.
- Studio validates the manifest before constructing the desktop UI; `run_modkec.py --bootstrap-check` provides a headless bootstrap check.
- Added regression tests for manifest integrity, path traversal, duplicate sources, missing files, and version drift.
- The manifest makes bootstrap requirements explicit and catches incomplete packages early. This is not yet a Python-free/self-hosted runtime: the language engine and Tkinter desktop host still depend on Python, as declared in the manifest.


## v1.0.0-p14 — Native migration, chunk 1 (experimental)

- Added a standalone C runtime kernel that runs a limited Modkec core subset without starting Python.
- Added Linux shell and Windows batch build/run scripts; these are launch/build helpers, not the runtime itself.
- Added native smoke tests for supported commands, explicit rejection of unsupported module syntax, and missing-file errors.
- Preserved the original Python/Tkinter Studio launchers so existing features remain available while migration continues.
- This is not yet full self-hosting: the native kernel does not implement the full language, translator, extensions, BeatMaker, Visele, workspace system, or desktop UI.

## v1.0.0-p14 — native-kernel hardening follow-up
- Reject oversized string values instead of silently truncating them.
- Reject non-finite numeric literals and non-finite values during increment/decrement.
- Guard large-number formatting against out-of-range floating-point-to-integer conversion.
- Expanded native runtime regression tests from 3 to 7 cases.
- Full suite result in the build environment: 231 passed, 6 GUI tests skipped because no display was available, 7 subtests passed.
- Windows executable remains unavailable in this build environment; this package is still a Linux x86-64 kernel preview, not a universal or fully self-hosted Studio release.

## v1.0.0-p14 — native file and persistence increment
- Added native `read_file`, `write_file`, `file_exists`, `copy_file`, `rename_file`, and `create_folder` commands for basic file workflows.
- Added scalar `store(name, value)` persistence using a `.modkec_store.json` sidecar beside the source script; `get(name)` can retrieve values in subsequent runs.
- Added tests for file reads/writes/copy/rename, missing-file errors, and persistence across separate process runs while retaining multiple keys.
- Persistence remains a limited scalar compatibility layer; structured data, full JSON semantics, and the complete Python engine behavior are not yet implemented.

## v1.0.0-p14 — Native result assignment increment
- Added scalar result capture using `command(...) -> variable` for `say`, `get`, `file_exists`, and `read_file` in the native kernel.
- `read_file(...) -> variable` captures bounded text content instead of writing it to stdout; files that exceed the value limit fail explicitly.
- `file_exists(...) -> variable` captures `true` or `false`.
- Unsupported result-producing commands are rejected before command execution, avoiding partial side effects from unsupported syntax.
- Added native regression tests for scalar/file result capture and unsupported result assignments.
- This remains a limited native subset; user-defined actions, structured data, full module behavior, and the Studio GUI are not yet migrated.

## v1.0.0-p14 — Native result assignment increment
- Added scalar result capture using `command(...) -> variable` for `say`, `get`, `file_exists`, and `read_file` in the native kernel.
- `read_file(...) -> variable` captures bounded text content instead of writing it to stdout; files that exceed the value limit fail explicitly.
- `file_exists(...) -> variable` captures `true` or `false`.
- Unsupported result-producing commands are rejected before command execution, avoiding partial side effects from unsupported syntax.
- Added native regression tests for scalar/file result capture and unsupported result assignments.
- This remains a limited native subset; user-defined actions, structured data, full module behavior, and the Studio GUI are not yet migrated.

## v1.0.0-p15 — Modkec-owned startup and host-service registry

- Startup settings (host path, version, and mode) are now declared in `studio/entry.modkec`.
- Added `studio/host_services.modkec` as the source-controlled map of Studio capabilities to their current host adapters.
- Added a validated Python compatibility adapter in `modkec/studio_launch.py`; it validates the bootstrap manifest and service registry before handing off to the existing desktop host.
- Added tests for registry completeness, duplicate service rejection, host dispatch, and unsafe paths.
- This is a migration architecture increment, not full self-hosting: the editor, Tkinter widgets, engine, translator, and services still use Python adapters.

## v1.0.0-p16 — Embedded desktop host source

- Moved the full existing Tkinter desktop implementation into `studio/desktop.modkec` as an explicit embedded Python block.
- Changed the Modkec entry point to load and execute that Modkec source directly; normal startup no longer dispatches through `studio.py` or `modkec.studio_launch`.
- Kept `studio.py` as a compatibility copy for existing users/tools while the Modkec-hosted copy is verified.
- This removes the separate `studio.py` file from the normal launch path, but Python itself and Tkinter are still needed to execute the embedded block; the engine, translator, and other bundled services remain Python modules.

## v1.0.0-p18 — Native-platform runtime build pipeline

- Added a GitHub Actions build matrix for Linux, Windows, and macOS standalone bundles.
- Added isolated build virtual environments to local launchers to avoid modifying system Python installations.
- Added a Linux GUI smoke test under Xvfb in CI.
- OS-specific runtime binaries are not included in this source package; the workflow must run on native runners to generate them.

## 1.0.0 release-candidate verification update

- Added cross-platform automated test steps before packaging in the standalone build workflow.
- Added a test report separating checks completed locally from Windows/macOS and bundled-runtime checks that still require native CI runners.
- This remains a release candidate until all native build jobs and clean-system launch tests pass.
