from pathlib import Path

import pytest

from studio import ModkecStudio


def test_command_help_definition_contains_reference_entries():
    entries = ModkecStudio._read_command_help(
        Path(__file__).resolve().parents[1] / "studio" / "command_help.modkec"
    )
    assert len(entries) >= 20
    assert entries['say(value)'] == 'Core: display text or a value. Example: say("Hello!")'
    assert 'Visele' in entries['p(120) hex(FF0000)']


def test_command_help_rejects_unknown_declarations(tmp_path):
    path = tmp_path / "command_help.modkec"
    path.write_text('execute_python("print(1)")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio help declaration"):
        ModkecStudio._read_command_help(path)


def test_command_help_rejects_non_string_arguments(tmp_path):
    path = tmp_path / "command_help.modkec"
    path.write_text('studio_help("say(value)", 42)\n', encoding="utf-8")
    with pytest.raises(ValueError, match="exactly two strings"):
        ModkecStudio._read_command_help(path)


def test_command_help_rejects_duplicate_commands(tmp_path):
    path = tmp_path / "command_help.modkec"
    path.write_text('studio_help("say(value)", "first")\nstudio_help("say(value)", "second")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate Studio help command"):
        ModkecStudio._read_command_help(path)


def test_command_help_rejects_empty_reference(tmp_path):
    path = tmp_path / "command_help.modkec"
    path.write_text('# empty\n', encoding="utf-8")
    with pytest.raises(ValueError, match="definition is empty"):
        ModkecStudio._read_command_help(path)
