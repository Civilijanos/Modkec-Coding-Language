from pathlib import Path

import pytest

from studio import ModkecStudio

ROOT = Path(__file__).resolve().parents[1]
DEFINITION = ROOT / "studio" / "shell.modkec"


def test_shell_definition_provides_branding_status_and_warning():
    declarations = ModkecStudio._read_shell_declarations(DEFINITION)
    assert declarations["studio_branding"] == ("◈", "Modkec Studio", "  •  Workspace")
    assert "13/14" in declarations["studio_status"][0]
    assert "AUTOSAVING IS DISABLED" in declarations["studio_source_warning"][0]


def test_shell_definition_rejects_unknown_declaration(tmp_path):
    path = tmp_path / "shell.modkec"
    path.write_text('studio_branding("x", "App", "Workspace")\nexecute_python("print(1)")\nstudio_status("status")\nstudio_source_warning("warning")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio shell declaration"):
        ModkecStudio._read_shell_declarations(path)


def test_shell_definition_rejects_duplicate_declaration(tmp_path):
    path = tmp_path / "shell.modkec"
    path.write_text('studio_branding("x", "App", "Workspace")\nstudio_branding("y", "Other", "Workspace")\nstudio_status("status")\nstudio_source_warning("warning")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate Studio shell declaration"):
        ModkecStudio._read_shell_declarations(path)


def test_shell_definition_requires_all_declarations(tmp_path):
    path = tmp_path / "shell.modkec"
    path.write_text('studio_branding("x", "App", "Workspace")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="must declare exactly"):
        ModkecStudio._read_shell_declarations(path)
