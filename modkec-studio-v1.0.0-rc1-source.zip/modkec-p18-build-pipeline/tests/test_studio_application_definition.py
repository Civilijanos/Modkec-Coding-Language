from pathlib import Path

import pytest

from studio import ModkecStudio
from modkec.engine import ModkecEngine

ROOT = Path(__file__).resolve().parents[1]
DEFINITION = ROOT / "studio" / "application.modkec"


def test_application_definition_is_loaded_from_modkec_source():
    settings = ModkecStudio._read_application_definition(DEFINITION)
    assert settings["title"] == "Modkec Studio"
    assert settings["window_size"] == "1240x820"
    assert settings["minimum_size"] == "900x620"
    assert settings["version"] == "v1.0.0-p18"
    assert settings["splash_message"] == "Preparing your Modkec workspace…"


def test_application_parser_rejects_unknown_or_executable_declarations(tmp_path):
    path = tmp_path / "application.modkec"
    path.write_text('execute_python("print(1)")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio application declaration"):
        ModkecStudio._read_application_definition(path)


def test_application_parser_rejects_duplicate_settings(tmp_path):
    source = DEFINITION.read_text(encoding="utf-8")
    path = tmp_path / "application.modkec"
    path.write_text(source + '\nstudio_setting("title", "Duplicate")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate Studio application setting"):
        ModkecStudio._read_application_definition(path)


def test_application_parser_rejects_invalid_window_sizes(tmp_path):
    source = DEFINITION.read_text(encoding="utf-8").replace('studio_setting("window_size", "1240x820")', 'studio_setting("window_size", "1x1")')
    path = tmp_path / "application.modkec"
    path.write_text(source, encoding="utf-8")
    with pytest.raises(ValueError, match="outside supported limits"):
        ModkecStudio._read_application_definition(path)


def test_starter_program_is_valid_modkec_and_runs():
    source = (ROOT / "studio" / "starter.modkec").read_text(encoding="utf-8")
    engine = ModkecEngine()
    output = engine.run(source)
    assert output == "Hello from Modkec!\nYou win!"
    assert engine.variables["score"] == 12
