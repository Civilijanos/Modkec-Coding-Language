from pathlib import Path

import pytest

from studio import ModkecStudio


DEFINITION = Path(__file__).resolve().parents[1] / "studio" / "theme.modkec"


def test_theme_definition_contains_complete_existing_palette():
    colors = ModkecStudio._read_theme_definition(DEFINITION)
    assert len(colors) == 18
    assert colors["window"] == "#1e1e1e"
    assert colors["panel"] == "#252526"
    assert colors["accent"] == "#0e639c"
    assert all(len(value) == 7 and value.startswith("#") for value in colors.values())


def test_theme_parser_rejects_unknown_declarations(tmp_path):
    path = tmp_path / "theme.modkec"
    path.write_text('execute_python("print(1)")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio theme declaration"):
        ModkecStudio._read_theme_definition(path)


def test_theme_parser_rejects_unknown_color_names(tmp_path):
    path = tmp_path / "theme.modkec"
    path.write_text('studio_color("mystery", "#ffffff")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Unknown Studio theme color"):
        ModkecStudio._read_theme_definition(path)


def test_theme_parser_rejects_invalid_hex_colors(tmp_path):
    path = tmp_path / "theme.modkec"
    path.write_text('studio_color("window", "red")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid hex color"):
        ModkecStudio._read_theme_definition(path)


def test_theme_parser_rejects_duplicate_color_names(tmp_path):
    path = tmp_path / "theme.modkec"
    path.write_text('studio_color("window", "#ffffff")\nstudio_color("window", "#000000")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate Studio theme color"):
        ModkecStudio._read_theme_definition(path)


def test_theme_parser_requires_complete_palette(tmp_path):
    path = tmp_path / "theme.modkec"
    path.write_text('studio_color("window", "#ffffff")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="definition is incomplete"):
        ModkecStudio._read_theme_definition(path)
