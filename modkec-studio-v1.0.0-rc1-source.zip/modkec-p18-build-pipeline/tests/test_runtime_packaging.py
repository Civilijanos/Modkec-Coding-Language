from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class StandaloneRuntimePackagingTests(unittest.TestCase):
    def test_builder_and_entrypoint_exist(self):
        self.assertTrue((ROOT / "packaging" / "build_runtime.py").is_file())
        self.assertTrue((ROOT / "packaging" / "frozen_entry.py").is_file())
        self.assertTrue((ROOT / "packaging" / "requirements-build.txt").is_file())

    def test_build_includes_tk_and_required_assets(self):
        source = (ROOT / "packaging" / "build_runtime.py").read_text(encoding="utf-8")
        for expected in ("tkinter", "--onedir", "--windowed", "--collect-submodules", "studio", "modkec", "--runtime-check"):
            self.assertIn(expected, source)

    def test_runtime_check_validates_tcl_and_assets(self):
        source = (ROOT / "packaging" / "frozen_entry.py").read_text(encoding="utf-8")
        for expected in ("--runtime-check", "tkinter.Tcl()", "info patchlevel", "entry.modkec", "desktop.modkec", "engine.py"):
            self.assertIn(expected, source)

    def test_native_build_launchers_exist(self):
        self.assertTrue((ROOT / "packaging" / "build-runtime.sh").is_file())
        self.assertTrue((ROOT / "packaging" / "build-runtime.bat").is_file())
        self.assertTrue((ROOT / "packaging" / "build-runtime.ps1").is_file())


if __name__ == "__main__":
    unittest.main()
