from pathlib import Path
import shutil

import pytest

from modkec.bootstrap import check_bootstrap, read_bootstrap_manifest

ROOT = Path(__file__).resolve().parents[1]


def test_bootstrap_manifest_validates_all_required_sources():
    result = check_bootstrap(ROOT)
    assert result["version"] == "v1.0.0-p18"
    assert result["entry"] == "studio/entry.modkec"
    assert result["source_count"] == 13
    assert set(result["capabilities"]) == {"python-host", "tkinter-host", "modkec-engine"}


def test_bootstrap_rejects_missing_required_source(tmp_path):
    shutil.copytree(ROOT / "studio", tmp_path / "studio")
    shutil.copytree(ROOT / "bundled_extensions", tmp_path / "bundled_extensions")
    shutil.copy(ROOT / "studio.py", tmp_path / "studio.py")
    shutil.copytree(ROOT / "modkec", tmp_path / "modkec")
    (tmp_path / "studio" / "theme.modkec").unlink()
    with pytest.raises(ValueError, match="missing or unreadable"):
        check_bootstrap(tmp_path)


@pytest.mark.parametrize("line", [
    'bootstrap_source("../outside.modkec")',
    'bootstrap_source("/etc/passwd")',
    'bootstrap_source("studio/theme.modkec")\nbootstrap_source("studio/theme.modkec")',
])
def test_bootstrap_rejects_unsafe_or_duplicate_sources(tmp_path, line):
    shutil.copytree(ROOT / "studio", tmp_path / "studio")
    shutil.copytree(ROOT / "bundled_extensions", tmp_path / "bundled_extensions")
    shutil.copy(ROOT / "studio.py", tmp_path / "studio.py")
    shutil.copytree(ROOT / "modkec", tmp_path / "modkec")
    manifest = (tmp_path / "studio" / "bootstrap.modkec")
    source = manifest.read_text(encoding="utf-8")
    if line.startswith('bootstrap_source("../') or line.startswith('bootstrap_source("/etc'):
        source = source.replace('bootstrap_source("studio/theme.modkec")', line, 1)
    else:
        source = source.replace('bootstrap_source("studio/theme.modkec")', line)
    manifest.write_text(source, encoding="utf-8")
    with pytest.raises(ValueError):
        read_bootstrap_manifest(tmp_path)


def test_bootstrap_rejects_version_mismatch(tmp_path):
    shutil.copytree(ROOT / "studio", tmp_path / "studio")
    shutil.copytree(ROOT / "bundled_extensions", tmp_path / "bundled_extensions")
    shutil.copy(ROOT / "studio.py", tmp_path / "studio.py")
    shutil.copytree(ROOT / "modkec", tmp_path / "modkec")
    manifest = tmp_path / "studio" / "bootstrap.modkec"
    manifest.write_text(manifest.read_text(encoding="utf-8").replace("p18", "p12"), encoding="utf-8")
    with pytest.raises(ValueError, match="version does not match"):
        read_bootstrap_manifest(tmp_path)


def test_bootstrap_entry_is_modkec_with_explicit_python_bridge():
    entry = ROOT / "studio" / "entry.modkec"
    source = entry.read_text(encoding="utf-8")
    assert source.startswith("# Modkec Studio entry point")
    assert "import(py)" in source
    assert "python()" in source
    assert "desktop_engine.run(source)" in source
    assert '"studio" / "desktop.modkec"' in source
    desktop = (ROOT / "studio" / "desktop.modkec").read_text(encoding="utf-8")
    assert "import tkinter as tk" in desktop
    assert "class ModkecStudio" in desktop
    assert "end_python()" in desktop
    assert "end_python()" in source


def test_studio_launchers_route_through_modkec_entry():
    shell = (ROOT / "run_studio.sh").read_text(encoding="utf-8")
    batch = (ROOT / "run_studio.bat").read_text(encoding="utf-8")
    assert "run_modkec.py --quiet studio/entry.modkec" in shell
    assert "run_modkec.py --quiet studio/entry.modkec" in batch
    assert "python3 studio.py" not in shell
    assert "py -3 studio.py" not in batch


def test_host_service_registry_covers_existing_host_adapters():
    from modkec.studio_launch import read_host_services

    services = read_host_services(ROOT)
    assert set(services) == {
        "desktop", "language_engine", "translator", "extensions",
        "visuals", "beatmaker", "project_files",
    }
    assert services["desktop"]["adapter"] == "tkinter"
    assert services["desktop"]["source"] == "studio/desktop.modkec"
    assert services["translator"]["source"] == "modkec/translator.py"


def test_host_service_registry_rejects_duplicate_services(tmp_path):
    import shutil
    from modkec.studio_launch import read_host_services

    shutil.copytree(ROOT / "studio", tmp_path / "studio")
    shutil.copytree(ROOT / "modkec", tmp_path / "modkec")
    shutil.copy(ROOT / "studio.py", tmp_path / "studio.py")
    registry = tmp_path / "studio" / "host_services.modkec"
    registry.write_text(registry.read_text(encoding="utf-8") + '\nstudio_host_service("desktop", "studio.py", "tkinter")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate host service"):
        read_host_services(tmp_path)


def test_launch_studio_validates_and_dispatches_host_without_opening_gui(monkeypatch):
    from modkec.studio_launch import launch_studio

    captured = {}
    def fake_run_path(path, run_name):
        captured["path"] = path
        captured["run_name"] = run_name
        return {"started": True}

    result = launch_studio(ROOT, "studio.py", run_path=fake_run_path)
    assert result == {"started": True}
    assert captured["path"] == str((ROOT / "studio.py").resolve())
    assert captured["run_name"] == "__main__"


def test_launch_studio_rejects_path_escape():
    from modkec.studio_launch import launch_studio

    with pytest.raises(ValueError, match="Unsafe Studio host path"):
        launch_studio(ROOT, "../outside.py", run_path=lambda *_args, **_kwargs: None)
