from pathlib import Path

import pytest

from studio import ModkecStudio


def test_studio_menu_definition_parses_all_top_level_menus():
    declarations = ModkecStudio._read_menu_declarations(
        Path(__file__).resolve().parents[1] / "studio" / "menus.modkec"
    )
    menu_names = [args[0] for op, args in declarations if op == "studio_menu"]
    assert menu_names == ["File", "Edit", "Program", "Extensions", "Settings", "Help"]
    assert sum(op == "studio_item" for op, _ in declarations) >= 30
    assert sum(op == "studio_check" for op, _ in declarations) == 2
    assert sum(op == "studio_recent" for op, _ in declarations) == 1


def test_studio_menu_definition_rejects_unknown_declarations(tmp_path):
    path = tmp_path / "menus.modkec"
    path.write_text('studio_menu("File")\nrun_arbitrary_code()\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio menu declaration"):
        ModkecStudio._read_menu_declarations(path)


def test_studio_menu_definition_rejects_non_string_arguments(tmp_path):
    path = tmp_path / "menus.modkec"
    path.write_text('studio_menu(123)\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Menu arguments must be strings"):
        ModkecStudio._read_menu_declarations(path)


def test_studio_menu_definition_rejects_wrong_argument_count(tmp_path):
    path = tmp_path / "menus.modkec"
    path.write_text('studio_item("Save")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Wrong argument count"):
        ModkecStudio._read_menu_declarations(path)
