from pathlib import Path

import pytest

from modkec.extensions import PARTNERED_EXTENSIONS, _parse_partnered_extension_registry

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "bundled_extensions" / "registry.modkec"


def test_partnered_extension_registry_is_loaded_from_modkec_source():
    declarations = _parse_partnered_extension_registry(REGISTRY)
    assert set(declarations) == {"compact_kit"}
    item = declarations["compact_kit"]
    assert item["name"] == "Compact Kit"
    assert item["version"] == "1.0.0"
    assert item["commands"] == ["calculator", "game", "utility"]
    assert item["package_path"] == ROOT / "bundled_extensions" / "compact_kit.zip"
    assert PARTNERED_EXTENSIONS == declarations


@pytest.mark.parametrize("source, error", [
    ('execute_python("print(1)")\n', "Invalid partnered extension declaration"),
    ('partnered_extension("xx", "Name", "1", "P", "D", "../outside.zip", "doit")\n', "local ZIP filename"),
    ('partnered_extension("bad id", "Name", "1", "P", "D", "x.zip", "doit")\n', "Invalid partnered extension ID"),
    ('partnered_extension("compact_kit", "One", "1", "P", "D", "x.zip", "doit")\npartnered_extension("compact_kit", "Two", "1", "P", "D", "y.zip", "doit")\n', "Duplicate partnered extension ID"),
    ('partnered_extension("xx", "Name", 1, "P", "D", "x.zip", "doit")\n', "seven non-empty strings"),
    ('partnered_extension("xx", "Name", "1", "P", "D", "x.zip", "doit;doit")\n', "Invalid or duplicate partnered extension commands"),
    ('# no extensions\n', "registry is empty"),
])
def test_partnered_extension_registry_rejects_invalid_declarations(tmp_path, source, error):
    path = tmp_path / "registry.modkec"
    path.write_text(source, encoding="utf-8")
    with pytest.raises(ValueError, match=error):
        _parse_partnered_extension_registry(path)


def test_bundled_install_rejects_command_registry_mismatch(tmp_path, monkeypatch):
    import modkec.plugins as plugins
    from modkec.extensions import PARTNERED_EXTENSIONS

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    original = PARTNERED_EXTENSIONS["compact_kit"]["commands"]
    monkeypatch.setitem(PARTNERED_EXTENSIONS["compact_kit"], "commands", ["unexpected_command"])
    with pytest.raises(ValueError, match="commands do not match"):
        plugins.install_bundled_extension("compact_kit")
    assert plugins.list_community_extensions() == []
    monkeypatch.setitem(PARTNERED_EXTENSIONS["compact_kit"], "commands", original)
