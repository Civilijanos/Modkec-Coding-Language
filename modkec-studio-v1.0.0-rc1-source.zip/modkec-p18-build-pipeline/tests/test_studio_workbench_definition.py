from pathlib import Path

import pytest

from studio import ModkecStudio


DEFINITION = Path(__file__).resolve().parents[1] / "studio" / "workbench.modkec"


def test_workbench_definition_contains_existing_activity_controls_and_panel_tabs():
    declarations = ModkecStudio._read_workbench_declarations(DEFINITION)
    activities = [(args[0], args[1]) for op, args in declarations if op == "studio_activity_button"]
    tabs = [(args[0], args[1]) for op, args in declarations if op == "studio_panel_tab"]
    actions = [(args[0], args[1]) for op, args in declarations if op == "studio_panel_action"]
    assert activities == [
        ("▤", "Explorer"),
        ("⌕", "Search"),
        ("⑂", "Source Control"),
        ("▣", "Extensions"),
    ]
    assert tabs == [
        ("PROBLEMS / OUTPUT", "PROBLEMS / OUTPUT"),
        ("COMMANDS", "COMMANDS"),
    ]
    assert actions == [("Run  ▶  F5", "run_program")]


def test_workbench_parser_rejects_unknown_declarations(tmp_path):
    path = tmp_path / "workbench.modkec"
    path.write_text('studio_activity_button("X", "Explorer")\nexecute_python("print(1)")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio workbench declaration"):
        ModkecStudio._read_workbench_declarations(path)


def test_workbench_parser_rejects_non_string_arguments(tmp_path):
    path = tmp_path / "workbench.modkec"
    path.write_text('studio_activity_button("X", 123)\nstudio_panel_tab("Output", "OUTPUT")\nstudio_panel_action("Run", "run_program")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Workbench arguments must be strings"):
        ModkecStudio._read_workbench_declarations(path)


def test_workbench_parser_rejects_duplicate_activity_names(tmp_path):
    path = tmp_path / "workbench.modkec"
    path.write_text('studio_activity_button("X", "Explorer")\nstudio_activity_button("Y", "Explorer")\nstudio_panel_tab("Output", "OUTPUT")\nstudio_panel_action("Run", "run_program")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Duplicate Studio activity button"):
        ModkecStudio._read_workbench_declarations(path)


def test_workbench_parser_requires_a_panel_action(tmp_path):
    path = tmp_path / "workbench.modkec"
    path.write_text('studio_activity_button("X", "Explorer")\nstudio_panel_tab("Output", "OUTPUT")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="exactly one panel action"):
        ModkecStudio._read_workbench_declarations(path)
