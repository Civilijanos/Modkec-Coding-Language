#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/../.." && pwd)
TMPDIR_NATIVE=$(mktemp -d)
trap 'rm -rf "$TMPDIR_NATIVE"' EXIT HUP INT TERM
cc -std=c11 -O2 -Wall -Wextra -Werror -pedantic "$ROOT/native/modkec_native.c" -o "$TMPDIR_NATIVE/modkec-native"
output=$("$TMPDIR_NATIVE/modkec-native" "$ROOT/tests/native/core.modkec")
expected=$(printf 'native runtime online\n41\n40')
if [ "$output" != "$expected" ]; then
  printf 'Unexpected native runtime output:\n%s\n' "$output" >&2
  exit 1
fi
if "$TMPDIR_NATIVE/modkec-native" /no/such/modkec-file >/dev/null 2>&1; then
  echo 'Expected missing-source error' >&2; exit 1
fi
printf 'Native runtime tests passed.\n'
