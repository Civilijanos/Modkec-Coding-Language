import pytest
from modkec.engine import ModkecEngine, ModkecError

def test_application_module_records_window_and_controls():
    calls = []
    engine = ModkecEngine(application_callback=lambda spec, _engine: calls.append(spec))
    engine.run('import(application)\napp_window("Demo", 640, 480, false)\napp_control("name", input, "Name", 4, 5, 200, 30)\napp_set("name", "Ada")\napp_get("name") -> value')
    assert engine.variables['value'] == 'Ada'
    assert calls[0] == {'type':'window','title':'Demo','width':640,'height':480,'resizable':False}
    assert calls[1]['control_type'] == 'input'
    assert calls[-1] == {'type':'set','id':'name','value':'Ada'}

def test_application_module_requires_import():
    with pytest.raises(ModkecError, match=r'requires import\(application\)'):
        ModkecEngine().run('app_window("Demo")')

def test_application_module_rejects_invalid_control_and_size():
    engine = ModkecEngine()
    with pytest.raises(ModkecError, match='Unsupported control type'):
        engine.run('import(application)\napp_control("x", slider)')
    with pytest.raises(ModkecError, match='width/height between'):
        engine.run('import(application)\napp_window("Demo", 20, 480)')

def test_application_module_get_unknown_control_fails():
    with pytest.raises(ModkecError, match='Unknown application control'):
        ModkecEngine().run('import(application)\napp_get("missing")')

def test_application_module_event_runs_action():
    engine = ModkecEngine()
    engine.run('import(application)\naction(clicked)\n    set(was_clicked, t)\nend()\napp_on("save", clicked)\napp_emit("save")')
    assert engine.variables['was_clicked'] is True

def test_application_module_wraps_host_errors():
    def fail(_spec, _engine): raise RuntimeError('host unavailable')
    with pytest.raises(ModkecError, match='Application host failed'):
        ModkecEngine(application_callback=fail).run('import(application)\napp_window("Demo")')
