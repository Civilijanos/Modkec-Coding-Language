from pathlib import Path

import pytest

from modkec.engine import ModkecEngine, ModkecError


def test_include_loads_reusable_parameterized_actions(tmp_path):
    (tmp_path / "math_helpers.modkec").write_text(
        'import(actions)\naction(add_pair, left, right)\n    return(left + right)\nend()\n',
        encoding="utf-8",
    )
    main = tmp_path / "main.modkec"
    engine = ModkecEngine(source_name=str(main))
    output = engine.run('include("math_helpers.modkec")\ncall(add_pair, 20, 22) -> answer\nsay(answer)')
    assert output == "42"
    assert engine.variables["answer"] == 42
    assert "left" not in engine.variables
    assert "right" not in engine.variables


def test_include_is_idempotent(tmp_path):
    module = tmp_path / "helpers.modkec"
    module.write_text('import(actions)\naction(greet, who)\n    say(who)\nend()\n', encoding="utf-8")
    engine = ModkecEngine(source_name=str(tmp_path / "main.modkec"))
    assert engine.run('include("helpers.modkec")\ninclude("helpers.modkec")\ncall(greet, "Modkec")') == "Modkec"


def test_include_rejects_top_level_side_effects(tmp_path):
    (tmp_path / "unsafe.modkec").write_text('say("runs during import")\n', encoding="utf-8")
    engine = ModkecEngine(source_name=str(tmp_path / "main.modkec"))
    with pytest.raises(ModkecError, match=r"only import\(\), include\(\), action\(\), command\(\)"):
        engine.run('include("unsafe.modkec")')


def test_include_detects_cycles(tmp_path):
    (tmp_path / "a.modkec").write_text('include("b.modkec")\n', encoding="utf-8")
    (tmp_path / "b.modkec").write_text('include("a.modkec")\n', encoding="utf-8")
    engine = ModkecEngine(source_name=str(tmp_path / "main.modkec"))
    with pytest.raises(ModkecError, match="Circular source-module include"):
        engine.run('include("a.modkec")')


def test_include_requires_modkec_extension(tmp_path):
    (tmp_path / "helper.txt").write_text('action(greet)\nend()\n', encoding="utf-8")
    engine = ModkecEngine(source_name=str(tmp_path / "main.modkec"))
    with pytest.raises(ModkecError, match="only loads files with the .modkec extension"):
        engine.run('include("helper.txt")')


def test_include_reports_missing_module(tmp_path):
    engine = ModkecEngine(source_name=str(tmp_path / "main.modkec"))
    with pytest.raises(ModkecError, match="Could not load source module"):
        engine.run('include("missing.modkec")')
