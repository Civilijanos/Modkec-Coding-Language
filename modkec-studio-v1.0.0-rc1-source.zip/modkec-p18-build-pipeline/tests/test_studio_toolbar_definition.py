from pathlib import Path

import pytest

from studio import ModkecStudio


def test_toolbar_definition_contains_all_primary_actions():
    declarations = ModkecStudio._read_toolbar_declarations(
        Path(__file__).resolve().parents[1] / "studio" / "toolbar.modkec"
    )
    buttons = [(args[0], args[1]) for op, args in declarations if op == "studio_toolbar_button"]
    assert buttons == [
        ("Export", "export_program"),
        ("Preview", "preview_program"),
        ("Translate", "translate_program"),
        ("Save", "save_file"),
        ("Open", "open_file"),
        ("Run Native", "run_current_file"),
        ("New", "new_file"),
    ]
    assert sum(op == "studio_target_selector" for op, _ in declarations) == 1
    assert [(op, args) for op, args in declarations if op == "studio_toolbar_label"] == [
        ("studio_toolbar_label", ("Target",))
    ]


def test_toolbar_parser_rejects_unknown_declarations(tmp_path):
    path = tmp_path / "toolbar.modkec"
    path.write_text('execute_python("print(1)")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Invalid Studio toolbar declaration"):
        ModkecStudio._read_toolbar_declarations(path)


def test_toolbar_parser_rejects_non_string_arguments(tmp_path):
    path = tmp_path / "toolbar.modkec"
    path.write_text('studio_toolbar_button("Run", 123)\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Toolbar arguments must be strings"):
        ModkecStudio._read_toolbar_declarations(path)


def test_toolbar_parser_rejects_wrong_argument_count(tmp_path):
    path = tmp_path / "toolbar.modkec"
    path.write_text('studio_target_selector("unexpected")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Wrong argument count"):
        ModkecStudio._read_toolbar_declarations(path)
