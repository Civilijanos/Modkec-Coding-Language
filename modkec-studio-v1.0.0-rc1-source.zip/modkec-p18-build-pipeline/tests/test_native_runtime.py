"""Smoke tests for the experimental native C runtime, independent of Python execution."""
from pathlib import Path
import shutil
import subprocess

import pytest

ROOT = Path(__file__).resolve().parents[1]
CC = shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")

@pytest.fixture(scope="module")
def native_binary(tmp_path_factory):
    if not CC:
        pytest.skip("No C compiler available to build the native runtime")
    binary = tmp_path_factory.mktemp("modkec-native") / "modkec-native"
    result = subprocess.run(
        [CC, "-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", "-pedantic",
         str(ROOT / "native" / "modkec_native.c"), "-o", str(binary)],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr
    return binary

def test_native_core_commands(native_binary):
    result = subprocess.run([str(native_binary), str(ROOT / "tests" / "native" / "core.modkec")],
                            capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == ["native runtime online", "41", "40"]
    assert "must not appear" not in result.stdout

def test_native_kernel_rejects_unsupported_commands(native_binary, tmp_path):
    source = tmp_path / "unsupported.modkec"
    source.write_text('import(calculator)\nadd(1, 2)\n', encoding="utf-8")
    result = subprocess.run([str(native_binary), str(source)], capture_output=True, text=True, check=False)
    assert result.returncode != 0
    assert "does not yet implement modules" in result.stderr

def test_native_kernel_reports_missing_source(native_binary, tmp_path):
    missing = tmp_path / "missing.modkec"
    result = subprocess.run([str(native_binary), str(missing)], capture_output=True, text=True, check=False)
    assert result.returncode == 2
    assert "missing.modkec" in result.stderr

@pytest.mark.parametrize("source, diagnostic", [
    ('set(value, "nan")\nincrement(value)\n', "not numeric"),
    ('set(value, 1e9999)\n', "set expects"),
    ('set(value, "' + ('x' * 5000) + '")\n', "set expects"),
])
def test_native_kernel_rejects_invalid_or_oversized_values(native_binary, tmp_path, source, diagnostic):
    program = tmp_path / "invalid-value.modkec"
    program.write_text(source, encoding="utf-8")
    result = subprocess.run([str(native_binary), str(program)], capture_output=True, text=True, check=False)
    assert result.returncode == 1
    assert diagnostic in result.stderr

def test_native_kernel_handles_large_numeric_values_without_crashing(native_binary, tmp_path):
    program = tmp_path / "large-number.modkec"
    program.write_text("set(value, 9223372036854775807)\nincrement(value)\nsay(value)\n", encoding="utf-8")
    result = subprocess.run([str(native_binary), str(program)], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "9.22337203685478e+18"

def test_native_file_operations(native_binary, tmp_path):
    program = tmp_path / "files.modkec"
    program.write_text(
        'import(files)\n'
        'write_file("first.txt", "hello from Modkec")\n'
        'file_exists("first.txt")\n'
        'copy_file("first.txt", "copy.txt")\n'
        'rename_file("copy.txt", "renamed.txt")\n'
        'create_folder("saved")\n'
        'write_file("saved/nested.txt", "nested content")\n'
        'read_file("saved/nested.txt")\n'
        'read_file("renamed.txt")\n',
        encoding="utf-8",
    )
    result = subprocess.run([str(native_binary), str(program)], cwd=tmp_path,
                            capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == ["true", "nested content", "hello from Modkec"]
    assert (tmp_path / "first.txt").read_text(encoding="utf-8") == "hello from Modkec"
    assert (tmp_path / "renamed.txt").read_text(encoding="utf-8") == "hello from Modkec"

def test_native_persistent_store_survives_runs_and_preserves_keys(native_binary, tmp_path):
    first = tmp_path / "store.modkec"
    first.write_text('store(coins, 42)\nstore(player, "Ada")\n', encoding="utf-8")
    result = subprocess.run([str(native_binary), str(first)], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    sidecar = tmp_path / ".modkec_store.json"
    assert '"coins": 42' in sidecar.read_text(encoding="utf-8")
    assert '"player": "Ada"' in sidecar.read_text(encoding="utf-8")
    second = tmp_path / "load.modkec"
    second.write_text("get(coins)\nget(player)\n", encoding="utf-8")
    result = subprocess.run([str(native_binary), str(second)], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == ["42", "Ada"]

def test_native_persistent_store_updates_existing_key(native_binary, tmp_path):
    source = tmp_path / "update.modkec"
    source.write_text('store(level, 1)\nstore(player, "Ada")\nstore(level, 9)\n', encoding="utf-8")
    result = subprocess.run([str(native_binary), str(source)], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    load = tmp_path / "load-update.modkec"
    load.write_text("get(level)\nget(player)\n", encoding="utf-8")
    result = subprocess.run([str(native_binary), str(load)], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == ["9", "Ada"]

def test_native_file_commands_reject_missing_input(native_binary, tmp_path):
    program = tmp_path / "missing-file.modkec"
    program.write_text('read_file("does-not-exist.txt")\n', encoding="utf-8")
    result = subprocess.run([str(native_binary), str(program)], cwd=tmp_path,
                            capture_output=True, text=True, check=False)
    assert result.returncode == 1
    assert "cannot read file" in result.stderr

def test_native_result_assignment_for_values_and_files(native_binary, tmp_path):
    (tmp_path / "message.txt").write_text("hello", encoding="utf-8")
    program = tmp_path / "result-assignment.modkec"
    program.write_text(
        'set(original, "Ada")\n'
        'get(original) -> copied\n'
        'file_exists("message.txt") -> exists\n'
        'read_file("message.txt") -> contents\n'
        'say(copied)\n'
        'say(exists)\n'
        'say(contents)\n',
        encoding="utf-8",
    )
    result = subprocess.run([str(native_binary), str(program)], cwd=tmp_path,
                            capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == ["Ada", "true", "hello"]

def test_native_result_assignment_rejects_unsupported_command(native_binary, tmp_path):
    program = tmp_path / "unsupported-result.modkec"
    program.write_text("increment(score) -> result\n", encoding="utf-8")
    result = subprocess.run([str(native_binary), str(program)], capture_output=True,
                            text=True, check=False)
    assert result.returncode == 1
    assert "does not return a capturable value" in result.stderr
