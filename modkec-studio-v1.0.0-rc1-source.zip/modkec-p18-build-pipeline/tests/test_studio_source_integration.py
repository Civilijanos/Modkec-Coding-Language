from pathlib import Path

import pytest

from studio import ModkecStudio

ROOT = Path(__file__).resolve().parents[1]


def test_all_studio_definitions_validate_as_one_set():
    summary = ModkecStudio._validate_source_definitions(ROOT)
    assert summary["application_settings"] == 8
    assert summary["theme_colors"] == 18
    assert summary["help_entries"] > 0
    assert summary["menu_declarations"] > 0
    assert summary["toolbar_declarations"] > 0
    assert summary["workbench_declarations"] > 0
    assert summary["shell_declarations"] == 3
    assert summary["starter_programs"] == 1
    assert summary["extension_registries"] == 1


@pytest.mark.parametrize(
    "relative_path",
    [
        "studio/application.modkec",
        "studio/theme.modkec",
        "studio/command_help.modkec",
        "studio/menus.modkec",
        "studio/toolbar.modkec",
        "studio/workbench.modkec",
        "studio/shell.modkec",
        "studio/starter.modkec",
        "bundled_extensions/registry.modkec",
    ],
)
def test_integration_validation_rejects_missing_source_file(tmp_path, relative_path):
    import shutil

    shutil.copytree(ROOT / "studio", tmp_path / "studio")
    shutil.copytree(ROOT / "bundled_extensions", tmp_path / "bundled_extensions")
    (tmp_path / relative_path).unlink()
    with pytest.raises((OSError, ValueError)):
        ModkecStudio._validate_source_definitions(tmp_path)


def test_integration_validation_rejects_invalid_theme(tmp_path):
    import shutil

    shutil.copytree(ROOT / "studio", tmp_path / "studio")
    shutil.copytree(ROOT / "bundled_extensions", tmp_path / "bundled_extensions")
    theme = tmp_path / "studio" / "theme.modkec"
    theme.write_text(theme.read_text(encoding="utf-8") + '\nstudio_color("unexpected", "#123456")\n', encoding="utf-8")
    with pytest.raises(ValueError, match="Unknown Studio theme color"):
        ModkecStudio._validate_source_definitions(tmp_path)
