import json
from pathlib import Path

import pytest

from modkec.studio_core import decode_workspace, encode_workspace, read_source, write_source


def test_workspace_round_trip_keeps_existing_folder(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    encoded = encode_workspace([workspace])
    assert json.loads(encoded)["format"] == "modkec-workspace"
    assert decode_workspace(encoded) == [workspace.resolve()]


def test_workspace_ignores_missing_folder_if_another_exists(tmp_path):
    existing = tmp_path / "existing"
    existing.mkdir()
    encoded = json.dumps({"format": "modkec-workspace", "version": 1,
                          "folders": [str(tmp_path / "missing"), str(existing)]})
    assert decode_workspace(encoded) == [existing.resolve()]


@pytest.mark.parametrize("payload", ["not json", "[]", '{"folders": "wrong"}',
                                      '{"format": "other", "folders": ["/"]}',
                                      '{"version": 999, "folders": ["/"]}',
                                      '{"folders": []}'])
def test_workspace_rejects_invalid_payloads(payload):
    with pytest.raises(ValueError):
        decode_workspace(payload)


def test_workspace_requires_at_least_one_existing_folder(tmp_path):
    with pytest.raises(ValueError, match="no existing folders"):
        decode_workspace(json.dumps({"folders": [str(tmp_path / "missing")]}))


def test_source_read_write_utf8(tmp_path):
    path = tmp_path / "sample.modkec"
    source = 'say("café")\n'
    write_source(path, source)
    assert read_source(path) == source
