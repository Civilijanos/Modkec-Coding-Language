#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
PYTHON_BIN="${PYTHON_BIN:-python3}"
# Use an isolated build environment so Linux distributions with externally
# managed Python installations do not require --break-system-packages.
BUILD_VENV="${MODKEC_BUILD_VENV:-.build-venv}"
if [ ! -x "$BUILD_VENV/bin/python" ]; then
  "$PYTHON_BIN" -m venv "$BUILD_VENV"
fi
"$BUILD_VENV/bin/python" -m pip install --upgrade pip
"$BUILD_VENV/bin/python" -m pip install -r packaging/requirements-build.txt
exec "$BUILD_VENV/bin/python" packaging/build_runtime.py
