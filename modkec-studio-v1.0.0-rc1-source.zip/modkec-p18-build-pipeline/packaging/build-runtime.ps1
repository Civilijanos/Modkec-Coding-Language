$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Test-Path '.build-venv/Scripts/python.exe')) { py -3 -m venv .build-venv }
$Python = Join-Path (Get-Location) '.build-venv/Scripts/python.exe'
& $Python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Could not upgrade pip in the isolated build environment.' }
& $Python -m pip install -r packaging/requirements-build.txt
if ($LASTEXITCODE -ne 0) { throw 'Could not install the build-time PyInstaller dependency.' }
& $Python packaging/build_runtime.py
if ($LASTEXITCODE -ne 0) { throw 'Standalone runtime build failed.' }
