"""Build a per-OS standalone Modkec Studio app with bundled Python and Tcl/Tk.

Run this on the target OS with Python 3 + Tkinter and PyInstaller installed.
PyInstaller does not cross-compile: build Windows on Windows, macOS on macOS,
and Linux on Linux. Output is a self-contained onedir app archive.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGING = ROOT / "packaging"
BUILD = ROOT / "release-build"
DIST = BUILD / "dist"
WORK = BUILD / "work"
RELEASE = ROOT / "release"
APP_NAME = "ModkecStudio"

DATA_DIRS = (
    "studio",
    "modkec",
    "examples",
    "bundled_extensions",
    "docs",
    "bin",
    "native",
)
DATA_FILES = (
    "studio.py",
    "run_modkec.py",
    "sitecustomize.py",
    "README.md",
    "CHANGELOG.md",
    "LICENSE",
)


def platform_tag() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower().replace(" ", "_")
    aliases = {"amd64": "x86_64", "x64": "x86_64", "arm64": "aarch64"}
    machine = aliases.get(machine, machine)
    return f"{system}-{machine}"


def main() -> int:
    try:
        import tkinter
        from tkinter import ttk  # noqa: F401
        import PyInstaller.__main__
    except Exception as exc:
        print("Runtime build prerequisites are missing.", file=sys.stderr)
        print("Use Python 3 with Tkinter, then install packaging/requirements-build.txt", file=sys.stderr)
        print(f"Details: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2

    # Fail before building if the local Python cannot initialize Tcl/Tk.
    try:
        tk = tkinter.Tcl()
        print(f"Build interpreter: Python {platform.python_version()}, Tcl/Tk {tk.eval('info patchlevel')}")
    except Exception as exc:
        print(f"Tkinter/Tcl initialization failed: {exc}", file=sys.stderr)
        return 3

    for required in (ROOT / "studio" / "entry.modkec", ROOT / "studio" / "desktop.modkec", ROOT / "modkec" / "engine.py"):
        if not required.is_file():
            print(f"Source package is incomplete: {required.relative_to(ROOT)}", file=sys.stderr)
            return 4

    if BUILD.exists():
        shutil.rmtree(BUILD)
    if RELEASE.exists():
        # Only remove the generated runtime archive for this exact platform.
        target_archive = RELEASE / f"{APP_NAME}-{platform_tag()}.zip"
        if target_archive.exists():
            target_archive.unlink()
    DIST.mkdir(parents=True, exist_ok=True)
    WORK.mkdir(parents=True, exist_ok=True)
    RELEASE.mkdir(parents=True, exist_ok=True)

    args = [
        str(PACKAGING / "frozen_entry.py"),
        "--noconfirm", "--clean", "--onedir", "--windowed",
        "--name", APP_NAME,
        "--distpath", str(DIST),
        "--workpath", str(WORK),
        "--specpath", str(BUILD),
        "--collect-submodules", "modkec",
        "--hidden-import", "tkinter.filedialog",
        "--hidden-import", "tkinter.messagebox",
        "--hidden-import", "tkinter.simpledialog",
        "--hidden-import", "tkinter.ttk",
        "--hidden-import", "tkinter.colorchooser",
    ]
    for directory in DATA_DIRS:
        source = ROOT / directory
        if source.is_dir():
            args.extend(["--add-data", f"{source}{os.pathsep}{directory}"])
    for filename in DATA_FILES:
        source = ROOT / filename
        if source.is_file():
            args.extend(["--add-data", f"{source}{os.pathsep}."])

    print(f"Building standalone runtime for {platform_tag()} (build must run on this OS)...")
    PyInstaller.__main__.run(args)

    built = DIST / APP_NAME
    if not built.exists():
        # macOS windowed builds may be emitted as an application bundle.
        built = DIST / f"{APP_NAME}.app"
    if not built.exists():
        print("PyInstaller completed but its application bundle was not found.", file=sys.stderr)
        return 5

    # Run a bundled-runtime check without opening the GUI. On GUI-less Linux this
    # confirms Python/Tcl imports; it does not require creating a Tk window.
    executable = built / APP_NAME
    if platform.system() == "Windows":
        executable = built / f"{APP_NAME}.exe"
    elif platform.system() == "Darwin" and built.suffix == ".app":
        executable = built / "Contents" / "MacOS" / APP_NAME
    if not executable.is_file():
        print(f"Could not find expected app executable: {executable}", file=sys.stderr)
        return 6

    with tempfile.TemporaryDirectory(prefix="modkec-runtime-check-") as check_dir:
        report_file = Path(check_dir) / "runtime-check.json"
        check_env = os.environ.copy()
        check_env["MODKEC_RUNTIME_CHECK_FILE"] = str(report_file)
        check = subprocess.run([str(executable), "--runtime-check"], capture_output=True, text=True, timeout=30, env=check_env)
        if report_file.is_file():
            report = report_file.read_text(encoding="utf-8")
            print(report)
        else:
            report = ""
            print(check.stdout.strip())
        if check.returncode != 0 or '"ok": true' not in report.lower():
            print(check.stderr.strip(), file=sys.stderr)
            print("Bundled runtime check failed; refusing to create release archive.", file=sys.stderr)
            return 7

    archive = RELEASE / f"{APP_NAME}-{platform_tag()}.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for path in sorted(built.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(built.parent))
    print(f"Standalone runtime created: {archive}")
    print("This archive includes the runtime and Tk/Tcl libraries; end users do not install Python separately.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
