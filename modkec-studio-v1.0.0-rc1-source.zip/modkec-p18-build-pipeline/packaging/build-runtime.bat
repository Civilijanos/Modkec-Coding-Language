@echo off
setlocal
cd /d "%~dp0\.."
if not exist .build-venv\Scripts\python.exe py -3 -m venv .build-venv
if errorlevel 1 goto :failed
.build-venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :failed
.build-venv\Scripts\python.exe -m pip install -r packaging\requirements-build.txt
if errorlevel 1 goto :failed
.build-venv\Scripts\python.exe packaging\build_runtime.py
if errorlevel 1 goto :failed
exit /b 0
:failed
echo Runtime build failed. See the error above.
pause
exit /b 1
