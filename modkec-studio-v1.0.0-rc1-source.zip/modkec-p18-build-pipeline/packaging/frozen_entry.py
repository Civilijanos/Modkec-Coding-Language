"""Frozen executable entry point for the standalone Modkec Studio runtime."""
from __future__ import annotations

import json
import os
import runpy
import sys
from pathlib import Path


def bundled_root() -> Path:
    # PyInstaller --onedir places bundled data in _MEIPASS (normally _internal).
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS).resolve()
    return Path(__file__).resolve().parents[1]


def runtime_check(root: Path) -> int:
    try:
        import tkinter
        from tkinter import ttk  # noqa: F401
        tk = tkinter.Tcl()
        tk_version = tk.eval("info patchlevel")
        required = [
            root / "studio" / "entry.modkec",
            root / "studio" / "desktop.modkec",
            root / "studio" / "bootstrap.modkec",
            root / "modkec" / "engine.py",
            root / "modkec" / "translator.py",
            root / "studio.py",
        ]
        missing = [str(path.relative_to(root)) for path in required if not path.is_file()]
        report = {
            "ok": not missing,
            "python": sys.version.split()[0],
            "tkinter": str(tkinter.TkVersion),
            "tcl_tk": tk_version,
            "bundled_root": str(root),
            "missing_files": missing,
            "frozen": bool(getattr(sys, "frozen", False)),
        }
        rendered = json.dumps(report, indent=2)
        report_path = os.environ.get("MODKEC_RUNTIME_CHECK_FILE")
        if report_path:
            Path(report_path).write_text(rendered, encoding="utf-8")
        else:
            print(rendered)
        return 0 if not missing else 2
    except Exception as exc:
        rendered = json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, indent=2)
        report_path = os.environ.get("MODKEC_RUNTIME_CHECK_FILE")
        if report_path:
            Path(report_path).write_text(rendered, encoding="utf-8")
        else:
            print(rendered)
        return 3


def main() -> int:
    root = bundled_root()
    if "--runtime-check" in sys.argv[1:]:
        return runtime_check(root)

    # All source files are placed beside the frozen runtime's _internal modules.
    sys.path.insert(0, str(root))
    entry = root / "studio" / "entry.modkec"
    if not entry.is_file():
        print(f"Modkec Studio runtime is incomplete: missing {entry}", file=sys.stderr)
        return 2
    sys.argv = [str(root / "run_modkec.py"), "--quiet", str(entry)]
    runpy.run_path(str(root / "run_modkec.py"), run_name="__main__")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
