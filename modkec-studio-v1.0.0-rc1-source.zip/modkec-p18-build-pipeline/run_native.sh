#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec ./native/run.sh "$@"
