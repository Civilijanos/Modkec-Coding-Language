# P16 — Embedded desktop host

The desktop implementation is now stored in `studio/desktop.modkec` inside an explicit `python()` block. `studio/entry.modkec` loads that source and runs it through the Modkec engine. The shell and batch launchers remain operating-system startup shims.

## What this achieves

- The normal launch path is Modkec entry → Modkec desktop source → embedded Python/Tkinter host.
- The UI source is in the `.modkec` project instead of being loaded from `studio.py` at runtime.
- Existing UI behavior is retained by moving the current implementation rather than rewriting it all at once.

## What it does not achieve yet

- Python is still the execution engine for embedded Python blocks.
- Tkinter must be available in that Python runtime.
- `modkec/engine.py`, `modkec/translator.py`, extension services, BeatMaker, and project-file services remain Python modules.
- `studio.py` remains as a compatibility copy and must not be treated as the authoritative desktop source during this stage.

A truly no-install release requires bundling a compatible Python/Tk runtime for each target operating system or replacing these services with a native Modkec runtime. One universal bundled runtime cannot simply be copied across Windows and Linux.
