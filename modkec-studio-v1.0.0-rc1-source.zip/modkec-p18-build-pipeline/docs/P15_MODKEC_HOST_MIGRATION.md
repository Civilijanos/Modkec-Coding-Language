# P15 Modkec-owned startup and host-service registry

P15 makes the startup contract and host-service map source-controlled Modkec files. `studio/entry.modkec` declares the desktop host, version, and mode, then explicitly invokes the Python compatibility bridge. `studio/host_services.modkec` maps the major Studio capabilities to the current host implementations.

`modkec/studio_launch.py` is the compatibility boundary. Before launching the GUI it validates the bootstrap manifest, validates every declared host source, rejects duplicate service names and unsafe paths, and checks that the selected host exists inside the project. This makes future service-by-service migration explicit and testable rather than silently changing the launcher.

## Current boundary

The UI and its event callbacks remain in `studio.py`; the language engine, translator, extension registry, Beatmaker, and project-file helpers remain Python modules. They are declared in the Modkec host-service registry but are not yet reimplemented in Modkec. The Python interpreter and Tkinter are still required. The native C kernel is not yet the Studio host and does not execute embedded Python blocks.

## Migration rule

A service is only considered migrated when its Modkec implementation replaces the Python adapter and regression tests verify the same behavior. Keep the existing Python implementation as a fallback until those tests pass. Do not describe this transitional package as fully self-hosted or dependency-free.
