# P18 — Per-OS standalone build pipeline

P18 adds a GitHub Actions matrix to build and validate the standalone runtime on native runners for Linux x86_64, Windows x86_64, and macOS x86_64. Run it from the repository's **Actions → Build standalone Modkec Studio → Run workflow** page, or push a `v1.0.0-*` tag. Each successful job uploads its OS-specific ZIP as a workflow artifact.

The local build launchers now use an isolated `.build-venv` so they do not install PyInstaller into the system Python environment. Linux CI installs the matching system Tkinter package and uses the distribution Python that owns it. The Linux job also performs a short GUI startup smoke test under Xvfb.

## Important limitation

This workflow definition is committed to the source archive, but this environment cannot contact package repositories or start remote GitHub Actions. Therefore the OS-specific archives have **not** been built here. The workflow must run successfully on the actual target runners, and the resulting archives must be tested on clean target machines before they can be called finished 1.0.0 installers. The current matrix targets x86_64 only; ARM64 packages require additional matrix entries and native runners.
