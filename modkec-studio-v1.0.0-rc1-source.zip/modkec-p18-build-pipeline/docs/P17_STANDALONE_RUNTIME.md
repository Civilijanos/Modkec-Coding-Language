# P17 — Standalone Python/Tkinter runtime

P17 adds a reproducible, per-operating-system build for a distributable Modkec Studio application. The generated app bundles the Python interpreter, imported modules, Tkinter, Tcl/Tk, and Modkec source assets. End users should not need a separate Python or Tkinter installation.

## Build on each target OS

Builds must run on the operating system they target. PyInstaller does not provide a general cross-compiler for these desktop bundles.

- **Linux:** install Python 3, its Tkinter package (often named `python3-tk`), and build tools; run `packaging/build-runtime.sh`.
- **Windows:** install Python 3 from python.org with Tcl/Tk selected; run `packaging/build-runtime.bat` or `packaging/build-runtime.ps1`.
- **macOS:** install a supported Python 3 distribution that includes Tkinter; run `packaging/build-runtime.sh` from Terminal.

The build script installs PyInstaller as a build-time tool, verifies Tkinter/Tcl, packages the app in one-directory mode, executes the frozen app's `--runtime-check`, and creates a ZIP under `release/` tagged for the current OS and architecture. The build machine needs internet access the first time to download PyInstaller. That is a build-time requirement only.

## Runtime validation

The generated executable supports `--runtime-check`. It reports the bundled Python version, Tkinter/Tcl versions, and required source assets without opening the GUI. The build fails instead of publishing the ZIP if this check fails.

The bundle is deliberately one-directory rather than one-file: it is easier to inspect, faster to start, and more reliable for Tcl/Tk resource discovery. The ZIP contains all files needed by that app bundle.

## Platform boundaries and remaining caveats

This repository now contains the builder and checks, not prebuilt Windows and macOS binaries. Native runtime bundles are OS- and architecture-specific and must be built on Windows/macOS respectively. Linux bundles can still depend on the target distribution's system C library and a few desktop libraries; the Python/Tk/Tcl runtime itself is bundled, but no single Linux binary is guaranteed to run on every Linux distribution. Test the produced archive on a clean machine or VM for every OS/architecture you intend to support.

P17 packages the existing Python/Tkinter implementation into a standalone runtime. It does not make the interpreter or all Studio subsystems native Modkec; it removes the end user's need to install Python separately.
