# P14 native migration status

This is an incremental engineering build, not a completed self-hosted release.

## Verified in this build

- A statically linked Linux x86-64 executable is included at `bin/modkec-native`.
- The native kernel runs the documented core subset without Python: `say`, `set`, `get`, `delete`, `increment`, `decrement`, `comment`, `stop`, and `import(core)`.
- Unsupported commands and modules fail with a diagnostic instead of being silently ignored.
- Native tests cover core output, unsupported modules, missing files, non-finite values, oversized values, and large numeric values.
- The full Python test suite last completed with 231 passed, 6 GUI tests skipped due to unavailable display, and 7 subtests passed.

## Not yet delivered

- There is no prebuilt Windows executable in this ZIP. `native/run.bat` will explain this and stop; it does not pretend the Windows runtime exists.
- The native kernel does not implement the full Modkec language or its modules.
- The Studio GUI, editor, translator, extensions, Visele preview, BeatMaker, and broader engine are still Python/Tkinter-based. `run_studio.sh` and `run_studio.bat` therefore still require Python and Tkinter.
- This ZIP is not yet universal, dependency-free on both platforms, or fully self-hosted.

## Required path to the target

1. Build and test a Windows native executable using a Windows-targeting C toolchain, then include both platform binaries.
2. Expand the native runtime behind conformance tests that compare supported behavior against the existing engine; keep unsupported features explicit until parity exists.
3. Migrate Studio application behavior and remaining services into `.modkec` modules, not just declarative UI descriptions.
4. Implement a native desktop host for the required UI capabilities on both platforms, or define a bundled cross-platform host that does not require a separate user install.
5. Run the full feature/regression suite on Linux and Windows before claiming self-hosting or universal support.

## Latest native increment: scalar result assignment

The native kernel now supports `command(...) -> variable` for `say`, `get`, `file_exists`, and `read_file`. Captured file contents are limited to the native scalar value buffer; larger files produce an explicit error. Other commands with `->` are rejected before execution until their return semantics are implemented. This does not yet implement user-defined action return values or structured list/object values.

## Latest native increment: scalar result assignment

The native kernel now supports `command(...) -> variable` for `say`, `get`, `file_exists`, and `read_file`. Captured file contents are limited to the native scalar value buffer; larger files produce an explicit error. Other commands with `->` are rejected before execution until their return semantics are implemented. This does not yet implement user-defined action return values or structured list/object values.
