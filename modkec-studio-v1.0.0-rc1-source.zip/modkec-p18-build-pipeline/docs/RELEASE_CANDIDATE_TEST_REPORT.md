# Modkec Studio 1.0.0 release-candidate test report

Candidate basis: P18 source/build pipeline. This is a source-level release candidate, **not the final standalone 1.0.0 distribution**.

## Checks run in the available Linux environment

- Automated suite under Xvfb: **253 passed, 7 subtests passed**.
- Modkec bootstrap check: passed; reports version `v1.0.0-p18`, entry point `studio/entry.modkec`, 13 required source files, and host requirements `modkec-engine`, `python-host`, `tkinter-host`.
- Native runtime shell tests: passed.
- Python compile check for runtime, Studio, and packaging sources: passed.
- GUI launch smoke test under Xvfb: stayed running until the 10-second timeout, consistent with a GUI that did not immediately crash.
- Source archive ZIP integrity check: passed.

## Checks not completed

- PyInstaller is not installed in this environment and network access to package repositories is unavailable. No standalone runtime archive was produced here.
- The Windows and macOS test/build jobs have not run.
- A clean-machine installation/launch test has not run on any target OS.
- ARM64 targets are not included in the current workflow.
- This architecture still uses a Python/Tkinter host internally. The packaged runtime is intended to bundle those dependencies, not eliminate Python from the implementation.

## Release gate

Do not label the release final until the revised GitHub Actions matrix completes successfully on all three OS targets, the generated archives are downloaded and launched on clean systems, core Studio features are checked in the bundled runtime, and the final archives are published with checksums. The workflow itself is prepared but has not been remotely executed in this environment.
