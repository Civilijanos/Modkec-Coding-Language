# P14: Modkec-first startup bridge

The normal Studio launchers now enter through `studio/entry.modkec` rather than invoking `studio.py` directly.

The entry file uses the engine's existing explicit Python interoperability syntax:

```modkec
import(py)
python()
# host bridge code
end_python()
```

Its Python block resolves `studio.py` relative to the project root and runs the existing GUI host. This keeps the current interface and behavior intact while establishing a Modkec-owned startup path.

## Current limits

- The current Modkec engine and the embedded-Python bridge still run on Python.
- The GUI, translator, and most application behavior remain in Python.
- The bundled C native kernel does not implement embedded Python and is not used by this desktop launcher.
- This step does not remove Python as a system requirement.

## Verification

- The full automated suite passes in the available environment; GUI tests require a display and are skipped when none is available.
- `run_modkec.py --bootstrap-check` validates the Modkec entry and all declared source files.
- The Linux native-kernel smoke test remains intact.
