#!/usr/bin/env python3
"""Run Modkec source or validate the Studio bootstrap manifest."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.pycache_prefix = str(ROOT / ".pytest_cache" / "pycache")
sys.path.insert(0, str(ROOT))
from modkec import ModkecEngine, ModkecError
from modkec.bootstrap import check_bootstrap


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a Modkec program")
    parser.add_argument("file", nargs="?", help="Path to a .modkec source file")
    parser.add_argument("--bootstrap-check", action="store_true", help="Validate Studio bootstrap and required source files without opening the GUI")
    parser.add_argument("--quiet", action="store_true", help="Suppress normal completion details (errors are still shown)")
    args = parser.parse_args()
    if args.bootstrap_check:
        try:
            result = check_bootstrap(ROOT)
            print(f"[Modkec bootstrap] {result['version']}: OK")
            print(f"[Modkec bootstrap] Entry point: {result['entry']}")
            print(f"[Modkec bootstrap] Required source files: {result['source_count']}")
            print(f"[Modkec bootstrap] Host requirements: {', '.join(result['capabilities'])}")
            return 0
        except (OSError, ValueError) as exc:
            print(f"[Modkec bootstrap] Error: {exc}")
            return 1
    if not args.file:
        parser.error("provide a source file or use --bootstrap-check")
    path = Path(args.file)
    try:
        source = path.read_text(encoding="utf-8")
        engine = ModkecEngine(source_name=str(path.resolve()))
        output = engine.run(source)
        if output and not args.quiet:
            print(output)
        if not args.quiet:
            print(f"\n[Modkec] Finished. Variables: {engine.variables}")
            if engine.imported_modules:
                print(f"[Modkec] Imported modules: {', '.join(sorted(engine.imported_modules))}")
        return 0
    except (OSError, ModkecError) as exc:
        print(f"[Modkec] Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
