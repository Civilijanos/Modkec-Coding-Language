# Modkec Studio v1.0.0-p14 — native runtime migration preview

**v1.0.0-p9 adds reusable source modules to the Modkec runtime.** `include("path/to/library.modkec")` loads action and custom-command declarations into the current engine so larger projects can share code without copying it. Includes resolve relative to the including source file, load only once, support nested includes, detect cycles, require the `.modkec` extension, and reject executable top-level statements to prevent hidden side effects. See `examples/source_modules_demo.modkec` and `examples/library/numbers.modkec`. Studio's UI host and language engine are still implemented in Python; this is a runtime capability step, not yet a Python-free application.

**Modkec** means **Modular Development Kit for Extensible Coding**. This is an early, runnable prototype built around the original starter command list. Earlier versions added button-specific Visele actions, live named-text updates, native scientific math evaluation, and a native website builder. It is still not a production-ready language or a complete implementation of every listed module.

## Run on Linux (default)

Python 3.10+ is recommended. Studio uses Python's built-in Tkinter library; no pip packages are needed.

1. Extract the ZIP.
2. Open a terminal in the extracted `modkec` folder.
3. Run:

```bash
./run_studio.sh
```

If the launcher is not executable, run `sh run_studio.sh` instead. If Tkinter is missing on Debian/Ubuntu/Linux Mint:

```bash
sudo apt install python3-tk
```

You can also start the IDE directly with `python3 studio.py`.

If Tkinter is missing:

```bash
sudo apt install python3-tk
```

Run a source file from the project folder:

```bash
python3 run_modkec.py examples/first_program.modkec
```

Translate a source file to Python, JavaScript, Lua, Luau, C, HTML, or all targets:

```bash
python3 translate_modkec.py examples/first_program.modkec python
python3 translate_modkec.py examples/first_program.modkec javascript
python3 translate_modkec.py examples/first_program.modkec lua
python3 translate_modkec.py examples/first_program.modkec luau
python3 translate_modkec.py examples/first_program.modkec c
python3 translate_modkec.py examples/first_program.modkec html
python3 translate_modkec.py examples/first_program.modkec all
python3 translate_modkec.py examples/first_program.modkec python --export output/first_program.py
python3 translate_modkec.py examples/first_program.modkec all --export output/all-targets.zip
```

## Expanded language features in v0.7

- Actions can accept parameters: `action(double, value) ... end()` and `call(double, 21) -> answer`.
- Action parameters are local to the call and restored afterward.
- Expressions support safe built-in functions such as `len`, `str`, `int`, `float`, `bool`, `abs`, `min`, `max`, `round`, `sorted`, `sum`, `any`, `all`, and `range`.
- Expressions support list/object literals, indexing, membership tests (`in`, `not in`), and comparisons.
- `set(items[0], value)` updates an indexed list or object entry.
- Action recursion has a depth limit to prevent runaway recursion.
- See `examples/functions_demo.modkec` for a working example.

## Studio

The Studio interface is a VS Code-inspired workbench: a vertical activity rail, project explorer with example files, editor tab strip, syntax highlighting, line numbers, a bottom panel for output and command reference, a run control, and a blue status bar. The current desktop host still uses Tkinter, so Python 3 and Tkinter are required until the planned runtime migration is complete. The `.sh` and `.bat` launchers remain the supported entry points.

- Edit multiple files at once using the document tab strip; New, Open, Save, Save As, Save All, and per-tab Close are available. Files with source-code extensions inside the Modkec Studio project show a safety warning and have Auto Save disabled; save those files manually.
- Run with the Run button or F5. Native programs use a separate console with live output and an input field for stdin-based programs. Some compiled languages still require a build step before the console opens.
- The project explorer loads nested folders on expansion; `.git`, caches, virtual environments, and `node_modules` are hidden from the tree.
- Choose Python, JavaScript, Lua, Luau, C, HTML, or all targets, then Translate or Export.
- Command descriptions are visible by default and can be toggled in Settings.
- Run a program that creates Visele elements to open the visual preview, or use the Visele Preview button.

## Core commands (no import required)

- `say("Hello!")` displays a value.
- `ask("Your name?") -> name` asks for input.
- `set(score, 100)` assigns or updates a variable.
- `store(score, 100)` assigns and persists a value in `.modkec_store.json` beside the saved script (or in the current directory for an unsaved/CLI script).
- `get(score)` prints a variable or stored value; `get(score) -> result` copies it to another variable.
- `delete(score)` removes a variable.
- `increment(score, 1)` and `decrement(score, 1)` update numeric variables.
- `type_of(value) -> kind` reports a value type.
- `wait(2)` pauses for the requested seconds (capped at 30 seconds in this prototype).
- `stop()` ends the current program.
- `import(logic)` loads a module for the current program. Dependencies are loaded automatically; for example, `import(media)` also loads `visele`. Repeated imports are ignored, and circular dependencies produce an error.
- `include("library/helpers.modkec")` loads reusable `action()` and `command()` definitions from another Modkec source file. Includes can be nested and are resolved relative to the file that contains the include. Module files may contain imports, includes, declarations, comments, and blank lines; executable top-level statements are rejected. See `examples/source_modules_demo.modkec`.
- `run("intro")` runs a named action or a relative script path.
- `comment("Player setup")` is an explanatory note.
- `translate(python)` emits translated code to the output panel. Supported targets are Python, JavaScript, Lua, Luau, C, and HTML (subject to the translation features implemented for each target). Saving translated code is done through Studio's Export feature or the CLI's `--export` option.

Actions use the original block style:

```text
action(win)
    say("You win!")
end()
if(score > 10)=t, do(win)
```

## Modules and commands

### Visele — `import(visele)`

`p`, `rect`, `square`, `circle`, `line`, `c1`, `c2`, `c3`, `c4`, `hex`, `rgb`, `text`, `image`, `button`, `update_text`, `resize`, `move`, `hide`, `show`, `remove`, `interact`, `clear`, `layer`, `opacity`.

Visele creates visual instructions that Studio can preview. The preview draws pixels, shapes, lines, text, and Tk-supported image formats such as PNG, GIF, PPM, and PGM. Use `image("assets/logo.png", 20, 20, 160, 90)` to display an image; missing or unsupported images show an error placeholder. Use `button("7", 10, 10, press_key)` to bind a button to a named action; its label is passed as the action's first parameter. The older shared `on(click) do(action_name)` event remains supported. Use `text("0", 10, 20, "display")` to name a text element and `update_text("display", expression)` to change it during interaction. `interact(t) run()` remains supported.

Example: `python3 run_modkec.py examples/visele_demo.modkec` opens a visual preview only when run through Studio; in the CLI, visual commands are recorded without opening a window.

### Calculations — `import(calculator)`

`add`, `subtract`, `multiply`, `divide`, `mod`, `power`, `round`, `floor`, `ceil`, `absolute`, `min`, `max`, `random`, `percentage`, `sqrt`, `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `ln`, `log`, `exp`, `factorial`, `evaluate`.

`evaluate("sin(30) + 2^3")` safely evaluates math expressions. Supported constants include `pi`, `e`, and `Ans`. Trigonometric functions use degrees when `angle_mode` is set to `"DEG"`; otherwise they use radians. The `text` module also includes `drop_last(text)` for editing expressions.

Example: `add(5,10) -> result`

### Logic — `import(logic)`

`if`, `else`, `equal`, `greater`, `less`, `and`, `or`, `not`, `repeat`, `while`, `break`, `on`, `wait_until`.

Example: `if(score > 10)=t, do(win)` or `repeat(5) do(action_name)`.

### Actions and functions — `import(actions)`

`action`, `do`, `return`, `input`, `call`, `event`, `trigger`, `cancel`, plus `end()` to close an action block. Actions can be defined with `action(name)` and closed with `end()`.

### Data — `import(data)`

`list`, `append`, `remove_item`, `count`, `contains`, `sort`, `reverse`, `object`, `key`, `save`, `load`.

### Text — `import(text)`

`join`, `length`, `upper`, `lower`, `replace`, `contains_text`, `split`, `trim`, `number`, `format`.

### Files — `import(files)`

`read_file`, `write_file`, `file_exists`, `copy_file`, `rename_file`, `list_files`, `create_folder`, `dimp`. `dimp("data.json") -> data` imports JSON data (or returns raw text if it is not valid JSON) and requires `import(files)`.

**Security:** file and network commands can access resources on the machine or network. Only run scripts you trust. A permission prompt/sandbox system is still a planned improvement.

### Web — `import(web)`

`open_url`, `request`, `get_page`, `send`, `listen`, `timer`. `send(url, data, optional_content_type)` performs an HTTP POST. `listen()` still needs a defined event-source/server API and returns a clear error instead of pretending to listen.

### Animation and audio — `import(media)`

`animate`, `fade`, `rotate`, `stop_animation`, `play_sound`, `stop_sound`, `volume`, `play_video`. Visele preview runs timed property animations for visual elements. `play_sound(path)` uses available OS players such as `paplay`, `aplay`, `ffplay`, or `afplay`; Windows supports WAV playback through its standard sound API. `play_video(path)` uses `ffplay` or the system default player. Relative media paths resolve beside the saved Modkec script. `volume(level)` sets software volume for players that support it, not guaranteed system-wide volume. `import(animation)` is accepted as an alias for `import(media)`.

```text
import(visele)
import(media)
rect(20, 40, 80, 60) hex(7C3AED)
animate("x", 20, 420, 2)
fade(100, 15, 1.5)
rotate(90, 1)
run()
```

`animate(property, from, to, seconds)` animates the most recently created element. Supported properties are `x`, `y`, `w`, `h`, `r`, and `opacity`. To select an element by its name or text, use `animate(target, property, from, to, seconds)`. `fade(from_opacity, to_opacity, seconds)` fades the last element; `fade(target, from_opacity, to_opacity, seconds)` selects a target. Opacity is 0–100. `rotate(degrees, seconds)` rotates the last element, or `rotate(target, degrees, seconds)` selects a target. Targets may be `"last"`, a zero-based element index, or a matching visual name/text. `stop_animation()` stops all running tracks; `stop_animation(target)` stops tracks for that target. These animations run in Studio's Visele preview.

### Translation tools — `import(translation)`

`check()` performs basic action-block structure checks, and `explain()` lists a short description of each command in the current script. These are early helper functions, not a complete compiler or static analyzer.

## Translation status

The translator supports core commands, actions, simple conditions, arithmetic, and some text operations across Python, JavaScript, Lua, and Luau. C now supports basic action definitions and conditional action calls, with some limitations around return values and advanced data types. HTML can embed translated JavaScript for simple action/condition programs; basic Visele drawing commands use static HTML. Some Visele/media operations are emitted as comments noting that a target-language runtime is required. `translate(all)` shows every target and reports unavailable translations per target; exporting all targets creates a ZIP. This is an early transpiler, not a promise of perfect semantic equivalence.

## Beatmaker (v0.9 development)

Use **Program → Beatmaker** to create a 16-step rhythm with kick, snare, hi-hat, and bass tracks. It synthesizes audio using the Python standard library and exports WAV files without a pip package. Preview playback uses an available system audio player; if none is found, export the WAV and open it with an audio player installed on the system.

Compact Kit is available as an optional partnered extension. It ships with the application package but is not installed or activated automatically. Open **Extensions → Manage Extensions**, select Compact Kit under Partnered Extensions, and choose **Install / Uninstall partnered extension**. After installation, use `import(compact_kit)` in a Modkec script. Its template commands return editable Modkec source as text for you to copy into your script. The older [`docs/compact-kit-fork.md`](docs/compact-kit-fork.md) remains available for people who want to customize the feature in their own fork.

## Extensions and language support (v0.9.5 development)

Open **Extensions → Manage Extensions** to view native language support alongside translation/export packs for Python, JavaScript, Lua, Luau, C, and HTML. Native language entries are built into Studio; the runtime/compiler still must be installed on the operating system. Translation packs enable the existing translator; they do not add a new translator by themselves. Target-pack manifests are stored in the user's Modkec configuration directory.

Settings include **Change Studio background** and **Change button color**. Text color is chosen automatically for the selected background/button color. Python bytecode caches are redirected into `.pytest_cache/pycache` rather than being placed next to source files.

### Partnered extensions

Partnered extensions are listed in `modkec/extensions.py` as metadata, separate from installed extension packages. Bundled packages are installed only after the user chooses to install them. The initial catalog entry is Compact Kit; it uses the same validated package format and API as community extensions.

### Community command extensions

A community extension is a local ZIP containing `modkec-extension.json` and its Python entrypoint at the archive root. It declares `id`, `name`, `version`, `api_version: 1`, `entrypoint`, and `commands`. The entrypoint defines `register(api)` and registers handlers with `api.register_command("command_name", handler, description)`. Handlers receive `(context, args)`, where `args` are evaluated Modkec values, and return a value or `None`. The context exposes `variables`, `output`, `project_directory`, `evaluate(expression)`, `say(value)`, and `set_variable(name, value)`.

The `examples/community_extension_template` folder is a working sample. ZIP its **contents** so the manifest sits at the archive root. Install through **Extensions → Manage Extensions → Install local extension ZIP…**, then use `import(sample-math)` in Modkec code to enable the sample `double()` command. Extension Python code runs with the same operating-system permissions as Studio; only install source you have reviewed. Package file count, size, paths, and file types are validated, but extensions are not sandboxed. The GitHub fork browser discovers forks but does not automatically install their code. Translation support remains limited to each translator's implemented syntax.

## Examples

- `examples/first_program.modkec` — core commands and a conditional action.
- `examples/visele_demo.modkec` — shapes, colors, text, a button, and interaction preview.
- `examples/calculator_demo.modkec` — arithmetic and result variables.
- `examples/dimp_demo.modkec` — importing a JSON file with `dimp()`.

## Tests

Run the full automated suite from the project root. On Linux, `./run_tests.sh` automatically starts a virtual X display with Xvfb when no display is available, so the Tkinter GUI smoke tests can run in headless CI. Both direct invocations are also supported when a display is available:

```bash
pytest -q
python3 -m pytest -q
python3 -m compileall -q modkec studio.py run_modkec.py translate_modkec.py
```

The test suite includes interpreter behavior, invalid syntax and errors, expression safety limits, module imports, Visele instruction recording and preview-window construction, extension package validation, translation/export, persistent storage, website building, beatmaker WAV output, Studio startup, editor interaction, program execution from the editor, and search-highlight cleanup. Automated tests do not replace manual GUI smoke tests on each supported operating system. See [`docs/pre-1.0-release-checklist.md`](docs/pre-1.0-release-checklist.md) for the remaining release gate.

## License

MIT. See `LICENSE`.

## Windows setup (optional)

1. Install Python 3 for Windows from <https://www.python.org/downloads/windows/>. During setup, enable **Add python.exe to PATH**. Tkinter is normally included with the standard Python installer.
2. Extract the ZIP file to a normal folder (for example, your Desktop or Downloads folder).
3. Double-click `run_studio.bat` to open Modkec Studio.
4. Open an example from the `examples` folder and click **Run**.

The Windows launchers are `run_studio.bat`, `run_modkec.bat`, and `translate_modkec.bat`. Linux is the default platform for this package; Windows launchers are included for convenience. For example, from Command Prompt in the extracted folder, run:

```bat
run_modkec.bat examples\first_program.modkec
translate_modkec.bat examples\first_program.modkec --target python
```

This is a Windows-compatible source package, not a compiled `.exe`; Python 3 must be installed. The same Modkec prototype limitations listed above still apply.

## Input with `ask()`

In Studio, `ask("Prompt") -> answer` opens a native input dialog instead of reading from the terminal. Plain integer and decimal answers are converted to numbers, so a response such as `7` can be compared with a numeric variable. Other responses remain text. Cancelling the dialog returns an empty string.

## Web projects (v0.7.2)

Modkec can now assemble a web project from one `.modkec` source file and translate it to either a complete HTML page or a JavaScript bundle. This is useful for websites that need HTML structure, CSS styling, and browser-side interaction.

```text
title("My Website")

html()
<main><h1 id="heading">Hello from Modkec</h1><button id="change">Change</button></main>
end_html()

style()
body { font-family: system-ui, sans-serif; }
end_style()

script()
document.querySelector("#change").addEventListener("click", () => {
  document.querySelector("#heading").textContent = "Updated";
});
end_script()
```

Use `html() ... end_html()` for markup, `style() ... end_style()` for CSS, and `script() ... end_script()` for JavaScript. `title("...")` sets the page title. In Studio, select **HTML** or **JavaScript** as the translation target. You can also use the CLI:

```sh
python translate_modkec.py examples/web_project.modkec html --export web-example.html
python translate_modkec.py examples/web_project.modkec javascript --export web-example.js
```

The HTML target outputs a self-contained page. The JavaScript target creates the page markup and stylesheet in the browser, then runs the script block; load it after the document body exists. Content inside the three blocks is target-language code passed through as-is, so this feature does not mean Modkec commands can be used directly inside HTML, CSS, or JavaScript blocks. The broader native web API remains future work.

## Custom commands (v0.8.0)

Create a command with `command(name, optional, parameters...)`, close it with `end()`, and call it directly by name. The body uses Modkec commands by default.

```text
command(greet, name)
    say("Hello!")
    say(name)
end()

greet("Ada")
```

Studio's **Program → Create Custom Command…** menu item inserts a command template into the current editor. Custom command names cannot overwrite built-in or module commands. A custom command can use `return(value)` when `import(actions)` is enabled.

See `examples/custom_commands.modkec`.

## Native Python blocks (v0.8.0)

Modkec remains the default language. Python is opt-in and runs only inside an explicit block after `import(py)`:

```text
set(start, 4)
import(py)
python()
answer = start * 3
print("Python says:", answer)
end_python()
say(answer)
```

Python blocks share variables with Modkec: existing Modkec variables are available in the Python namespace, and variables created or changed by Python are copied back. Printed output appears in Studio's output panel. Python blocks can only be translated to Python; translating them to JavaScript, Lua, Luau, C, or HTML produces an explicit error instead of silently changing their behavior.

**Security warning:** `import(py)` deliberately opts into native Python execution. Python code can access files, the network, installed packages, and other capabilities available to the running user. Only run trusted source code. This is not a sandbox.

See `examples/python_interop.modkec`.


## Native Modkec website builder (v0.8.1)

The `web` module includes semantic site-building commands. You author the page in Modkec; the runtime generates the browser files. The source file does not need raw HTML, CSS, or JavaScript blocks.

```text
import(web)
site_start("Example site", "A site authored in Modkec.")
site_nav_item("Downloads", "#downloads")
site_hero("Build with", "A short introduction.", "Downloads", "#downloads", "Learn", "#docs")
site_section("downloads", "Releases", "Downloads", "Available builds.")
site_list_start("builds", "versions")
site_download("0.8.4", "Modkec Studio", "Development", "Visele button actions and native scientific math.", "Linux,Windows", "downloads/modkec-studio-v0.8.4.zip", "Development build")
site_list_end()
site_build("index.html")
```

Supported page commands: `site_start`, `site_nav_item`, `site_hero`, `site_stat`, `site_section`, `site_text`, `site_button`, `site_image`, `site_link`, `site_theme`, `site_custom_css`, `site_card`, `site_search`, `site_list_start`, `site_list_end`, `site_download`, `site_depot`, `site_empty`, `site_warning`, `site_step`, `site_command`, `site_faq`, `site_code`, `site_footer`, and `site_build`. These commands require `import(web)` and `site_start()` first. `site_text(text, optional_tag)` supports `p`, `h1`, `h2`, `h3`, and `blockquote`; `site_button(label, target, optional_style)` supports `primary` and `secondary`; `site_image(path, alt, optional_width)` adds a responsive image; `site_link(label, target)` adds a link; `site_theme(primary_hex, optional_background_hex)` sets theme colors; and `site_custom_css(css_text)` appends developer-written CSS. `site_build(path)` writes a standalone HTML page, including generated styling and the small search interaction. This is a static site builder; it does not host the site or provide server-side forms/accounts.

To rebuild the included Community Hub from the project root, run:

```sh
python3 run_modkec.py examples/community_hub.modkec
```

The resulting `index.html` is generated browser output; the maintainable source is `examples/community_hub.modkec`. This is a static site builder, not a hosted server or a community-submission backend.


## v0.9.4: native code blocks and saved custom commands

Use `code(language)` and close it with `code(language) end` to mark a native-language block inside a `.modkec` file. The interpreter executes Python blocks directly and can launch other installed runtimes/compilers for supported native source blocks. External blocks run as subprocesses with a 15-second timeout; they are not sandboxed. Runtime availability varies by operating system.

During translation, `code(python)` switches the source language for that block: the implemented Python subset is translated to the selected output language, and the matching closing marker switches back to Modkec-to-target translation. The Python-block translator supports assignments, augmented assignments, arithmetic, boolean expressions, comparisons, `print()`, `if`/`elif`/`else`, `while`, and `for` loops over `range()` with a supported integer step. This is still a bounded subset, not a complete Python transpiler: imports, classes, function definitions, collections, comprehensions, f-strings, and many library-specific calls are not translated. Unsupported syntax raises an error rather than being silently copied. `range()` steps must be nonzero integer literals for cross-language translation. Direct HTML translation of embedded code blocks and arbitrary cross-language conversions are not implemented. Existing `python()` / `end_python()` blocks remain supported for compatibility.

Command Maker now has **Save**, **Insert into script**, and **Close** controls. Saved command definitions are stored under the user's Modkec configuration directory (`custom_commands/`) and can be inserted later with **Program → Insert Saved Command…**. Saving a command stores its definition; it does not automatically add that definition to every script.

### Studio bootstrap validation

Run `python3 run_modkec.py --bootstrap-check`  to validate the source-controlled `studio/bootstrap.modkec` manifest and all required source files without opening the GUI. This is a packaging/startup integrity check, not a Python-free runtime: the current interpreter and Tkinter desktop host still require Python.

## P14 native-runtime migration preview (experimental)

P14 begins a parallel native implementation rather than replacing the working Studio prematurely. `native/modkec_native.c` is a standalone C runtime kernel that does not call Python. The currently tested subset includes core scalar commands (`say`, `set`, `get`, `store`, `delete`, `increment`, `decrement`, `comment`, and `stop`) plus basic file commands (`read_file`, `write_file`, `file_exists`, `copy_file`, `rename_file`, and `create_folder`). `store()` writes scalar values to `.modkec_store.json` beside the source script; `get()` can read a stored value in a later run. This is a partial compatibility layer, not a complete implementation of the Python engine's persistent data model. Unsupported syntax and modules fail with explicit diagnostics; this is intentional so programs are not silently misinterpreted.

On Linux, run `./run_native.sh tests/native/core.modkec` only with a script limited to the supported subset; the bundled `tests/native/core.modkec` is a known-good example. The included Linux x86-64 binary runs without a compiler. Developers can rebuild it with `./native/build.sh`. On Windows, `run_native.bat` reports that no prebuilt Windows executable is included; a Windows build has not yet been produced or verified. The existing `run_studio.sh` and `run_studio.bat` still launch the original full-featured Studio through Python, because the native runtime and native GUI do not yet implement the full existing feature set. This preview is a migration foundation, not a claim of completed self-hosting.

## Standalone native-kernel preview (P14)

This ZIP includes a prebuilt, statically linked Linux x86-64 native kernel at `bin/modkec-native`. Running `./run_native.sh tests/native/core.modkec` does not require Python or a C compiler on a compatible Linux x86-64 system. The Windows `.bat` launcher is included, but this preview does **not** include a prebuilt Windows executable. Building the Windows kernel currently requires a Windows C toolchain; the build helper uses Microsoft's `cl` compiler.

The kernel supports only a small subset of Modkec commands and is not the full Studio. Unsupported commands and modules fail explicitly. The desktop IDE, translator, extensions, BeatMaker, Visele, and broader runtime still use Python; `run_studio.sh` therefore still requires Python and Tkinter. This package is not yet a universal or dependency-free release of the complete Studio. The goal remains a ZIP with tested per-platform launch targets and a Studio implemented in Modkec, with only the small OS bootstrap outside Modkec.

### Modkec-first startup (P14)

The standard `run_studio.sh` and `run_studio.bat` launchers now start `studio/entry.modkec` through the Modkec engine. That entry point explicitly opts into `import(py)` and an embedded `python()` block to start the existing desktop host. This lets Modkec own the startup sequence while Python remains a compatibility bridge for GUI and application behavior that has not yet been ported. It does **not** mean the desktop UI or engine has already been rewritten in Modkec, and Python remains a runtime requirement in this transitional build.

## v1.0.0-p15 host migration status

The standard launcher now runs the Modkec entry point, which declares its host path and startup mode in Modkec before invoking a validated Python compatibility adapter. `studio/host_services.modkec` is the source-controlled registry for the desktop, language engine, translator, extensions, visuals, Beatmaker, and project-file services. The registry is validated before startup and covered by regression tests.

This is a migration boundary, not completed self-hosting. The listed services still point to Python implementations, and the desktop still requires Python 3.10+ and Tkinter. A service should only be called Modkec-native once its implementation has actually moved to `.modkec` and passed behavior-equivalence tests.

## v1.0.0-p16 embedded desktop host

The normal Studio launcher now starts `studio/entry.modkec`, which loads `studio/desktop.modkec`. The complete desktop host implementation is embedded in that Modkec file as an explicit Python/Tkinter block, rather than being launched from a separate `studio.py` file. `studio.py` remains as a compatibility copy during this migration.

This is a concrete move of the desktop host source into Modkec, not yet a dependency-free executable: the Modkec interpreter still uses Python, and the desktop block requires Python with Tkinter available. The language engine, translator, extension services, and other bundled components are not yet rewritten in Modkec.


## v1.0.0-p18 standalone runtime builds

To create a no-separate-Python-install runtime, build on each target OS using `packaging/build-runtime.sh` (Linux/macOS) or `packaging/build-runtime.bat` (Windows). The build process packages the current Python/Tkinter host with PyInstaller, runs a bundled runtime check, and writes an OS/architecture-specific ZIP under `release/`. See `docs/P17_STANDALONE_RUNTIME.md`. Build-time internet is required to install PyInstaller; end users do not need it or a separate Python installation.

### Standalone runtime builds (P18)

See `docs/P18_STANDALONE_BUILDS.md` for the per-OS build pipeline. To generate native Windows, Linux, and macOS runtime ZIPs, publish this source to a GitHub repository and run the **Build standalone Modkec Studio** workflow. Each OS bundle must be built on its native runner; this source ZIP does not itself contain those large platform-specific runtimes.

## Release-candidate status

The P18 source tree has passed the local automated test suite and source/runtime smoke checks in the current Linux environment. See `docs/RELEASE_CANDIDATE_TEST_REPORT.md` for the exact results and outstanding release gates. The standalone Windows, Linux, and macOS archives are not included in this source ZIP; the native build workflow must run successfully before this can be called the final 1.0.0 release.
