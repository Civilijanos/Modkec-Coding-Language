"""Host-independent core services used by Modkec Studio.

These routines deliberately avoid Tkinter so the same project/file behavior can
be reused by a future Modkec-native desktop host.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

WORKSPACE_FORMAT = "modkec-workspace"
WORKSPACE_VERSION = 1


def encode_workspace(folders: list[str | Path]) -> str:
    """Serialize workspace folders in the stable, versioned workspace format."""
    paths = [str(Path(folder).expanduser().resolve()) for folder in folders]
    return json.dumps({"format": WORKSPACE_FORMAT, "version": WORKSPACE_VERSION, "folders": paths}, indent=2)


def decode_workspace(text: str) -> list[Path]:
    """Validate workspace data and return existing folder paths.

    Raises ValueError for malformed or unsupported workspace documents.
    """
    try:
        data: Any = json.loads(text)
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Invalid workspace data: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("Workspace must be a JSON object.")
    if data.get("format", WORKSPACE_FORMAT) != WORKSPACE_FORMAT:
        raise ValueError("This file is not a Modkec workspace.")
    if data.get("version", WORKSPACE_VERSION) != WORKSPACE_VERSION:
        raise ValueError(f"Unsupported workspace version: {data.get('version')!r}")
    raw_folders = data.get("folders")
    if not isinstance(raw_folders, list) or not all(isinstance(p, str) and p.strip() for p in raw_folders):
        raise ValueError("Workspace folders must be a list of non-empty paths.")
    folders = [Path(p).expanduser().resolve() for p in raw_folders]
    existing = [folder for folder in folders if folder.is_dir()]
    if not existing:
        raise ValueError("This workspace has no existing folders.")
    return existing


def read_source(path: str | Path) -> str:
    """Read a source file as UTF-8, preserving newline content."""
    return Path(path).read_text(encoding="utf-8")


def write_source(path: str | Path, source: str) -> None:
    """Write source as UTF-8; do not create missing parent directories implicitly."""
    if not isinstance(source, str):
        raise TypeError("Source content must be text.")
    Path(path).write_text(source, encoding="utf-8")
