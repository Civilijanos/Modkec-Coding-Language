"""Source-driven bootstrap manifest validation for Modkec Studio.

The manifest is intentionally declarative and never executed as Python. This
module validates paths and required host capabilities before the UI starts.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

ALLOWED_CALLS = {
    "bootstrap_version": 1,
    "bootstrap_entry": 1,
    "bootstrap_source": 1,
    "bootstrap_requirement": 2,
}
REQUIRED_CAPABILITIES = {"python-host", "tkinter-host", "modkec-engine"}


def read_bootstrap_manifest(root: str | Path) -> dict[str, Any]:
    root = Path(root).resolve()
    manifest = root / "studio" / "bootstrap.modkec"
    declarations: dict[str, Any] = {"sources": [], "requirements": []}
    seen_singletons: set[str] = set()
    try:
        lines = manifest.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"Cannot read Studio bootstrap manifest: {exc}") from exc

    for number, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([a-z_]+)\((.*)\)", line)
        if not match or match.group(1) not in ALLOWED_CALLS:
            raise ValueError(f"Invalid bootstrap declaration at {manifest.name}:{number}")
        name, raw_args = match.groups()
        try:
            args = ast.literal_eval("(" + raw_args + ("," if raw_args.strip() else "") + ")")
        except (ValueError, SyntaxError) as exc:
            raise ValueError(f"Invalid bootstrap arguments at {manifest.name}:{number}: {exc}") from exc
        if not isinstance(args, tuple) or len(args) != ALLOWED_CALLS[name] or not all(isinstance(v, str) and v.strip() for v in args):
            raise ValueError(f"Invalid arguments for {name} at {manifest.name}:{number}")
        if name in {"bootstrap_version", "bootstrap_entry"}:
            if name in seen_singletons:
                raise ValueError(f"Duplicate {name} declaration at {manifest.name}:{number}")
            seen_singletons.add(name)
            declarations["version" if name == "bootstrap_version" else "entry"] = args[0]
        elif name == "bootstrap_source":
            declarations["sources"].append(args[0])
        else:
            declarations["requirements"].append(args)

    if seen_singletons != {"bootstrap_version", "bootstrap_entry"}:
        raise ValueError("Bootstrap manifest must declare exactly one version and entry point")
    if not re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+-p[0-9]+", declarations["version"]):
        raise ValueError(f"Invalid bootstrap version: {declarations['version']!r}")
    if not declarations["sources"] or len(declarations["sources"]) != len(set(declarations["sources"])):
        raise ValueError("Bootstrap sources must be non-empty and unique")
    if not declarations["requirements"]:
        raise ValueError("Bootstrap requirements must not be empty")
    requirement_names = [item[0] for item in declarations["requirements"]]
    if len(requirement_names) != len(set(requirement_names)):
        raise ValueError("Duplicate bootstrap requirement")
    if {value for _, value in declarations["requirements"]} != REQUIRED_CAPABILITIES:
        raise ValueError("Bootstrap requirements do not match supported host capabilities")

    relative_paths = [declarations["entry"], *declarations["sources"]]
    for relative in relative_paths:
        candidate = Path(relative)
        if candidate.is_absolute() or ".." in candidate.parts or not candidate.parts:
            raise ValueError(f"Unsafe path in bootstrap manifest: {relative!r}")
        target = (root / candidate).resolve()
        if root not in target.parents:
            raise ValueError(f"Bootstrap path escapes project root: {relative!r}")
        try:
            content = target.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise ValueError(f"Bootstrap source is missing or unreadable: {relative!r}: {exc}") from exc
        if not content.strip():
            raise ValueError(f"Bootstrap source is empty: {relative!r}")

    if Path(declarations["entry"]).suffix != ".modkec":
        raise ValueError("Studio bootstrap entry must be a .modkec source file")
    entry_text = (root / declarations["entry"]).read_text(encoding="utf-8")
    if not all(token in entry_text for token in ("import(py)", "python()", "end_python()")):
        raise ValueError("Studio Modkec entry must explicitly bridge to the Python host")

    app_text = (root / "studio" / "application.modkec").read_text(encoding="utf-8")
    if f' studio_setting("version", "{declarations["version"]}")' not in app_text and f'studio_setting("version", "{declarations["version"]}")' not in app_text:
        raise ValueError("Bootstrap version does not match studio/application.modkec")
    return declarations


def check_bootstrap(root: str | Path) -> dict[str, Any]:
    """Run manifest checks without opening the desktop GUI."""
    result = read_bootstrap_manifest(root)
    result["source_count"] = len(result["sources"])
    result["capabilities"] = sorted(value for _, value in result["requirements"])
    return result
