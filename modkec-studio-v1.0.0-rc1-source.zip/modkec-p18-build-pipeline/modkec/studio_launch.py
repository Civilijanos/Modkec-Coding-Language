"""Validated launcher bridge for Modkec-owned Studio startup.

The .modkec files own startup intent and host-service declarations. This small
Python adapter performs filesystem validation and hands off to the existing
Tkinter host until those services have Modkec-native implementations.
"""
from __future__ import annotations

import ast
import re
import runpy
from pathlib import Path
from typing import Any, Callable

_SERVICE_RE = re.compile(r"studio_host_service\((.*)\)")


def read_host_services(root: str | Path) -> dict[str, dict[str, str]]:
    root = Path(root).resolve()
    registry = root / "studio" / "host_services.modkec"
    try:
        lines = registry.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"Cannot read host-service registry: {exc}") from exc

    services: dict[str, dict[str, str]] = {}
    for number, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = _SERVICE_RE.fullmatch(line)
        if not match:
            raise ValueError(f"Invalid host-service declaration at {registry.name}:{number}")
        try:
            values: Any = ast.literal_eval("(" + match.group(1) + ("," if match.group(1).strip() else "") + ")")
        except (ValueError, SyntaxError) as exc:
            raise ValueError(f"Invalid host-service arguments at {registry.name}:{number}") from exc
        if not isinstance(values, tuple) or len(values) != 3 or not all(isinstance(value, str) and value.strip() for value in values):
            raise ValueError(f"Host-service declaration requires three non-empty strings at line {number}")
        name, source, adapter = values
        if name in services:
            raise ValueError(f"Duplicate host service: {name}")
        relative = Path(source)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"Unsafe host-service source path: {source!r}")
        target = (root / relative).resolve()
        if root not in target.parents or not target.is_file():
            raise ValueError(f"Host-service source is missing or outside the project: {source!r}")
        if adapter not in {"tkinter", "python-compat"}:
            raise ValueError(f"Unsupported host adapter {adapter!r} for service {name!r}")
        services[name] = {"source": source, "adapter": adapter}

    required = {"desktop", "language_engine", "translator", "extensions", "visuals", "beatmaker", "project_files"}
    missing = required - services.keys()
    if missing:
        raise ValueError("Host-service registry is missing: " + ", ".join(sorted(missing)))
    return services


def launch_studio(
    root: str | Path,
    host_file: str = "studio.py",
    *,
    run_path: Callable[..., Any] = runpy.run_path,
) -> Any:
    """Validate source declarations and launch the compatibility host."""
    from .bootstrap import check_bootstrap

    project_root = Path(root).resolve()
    check_bootstrap(project_root)
    read_host_services(project_root)
    relative = Path(host_file)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe Studio host path: {host_file!r}")
    host = (project_root / relative).resolve()
    if project_root not in host.parents or not host.is_file():
        raise FileNotFoundError(f"Studio host was not found inside the project: {host_file}")
    return run_path(str(host), run_name="__main__")
