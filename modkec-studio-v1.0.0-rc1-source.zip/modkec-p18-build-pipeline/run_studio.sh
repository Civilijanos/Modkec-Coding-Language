#!/bin/sh
cd "$(dirname "$0")"
export PYTHONPYCACHEPREFIX="$PWD/.pytest_cache/pycache"
exec python3 run_modkec.py --quiet studio/entry.modkec
