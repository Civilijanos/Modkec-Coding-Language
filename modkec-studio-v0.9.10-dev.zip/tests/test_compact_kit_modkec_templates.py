import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_compact_kit_templates_are_defined_in_modkec_file():
    templates = ROOT / "bundled_extensions" / "compact_kit" / "templates.modkec"
    source = templates.read_text(encoding="utf-8")
    assert 'template("calculator", "basic"' in source
    assert 'template("game", "health"' in source
    assert 'template("utility", "random"' in source


def test_compact_kit_generates_a_user_added_modkec_template(tmp_path, monkeypatch):
    import modkec.plugins as plugins
    from modkec.engine import ModkecEngine

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    installed = plugins.install_bundled_extension("compact_kit")
    assert installed["id"] == "compact_kit"
    template_path = tmp_path / "extensions" / "community" / "compact_kit" / "templates.modkec"
    # Extension directory resolution is platform-dependent; use the actual installed package path.
    package = next(item for item in plugins.list_community_extensions() if item["id"] == "compact_kit")
    template_path = Path(package["folder"]) / "templates.modkec"
    with template_path.open("a", encoding="utf-8") as stream:
        stream.write('\ntemplate("game", "inventory", "set(inventory, 0)\\nincrement(inventory, 1)\\nsay(inventory)")\n')
    output = ModkecEngine().run("import(compact_kit)\ngame(inventory)")
    assert "set(inventory, 0)" in output
    assert "increment(inventory, 1)" in output
