"""Headless-capable GUI smoke tests; run under Xvfb on Linux CI."""
import tkinter as tk

import pytest

from studio import ModkecStudio
from modkec.engine import ModkecEngine


@pytest.fixture
def studio_app():
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        pytest.skip(f"Tk display is unavailable; run tests under Xvfb: {exc}")
    app = ModkecStudio(root)
    root.update_idletasks()
    root.update()
    yield root, app
    try:
        root.destroy()
    except tk.TclError:
        pass


def test_studio_window_and_editor_initialize(studio_app):
    root, app = studio_app
    assert root.title() == "Modkec Studio"
    assert root.winfo_exists()
    assert app.editor.winfo_exists()
    assert app.output.winfo_exists()
    assert app.active_document_index == 0
    assert len(app.documents) >= 1


def test_editor_can_edit_and_run_modkec_program(studio_app):
    _root, app = studio_app
    app.editor.delete("1.0", "end")
    app.editor.insert("1.0", 'say("GUI smoke test")')
    app.run_program()
    output = app.output.get("1.0", "end")
    assert "GUI smoke test" in output
    assert app.status.get() == "Run completed"


def test_find_highlights_and_clears_results(studio_app):
    _root, app = studio_app
    app.editor.delete("1.0", "end")
    app.editor.insert("1.0", "alpha beta alpha")
    assert app._highlight_find_matches("alpha") == 2
    assert len(app.editor.tag_ranges("search_result")) == 4
    app._close_find_dialog()
    assert app.editor.tag_ranges("search_result") == ()


def test_visele_preview_builds_canvas(studio_app):
    root, app = studio_app
    source = 'import(visele)\nrect(10, 20, 100, 60) hex(7C3AED)\ntext("Preview smoke test", 10, 100) hex(111111)'
    # Build an engine with visuals; ModkecEngine.run returns output, so retain instance.
    engine = ModkecEngine()
    engine.run(source)
    app._show_visual_preview(engine)
    root.update_idletasks()
    root.update()
    windows = [w for w in root.winfo_children() if isinstance(w, tk.Toplevel)]
    assert windows, "Visele preview window was not created"
    canvas_widgets = [child for child in windows[-1].winfo_children() if isinstance(child, tk.Canvas)]
    assert canvas_widgets, "Visele preview canvas was not created"
    assert len(canvas_widgets[0].find_all()) >= 2


def test_startup_diagnostics_cover_core_subsystems():
    import queue

    from studio import run_startup_checks

    events = queue.Queue()
    run_startup_checks(events)
    results = []
    while not events.empty():
        results.append(events.get_nowait())

    assert {name for name, _status, _detail in results} == {
        "Project files",
        "Interpreter and arithmetic",
        "Error handling",
        "Code translation",
        "Visele drawing",
        "Extension loader",
    }
    failures = [(name, detail) for name, status, detail in results if status != "PASS"]
    assert not failures, f"Startup diagnostic failures: {failures}"


def test_studio_source_file_shows_warning_and_disables_autosave(studio_app, monkeypatch):
    from pathlib import Path
    from studio import ROOT

    _root, app = studio_app
    app.current_path = ROOT / "studio.py"
    app.dirty = True
    app.auto_save.set(True)
    app._set_title()

    assert app._is_studio_source_file()
    assert app.source_warning.winfo_manager() == "pack"
    assert app.file_menu.entrycget(app.auto_save_menu_index, "state") == "disabled"

    saved = []
    monkeypatch.setattr(app, "save_file", lambda: saved.append(True) or True)
    app._autosave_if_needed()
    assert saved == []


def test_regular_external_source_file_does_not_get_studio_warning(studio_app, tmp_path):
    _root, app = studio_app
    app.current_path = tmp_path / "my_script.py"
    app._set_title()
    assert not app._is_studio_source_file()
    assert app.source_warning.winfo_manager() == ""
    assert app.file_menu.entrycget(app.auto_save_menu_index, "state") == "normal"
