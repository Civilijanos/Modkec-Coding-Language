from pathlib import Path
import tempfile
import wave

from modkec.beatmaker import TRACKS, render_wav


def test_beatmaker_exports_valid_wav():
    pattern = {track: [False] * 16 for track in TRACKS}
    pattern["Kick"][0] = True
    with tempfile.TemporaryDirectory() as directory:
        output = render_wav(pattern, 110, Path(directory) / "test.wav", bars=1)
        with wave.open(str(output), "rb") as wav:
            assert wav.getnchannels() == 1
            assert wav.getsampwidth() == 2
            assert wav.getframerate() == 22050
            assert wav.getnframes() > 0
