"""Pre-1.0 regression coverage for parser, evaluator, and release behavior."""
import json
import math
import zipfile
from pathlib import Path

import pytest

from modkec.engine import ModkecEngine, ModkecError, split_args, split_commands
from modkec.translator import translate


def run(source, **kwargs):
    engine = ModkecEngine(**kwargs)
    return engine, engine.run(source)


@pytest.mark.parametrize(("source", "expected"), [
    ('say("hello")', 'hello'),
    ('set(x, 4)\nsay(x + 3)', '7'),
    ('set(x, -4)\nsay(abs(x))', '4'),
    ('set(x, 5 / 2)\nsay(x)', '2.5'),
    ('set(x, 5 // 2)\nsay(x)', '2'),
    ('set(x, 5 % 2)\nsay(x)', '1'),
    ('set(x, 2 ** 8)\nsay(x)', '256'),
    ('set(x, [1, 2, 3])\nsay(x[1])', '2'),
    ('set(x, {"a": 4})\nsay(x["a"])', '4'),
    ('set(x, 4 in [2, 4, 6])\nsay(x)', 'True'),
    ('set(x, 4 not in [2, 4, 6])\nsay(x)', 'False'),
    ('set(x, 4 >= 4)\nsay(x)', 'True'),
    ('set(x, 4 != 5)\nsay(x)', 'True'),
    ('set(x, not f)\nsay(x)', 'True'),
    ('set(x, 1 and 2)\nsay(x)', 'True'),
    ('set(x, 0 or 2)\nsay(x)', 'True'),
    ('set(x, sum([1, 2, 3]))\nsay(x)', '6'),
    ('set(x, len("modkec"))\nsay(x)', '6'),
    ('set(x, round(2.6))\nsay(x)', '3'),
    ('set(x, pi > 3)\nsay(x)', 'True'),
])
def test_core_expression_regressions(source, expected):
    _, output = run(source)
    assert output == expected


@pytest.mark.parametrize("expression", [
    'x.__class__',
    '__import__("os")',
    'open("secret")',
    '(lambda: 1)()',
    '[x for x in range(3)]',
    'sum(x for x in range(3))',
    'x.real',
    'globals()',
    'eval("1+1")',
])
def test_expression_evaluator_rejects_unsupported_or_unsafe_constructs(expression):
    with pytest.raises(ModkecError):
        run(f'set(result, {expression})')


def test_and_short_circuits_false_left_operand():
    _, output = run('set(result, f and missing_name)\nsay(result)')
    assert output == 'False'


def test_or_short_circuits_true_left_operand():
    _, output = run('set(result, t or missing_name)\nsay(result)')
    assert output == 'True'


def test_power_expression_has_a_guardrail():
    with pytest.raises(ModkecError, match='Exponent is too large'):
        run('set(result, 2 ** 100000000)')


@pytest.mark.parametrize("source, message", [
    ('unknown_command()', 'Unknown command'),
    ('set(x)', 'needs a name and value'),
    ('set(1bad, 2)', 'target must be a variable'),
    ('import(no_such_module)', 'Unknown module'),
    ('set(x, 1)\nif(x)=t, do(missing_action)', 'hasn.t been defined'),
    ('end()', 'only closes'),
    ('python()\nprint(1)', 'requires import'),
    ('action(test)\n say("x")', 'no matching end'),
    ('code(not_a_language)\nhello\ncode(not_a_language) end', 'unsupported source language'),
])
def test_invalid_programs_raise_readable_modkec_errors(source, message):
    with pytest.raises(ModkecError, match=message):
        run(source)


def test_increment_initializes_missing_numeric_variable_to_zero():
    _, output = run('increment(score, 1)\nsay(score)')
    assert output == '1'


def test_runtime_errors_include_source_line_number():
    with pytest.raises(ModkecError, match=r'Line 3:'):
        run('say("first")\n# comment\nmissing_command()')


@pytest.mark.parametrize(("raw", "expected"), [
    ('a,b,c', ['a', 'b', 'c']),
    ('"a,b",c', ['"a,b"', 'c']),
    ('fn(a,b),c', ['fn(a,b)', 'c']),
    ('[1,2], {"x":3}', ['[1,2]', '{"x":3}']),
    ('"escaped \\" quote",x', ['"escaped \\" quote"', 'x']),
    ('', []),
    ('  a  ,  b  ', ['a', 'b']),
])
def test_split_args_handles_nested_and_quoted_commas(raw, expected):
    assert split_args(raw) == expected


def test_split_commands_does_not_split_inside_quoted_strings():
    assert split_commands('say("a b c")') == ['say("a b c")']


def test_split_commands_splits_adjacent_commands():
    assert split_commands('rect(1,2,3,4) hex(FF00FF)') == ['rect(1,2,3,4)', 'hex(FF00FF)']


def test_action_parameters_are_restored_after_call():
    source = '''import(actions)
set(value, 100)
action(double, value)
    return(value * 2)
end()
call(double, 4) -> result
say(result)
say(value)'''
    engine, output = run(source)
    assert output == '8\n100'
    assert engine.variables['value'] == 100


def test_repeat_loop_limit_does_not_execute_unbounded_count():
    source = 'import(logic)\nset(n, 0)\naction(inc)\n increment(n, 1)\nend()\nrepeat(1000000000) do(inc)\nsay(n)'
    _, output = run(source)
    assert output == '10000'


def test_while_loop_limit_raises_instead_of_hanging():
    with pytest.raises(ModkecError, match='10,000 iterations'):
        run('import(logic)\nset(n, 0)\naction(inc)\n increment(n, 1)\nend()\nwhile(t) do(inc)')


def test_translate_rejects_unknown_target():
    with pytest.raises(ModkecError):
        translate('say("hello")', 'made_up_target')


@pytest.mark.parametrize("target", ['python', 'javascript', 'lua', 'luau', 'c', 'html'])
def test_basic_program_translates_to_every_advertised_target(target):
    output = translate('set(score, 4)\nsay(score)', target)
    assert isinstance(output, str) and output.strip()


def test_export_creates_expected_file(tmp_path):
    from modkec.translator import export
    source = tmp_path / 'main.modkec'
    source.write_text('say("hello")', encoding='utf-8')
    destination = tmp_path / 'main.py'
    result = export(source.read_text(encoding='utf-8'), 'python', destination)
    assert Path(result).is_file()
    assert 'hello' in Path(result).read_text(encoding='utf-8')


def test_persistent_store_corruption_does_not_break_engine(tmp_path):
    store = tmp_path / '.modkec_store.json'
    store.write_text('{not json', encoding='utf-8')
    engine = ModkecEngine(source_name=str(tmp_path / 'main.modkec'))
    output = engine.run('say("still runs")')
    assert output == 'still runs'


def test_store_round_trip_values(tmp_path):
    source = tmp_path / 'main.modkec'
    engine = ModkecEngine(source_name=str(source))
    engine.run('store(score, 42)\nstore(label, "ready")')
    other = ModkecEngine(source_name=str(source))
    assert other.run('get(score)\nget(label)') == '42\nready'


def test_visual_commands_record_data_without_gui():
    engine, _ = run('import(visele)\nrect(10, 20, 30, 40) hex(7C3AED)')
    assert engine.visuals
    rects = [item for item in engine.visuals if item.get('kind') == 'rect']
    assert rects


def test_import_aliases_are_normalized():
    engine, _ = run('import(calculations)\nadd(2, 3) -> answer')
    assert engine.variables['answer'] == 5
    assert 'calculator' in engine.imported_modules


def test_module_imports_are_idempotent():
    engine, _ = run('import(calculator)\nimport(calculator)\nadd(1, 2) -> answer')
    assert engine.module_import_order.count('calculator') == 1


def test_cli_launcher_has_helpful_missing_file_error():
    import subprocess
    import sys
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run([sys.executable, str(root / 'run_modkec.py'), str(root / 'does-not-exist.modkec')], cwd=root, text=True, capture_output=True)
    assert result.returncode != 0
    assert result.stderr or result.stdout
