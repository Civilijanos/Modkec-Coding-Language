from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_compact_kit_is_not_registered_as_a_builtin_studio_feature():
    studio = (ROOT / "studio.py").read_text(encoding="utf-8")
    assert "from modkec.compact_kit import" not in studio
    assert "def insert_compact_kit(" not in studio
    assert not (ROOT / "modkec" / "compact_kit.py").exists()


def test_compact_kit_is_an_optional_bundled_extension():
    assert (ROOT / "bundled_extensions" / "compact_kit.zip").is_file()
    assert "compact_kit" in (ROOT / "modkec" / "extensions.py").read_text(encoding="utf-8")
