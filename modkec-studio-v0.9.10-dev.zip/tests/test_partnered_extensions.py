from pathlib import Path

import pytest

from modkec.extensions import PARTNERED_EXTENSIONS

ROOT = Path(__file__).resolve().parents[1]


def test_compact_kit_is_catalogued_but_not_installed_by_default(tmp_path, monkeypatch):
    import modkec.plugins as plugins

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    assert "compact_kit" in PARTNERED_EXTENSIONS
    assert PARTNERED_EXTENSIONS["compact_kit"]["name"] == "Compact Kit"
    assert PARTNERED_EXTENSIONS["compact_kit"]["package_path"].is_file()
    assert plugins.list_community_extensions() == []


def test_partnered_compact_kit_installs_and_is_only_activated_by_import(tmp_path, monkeypatch):
    import modkec.plugins as plugins
    from modkec.engine import ModkecEngine

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    installed = plugins.install_bundled_extension("compact_kit")
    assert installed["id"] == "compact_kit"
    assert set(installed["commands"]) == {"calculator", "game", "utility"}

    # Installed extension commands are not activated until the script imports it.
    engine = ModkecEngine()
    assert "calculator" not in engine.imported_modules
    output = engine.run("import(compact_kit)\ncalculator(basic)")
    assert "Compact Kit — Basic Calculator" in output
    assert 'ask("First number:") -> first' in output


def test_partnered_templates_and_invalid_variant(tmp_path, monkeypatch):
    import modkec.plugins as plugins
    from modkec.engine import ModkecEngine, ModkecError

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    plugins.install_bundled_extension("compact_kit")
    engine = ModkecEngine()
    output = engine.run("import(compact_kit)\ngame(health)")
    assert "set(max_health, 100)" in output
    assert "decrement(health, 10)" in output

    with pytest.raises(ModkecError, match="Unknown calculator template"):
        ModkecEngine().run("import(compact_kit)\ncalculator(unknown)")


def test_partnered_compact_kit_uninstalls_cleanly(tmp_path, monkeypatch):
    import modkec.plugins as plugins

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    plugins.install_bundled_extension("compact_kit")
    plugins.uninstall_community_extension("compact_kit")
    assert all(item["id"] != "compact_kit" for item in plugins.list_community_extensions())
