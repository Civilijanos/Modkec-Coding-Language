# Tutorial: maintain Compact Kit in your own Modkec Studio fork

Compact Kit is intentionally not built into the main v0.9.4 development build. This guide shows how to maintain it as a personal fork, so the core project stays smaller while you can change your own templates and menu.

## 1. Create your fork

1. Open the GitHub repository page for the Modkec Studio source you use.
2. Select **Fork** and create a fork under your own GitHub account. Do not guess the repository URL; use the actual project page you already have.
3. On your Linux Mint computer, open a terminal and clone **your fork's** URL:

   ```bash
   git clone <your-fork-url>
   cd <cloned-repository-folder>
   ```

4. Create a working branch:

   ```bash
   git switch -c add-compact-kit
   ```

If you already have the v0.9.4 source extracted, you can make these changes there first, then commit and push it to your fork.

## 2. Restore the template module

Create `modkec/compact_kit.py`. This module returns ordinary Modkec source text; it does not add new language syntax or run code itself.

```python
"""Editable Modkec Compact Kit source templates."""

TEMPLATES = {
    "calculator(basic)": (
        "Basic calculator",
        '''# Compact Kit: basic calculator
import(calculator)
ask("First number:") -> first
ask("Second number:") -> second
add(first, second) -> answer
say(answer)
''',
    ),
    "game(score)": (
        "Score counter for a game",
        '''# Compact Kit: game score
import(actions)
set(score, 0)
command(add_point)
    increment(score)
    say(score)
end()

# Call add_point() whenever the player earns a point.
''',
    ),
    "game(health)": (
        "Player health and damage",
        '''# Compact Kit: health system
import(actions)
set(health, 100)
command(take_damage, amount)
    set(health, health - amount)
    if(health < 1)=t, do(player_defeated)
    say(health)
end()

action(player_defeated)
    say("Player defeated")
end()

# Example: take_damage(25)
''',
    ),
    "utility(random)": (
        "Random number generator",
        '''# Compact Kit: random number
import(calculator)
random(1, 100) -> result
say(result)
''',
    ),
}


def get_templates():
    """Return a copy so callers cannot replace the template catalogue."""
    return dict(TEMPLATES)
```

## 3. Connect it to the Studio menu

In `studio.py`, add this import with the other `modkec` imports:

```python
from modkec.compact_kit import get_templates  # noqa: E402
```

Find the menu-building code for `extensions_menu`, where **Manage Extensions…** and **Browse Community Forks…** are added. After those commands and before `menu.add_cascade(label="Extensions", menu=extensions_menu)`, add:

```python
kit_menu = tk.Menu(extensions_menu, tearoff=False)
for template_name in get_templates():
    kit_menu.add_command(
        label=template_name,
        command=lambda n=template_name: self.insert_compact_kit(n),
    )
extensions_menu.add_cascade(label="Compact Kit Extension", menu=kit_menu)
```

Then add this method inside the Studio application class (same indentation as methods such as `open_beatmaker`):

```python
def insert_compact_kit(self, name: str) -> None:
    """Insert a Compact Kit template as ordinary editable Modkec source."""
    if not self._require_modkec_source("Compact Kit"):
        return
    templates = get_templates()
    if name not in templates:
        return
    description, source = templates[name]
    existing = self._source().strip()
    if existing and not self._source().endswith("\n"):
        self.editor.insert("end-1c", "\n")
    self.editor.insert("end-1c", ("\n" if existing else "") + source)
    self.editor.edit_modified(True)
    self.editor.see("end")
    self._highlight_syntax()
    self.status.set(f"Compact Kit inserted: {name} — {description}")
```

This uses the existing editor, source-mode guard, syntax highlighting, and dirty-state tracking. Templates remain visible and editable after insertion.

## 4. Test the fork

From the repository root, run:

```bash
python3 -m compileall -q studio.py modkec
python3 -m pytest -q
```

Launch Studio with `./run_studio.sh`. Confirm **Extensions → Compact Kit Extension** appears, choose a template, and verify the source is inserted into a Modkec document. Also open a native-language file and confirm the insertion is blocked by the source-mode guard.

Add or restore a test for `get_templates()` that checks the expected template names and ensures each description/source is nonempty. Keep the beatmaker WAV test in its own test file; it is unrelated to Compact Kit.

## 5. Commit and publish your fork

```bash
git add studio.py modkec/compact_kit.py tests docs
 git commit -m "Add Compact Kit templates to personal fork"
git push -u origin add-compact-kit
```

Open a pull request only if you want to propose the feature back to the main project. If you only want it for yourself, keep the changes in your fork. When updating from upstream, merge or rebase the upstream branch and resolve conflicts in the menu-building section if Studio changes there.

## Notes

- The templates are starter source snippets, not a separate runtime or plugin API.
- Review and test the Modkec commands in each template before relying on them; a template may need to change as Modkec syntax evolves.
- A GitHub fork is a copy of the source repository. It does not automatically install the fork into Studio for other users.
