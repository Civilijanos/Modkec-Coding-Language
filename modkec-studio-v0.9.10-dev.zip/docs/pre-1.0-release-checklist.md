# Modkec Studio pre-1.0 release checklist

This is a release gate, not a claim that every item is already complete. Check items only after they have been verified on the target build.

## Language and runtime
- [ ] Document syntax and behavior for core commands, expressions, actions, modules, and error handling.
- [ ] Verify unknown commands, unknown variables, malformed calls, wrong argument counts, and unterminated blocks fail with actionable line-numbered errors.
- [ ] Verify loop/action recursion limits and arithmetic/resource limits prevent runaway execution.
- [ ] Verify expression evaluation rejects Python attribute access, arbitrary calls, comprehensions, lambdas, and other unsupported AST nodes.
- [ ] Verify short-circuit behavior for `and` and `or`.
- [ ] Verify persistent storage behavior, corruption handling, and project-relative paths.

## Editor and projects
- [ ] Automated smoke tests verify Studio startup, editor interaction, running a program from the editor, search highlighting/cleanup, and Visele preview-window creation.
- [ ] Test New/Open/Save/Save As/Save All and opening the same file twice.
- [ ] Test dirty-buffer prompts when closing tabs and exiting.
- [ ] Test read-only paths, missing files, invalid encodings, and permission errors.
- [ ] Test multiple tabs, tab switching, undo isolation, and cursor/selection restoration.
- [ ] Test project explorer on nested folders, inaccessible folders, symlinks, and large trees.
- [ ] Test recovery from application termination and unsaved changes.

## Visele and media
- [ ] Verify each supported primitive, color mode, layer, opacity, move/resize, hide/show/remove, and clear operation.
- [ ] Verify interaction callbacks redraw correctly and can be stopped/restarted.
- [ ] Verify missing/unsupported image and media files show errors without crashing Studio.
- [ ] Verify preview close/reopen and large preview responsiveness on low-memory hardware.

## Extensions and imports
- [ ] Verify extension ZIP path traversal, symlinks, oversized archives, malformed manifests, API mismatches, duplicate commands, and built-in command conflicts are rejected.
- [ ] Verify optional bundled extensions are not installed automatically.
- [ ] Verify extension install/uninstall and invalid extension recovery.
- [ ] Clearly document that Python extensions and `import(py)` run with the user's OS permissions and are not sandboxed.

## Translation and other features
- [ ] Run translator tests per target and document unsupported constructs.
- [ ] Verify exported files/ZIPs and error behavior for invalid target names and paths.
- [ ] Test beatmaker generation, WAV headers, duration, and invalid inputs.
- [ ] Test website builder output escaping and malformed inputs.
- [ ] Test CLI usage, launcher scripts, Linux and Windows startup, and missing optional runtimes.

## Release evidence
- [ ] Run `python -m pytest -q` and `pytest -q` from the project root.
- [ ] Run `python -m compileall -q modkec studio.py run_modkec.py translate_modkec.py`.
- [ ] Verify ZIP integrity and ensure generated caches, user data, and temporary files are excluded.
- [ ] Perform manual GUI smoke tests on each supported operating system.
- [ ] Verify package version, About dialog, README, changelog, and example files agree.
