"""Modkec starter interpreter. Implements the user's initial command specification."""
from __future__ import annotations
import ast, contextlib, io, json, math, operator, random, re, shutil, textwrap, time, webbrowser, subprocess, tempfile, os
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable
from .site_builder import SiteBuilder, build_site

class ModkecError(Exception): pass

BINOPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
CMPS = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Gt: operator.gt, ast.GtE: operator.ge, ast.Lt: operator.lt, ast.LtE: operator.le}
MODULE_ALIASES = {'calculations':'calculator', 'vis ele':'visele', 'visual':'visele', 'animation':'media'}
# Built-in module dependencies. Keep this graph explicit so imports can be
# resolved predictably and circular dependencies can be reported clearly.
MODULE_DEPENDENCIES = {
 'media': ('visele',),
}
MODULE_COMMANDS = {
 'visele': {'p','rect','square','circle','line','c1','c2','c3','c4','hex','rgb','text','image','button','update_text','resize','move','hide','show','remove','interact','clear','layer','opacity'},
 'calculator': {'add','subtract','multiply','divide','mod','power','round','floor','ceil','absolute','min','max','random','percentage','sqrt','sin','cos','tan','asin','acos','atan','ln','log','exp','factorial','evaluate'},
 'logic': {'if','else','equal','greater','less','and','or','not','repeat','while','break','on','wait_until'},
 'actions': {'action','do','return','input','call','event','trigger','cancel','end'},
 'data': {'list','append','remove_item','count','contains','sort','reverse','object','key','save','load'},
 'text': {'join','length','upper','lower','replace','contains_text','split','trim','number','format','drop_last'},
 'files': {'read_file','write_file','file_exists','copy_file','rename_file','list_files','create_folder','dimp'},
 'web': {'open_url','request','get_page','send','listen','timer','site_start','site_nav_item','site_hero','site_stat','site_section','site_text','site_button','site_image','site_link','site_theme','site_custom_css','site_card','site_search','site_list_start','site_list_end','site_download','site_depot','site_empty','site_warning','site_step','site_command','site_faq','site_code','site_footer','site_build'},
 'media': {'animate','fade','rotate','play_sound','stop_sound','volume','play_video','stop_animation'},
 'translation': {'translate','export','check','explain'}
}

def split_args(text: str) -> list[str]:
    out=[]; start=0; depth=0; quote=None; escaped=False
    for i,ch in enumerate(text):
        if quote:
            if escaped: escaped=False
            elif ch=='\\': escaped=True
            elif ch==quote: quote=None
        elif ch in "'\"": quote=ch
        elif ch in '([': depth+=1
        elif ch in ')]': depth-=1
        elif ch==',' and depth==0: out.append(text[start:i].strip()); start=i+1
    tail=text[start:].strip()
    if tail: out.append(tail)
    return out

_split_args = split_args  # Backwards-compatible name used by the translator.

def call_parts(line: str):
    m=re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\((.*)\)',line.strip())
    return (m.group(1),split_args(m.group(2))) if m else (None,[])

def split_commands(line: str) -> list[str]:
    """Split adjacent command calls like `p(120) hex(FF0000)` without splitting quoted text."""
    if re.match(r"^(repeat|while|on|timer)\(.*\)\s+do\(", line.strip()) or re.match(r"^else\(\)\s+do\(", line.strip()): return [line.strip()]
    parts=[]; start=0; depth=0; quote=None; escaped=False; i=0
    while i < len(line)-1:
        ch=line[i]
        if quote:
            if escaped: escaped=False
            elif ch=='\\': escaped=True
            elif ch==quote: quote=None
        elif ch in ("'", '\"'): quote=ch
        elif ch=='(': depth+=1
        elif ch==')':
            depth-=1
            if depth==0 and line[i+1].isspace():
                j=i+1
                while j<len(line) and line[j].isspace(): j+=1
                if re.match(r'[A-Za-z_][A-Za-z0-9_]*\(',line[j:]):
                    parts.append(line[start:i+1].strip()); start=j; i=j; continue
        i+=1
    tail=line[start:].strip()
    if tail: parts.append(tail)
    return parts

COMMAND_DESCRIPTIONS = {
 'say':'display text or values','ask':'request user input','set':'set a value','store':'save a value persistently beside the script in .modkec_store.json','get':'retrieve a variable or a persistent value','delete':'remove a variable and its stored value','increment':'increase a numeric variable','decrement':'decrease a numeric variable','type_of':'get a value type','wait':'pause execution','stop':'stop the program','import':'load a module, including py for explicit native Python blocks','run':'run another script or action','comment':'add a note','translate':'translate this script to another language','export':'save translated code from Studio',
 'p':'place a pixel','rect':'draw a rectangle','square':'draw a square','circle':'draw a circle','line':'draw a line','text':'draw text','image':'place an image','button':'create a button with an optional action name','update_text':'update a named text element','move':'move the last or named element','resize':'resize the last or named element','hide':'hide a visual element','show':'show a visual element or display a value','remove':'remove a visual element','interact':'enable visual interaction','clear':'clear visual elements','layer':'set drawing order','opacity':'set visual opacity','hex':'set a hexadecimal color','rgb':'set an RGB color',
 'add':'add values','subtract':'subtract values','multiply':'multiply values','divide':'divide values','mod':'calculate a remainder','power':'raise a value to a power','round':'round a number','floor':'round down','ceil':'round up','absolute':'calculate absolute value','min':'find the smallest value','max':'find the largest value','random':'generate a random number','percentage':'calculate a percentage','sqrt':'calculate a square root','sin':'sine','cos':'cosine','tan':'tangent','asin':'inverse sine','acos':'inverse cosine','atan':'inverse tangent','ln':'natural logarithm','log':'base-10 logarithm','exp':'exponential function','factorial':'factorial','evaluate':'evaluate a safe mathematical expression',
 'if':'run an action when a condition matches','else':'run an alternative action','equal':'compare equality','greater':'compare greater-than','less':'compare less-than','and':'combine conditions','or':'combine conditions','not':'reverse a condition','repeat':'repeat an action','while':'repeat while a condition is true','break':'exit a loop','on':'connect an event to an action','wait_until':'wait for a condition',
 'action':'define a reusable action','command':'define a reusable custom command callable by its name','do':'execute an action','return':'return a result','input':'receive an action value','call':'call an action','event':'define an event','trigger':'trigger an event','cancel':'cancel an action',
 'python':'begin a native Python block; requires import(py)','end_python':'end a native Python block',
 'list':'create a list','append':'add a list item','remove_item':'remove a list item','count':'count items','contains':'check list membership','sort':'sort a list','reverse':'reverse a list','object':'create a data object','key':'retrieve an object key','save':'save data','load':'load saved data','dimp':'import data from a file',
 'join':'combine text','length':'count characters','upper':'uppercase text','lower':'lowercase text','replace':'replace part of text','contains_text':'search text','split':'split text','trim':'trim whitespace','number':'convert text to a number','format':'insert values into text','drop_last':'remove the last character from text',
 'read_file':'read a file','write_file':'write a file','file_exists':'check whether a file exists','copy_file':'copy a file','rename_file':'rename a file','list_files':'list files in a folder','create_folder':'create a folder','open_url':'open a web address','request':'send a web request','get_page':'retrieve page data','send':'send data to a service','listen':'listen for a message','timer':'schedule a timed action',
 'animate':'animate an element','fade':'fade an element','rotate':'rotate an element','play_sound':'play audio','stop_sound':'stop audio','volume':'set audio volume','play_video':'play a video','stop_animation':'stop an animation','check':'check basic script structure','explain':'describe commands in this script','title':'set the page title in a web-source file','html':'begin a raw HTML block for web translation','end_html':'end the HTML block','style':'begin a raw CSS block for web translation','end_style':'end the CSS block','script':'begin a raw JavaScript block for web translation','end_script':'end the JavaScript block','site_start':'start a native Modkec website','site_nav_item':'add a navigation link','site_hero':'add the homepage hero','site_stat':'add a homepage statistic','site_section':'start a semantic website section','site_text':'add a text element to a website','site_button':'add a website button','site_image':'add an image to a website','site_link':'add a text link to a website','site_theme':'set website theme colors','site_custom_css':'add custom CSS to a website','site_card':'add an information card','site_search':'add a live search field','site_list_start':'start a searchable card list','site_list_end':'end a searchable card list','site_download':'add a version download card','site_depot':'add a community depot listing','site_empty':'show an empty-state message','site_warning':'show a safety notice','site_step':'add a tutorial step','site_command':'document a Modkec command','site_faq':'add a FAQ entry','site_code':'show a code sample','site_footer':'set footer content and repository link','site_build':'render the native Modkec website to an HTML file' 
}

@dataclass
class ModkecEngine:
    input_fn: Callable[[str],str] = input
    variables: dict[str,Any] = field(default_factory=dict)
    actions: dict[str,list[tuple[int,str]]] = field(default_factory=dict)
    action_params: dict[str,list[str]] = field(default_factory=dict)
    _call_depth: int = 0
    imported_modules: set[str] = field(default_factory=set)
    imported_module_dependencies: dict[str, tuple[str, ...]] = field(default_factory=dict)
    module_import_order: list[str] = field(default_factory=list)
    output: list[str] = field(default_factory=list)
    visuals: list[dict[str,Any]] = field(default_factory=list)
    media_actions: list[dict[str,Any]] = field(default_factory=list)
    animations: list[dict[str,Any]] = field(default_factory=list)
    events: dict[str,str] = field(default_factory=dict)
    _active_action: str|None = None
    _active_definition_kind: str|None = None
    _active_python: bool = False
    _python_lines: list[str] = field(default_factory=list)
    _python_start_line: int = 0
    _active_code_language: str | None = None
    custom_commands: set[str] = field(default_factory=set)
    _last_condition: bool|None = None
    _break_loop: bool = False
    _return_value: Any = None
    source_name: str|None = None
    site_builder: SiteBuilder|None = None
    extension_commands: dict[str, tuple[str, Callable[..., Any]]] = field(default_factory=dict)
    extension_packages: dict[str, tuple[str, ...]] = field(default_factory=dict)
    extension_load_errors: list[str] = field(default_factory=list)
    persistent_values: dict[str, Any] = field(default_factory=dict)
    media_callback: Callable[[dict[str, Any], "ModkecEngine"], None] | None = None

    def run(self, source: str) -> str:
        self.output=[]; self.visuals=[]; self.media_actions=[]; self.animations=[]; self._active_action=None; self._active_definition_kind=None
        self._active_python=False; self._python_lines=[]; self._python_start_line=0; self._active_code_language=None; self._source_text=source
        from .plugins import load_installed_extensions
        self.extension_commands, self.extension_packages, self.extension_load_errors = load_installed_extensions()
        self._load_persistent_values()
        lines=source.splitlines()

        # A top-level translate(target) line is a source-generation directive.
        # Handle it before execution so interactive scripts are translated without
        # first prompting for input or running their side effects.
        in_action = False
        in_python_block = False
        in_code_language = None
        for number, original in enumerate(lines, 1):
            directive = original.strip()
            if in_code_language is not None:
                if directive == f"code({in_code_language}) end": in_code_language = None
                continue
            code_open = re.fullmatch(r"code\(([A-Za-z][A-Za-z0-9_+#.-]*)\)", directive)
            if code_open:
                in_code_language = code_open.group(1).lower()
                continue
            if in_python_block:
                if directive == 'end_python()': in_python_block = False
                continue
            if in_action:
                if directive == 'end()': in_action = False
                continue
            if directive.startswith(('action(', 'command(')):
                in_action = True
                continue
            if directive == 'python()':
                in_python_block = True
                continue
            match = re.fullmatch(r'translate\(([^()]*)\)', directive)
            if match:
                target = match.group(1).strip().strip("'\"").lower()
                from .translator import translate
                try:
                    generated = translate(source, target)
                except ModkecError as exc:
                    raise ModkecError(f'Line {number}: {exc}') from exc
                self.output.append(generated.rstrip())
                return '\n'.join(self.output)

        for number, original in enumerate(lines,1):
            line=original.strip()
            if self._active_code_language is not None:
                if line == f"code({self._active_code_language}) end":
                    language=self._active_code_language
                    self._active_code_language=None
                    code="\n".join(self._python_lines)
                    self._python_lines=[]
                    self._execute_native_code_block(language, code, number)
                else:
                    self._python_lines.append(original)
                continue
            code_open = re.fullmatch(r"code\(([A-Za-z][A-Za-z0-9_+#.-]*)\)", line)
            if code_open:
                language=code_open.group(1).lower()
                accepted={"python","javascript","js","typescript","ts","lua","luau","c","cpp","c++","java","csharp","c#","go","rust","ruby","php","bash","shell"}
                if language not in accepted: raise ModkecError(f"Line {number}: unsupported source language '{language}' in code().")
                self._active_code_language=language; self._python_lines=[]; self._python_start_line=number
                continue
            if self._active_python:
                if line == 'end_python()':
                    self._execute_python_block(number)
                    self._active_python=False
                    self._python_lines=[]
                else:
                    self._python_lines.append(original)
                continue
            if not line or line.startswith('#'): continue
            if self._active_action is not None:
                if line=='end()': self._active_action=None; self._active_definition_kind=None
                else: self.actions[self._active_action].append((number,line))
                continue
            try: self._execute_line(line,number)
            except _StopProgram: break
            except _BreakLoop as e: raise ModkecError(f'Line {number}: break() can only be used inside repeat() or while().') from e
            except ModkecError as e: raise ModkecError(f'Line {number}: {e}') from e
        if self._active_action: raise ModkecError(f"Action '{self._active_action}' has no matching end().")
        if self._active_python: raise ModkecError(f"Line {self._python_start_line}: python() block has no matching end_python().")
        if self._active_code_language is not None: raise ModkecError(f"Line {self._python_start_line}: code({self._active_code_language}) block has no matching code({self._active_code_language}) end.")
        return '\n'.join(self.output)

    def _execute_python_block(self, end_line: int) -> None:
        """Execute explicitly opted-in Python and sync its variables/output with Modkec."""
        self._need('py', 'python')
        code=textwrap.dedent('\n'.join(self._python_lines)).strip('\n')
        if not code.strip(): return
        namespace=dict(self.variables)
        namespace['__builtins__']=__builtins__
        printed=io.StringIO()
        try:
            with contextlib.redirect_stdout(printed):
                exec(compile(code, f'<Modkec Python block starting line {self._python_start_line}>', 'exec'), namespace, namespace)
        except Exception as exc:
            raise ModkecError(f"Python block (line {self._python_start_line}): {type(exc).__name__}: {exc}") from exc
        namespace.pop('__builtins__', None)
        self.variables.update(namespace)
        captured=printed.getvalue().rstrip('\n')
        if captured: self.output.extend(captured.splitlines())

    def _execute_native_code_block(self, language: str, code: str, end_line: int) -> None:
        """Execute an explicitly marked native-language block when its toolchain exists."""
        if not code.strip(): return
        if language == "python":
            self.imported_modules.add("py")
            self._python_lines = code.splitlines()
            self._execute_python_block(end_line)
            self._python_lines=[]
            return
        suffixes={"javascript":".js","js":".js","typescript":".ts","ts":".ts","lua":".lua","luau":".luau","c":".c","cpp":".cpp","c++":".cpp","java":".java","csharp":".cs","c#":".cs","go":".go","rust":".rs","ruby":".rb","php":".php","bash":".sh","shell":".sh"}
        with tempfile.TemporaryDirectory(prefix="modkec-code-") as temp:
            root=Path(temp); suffix=suffixes[language]; path=root/("Main"+suffix if language=="java" else "main"+suffix); path.write_text(code,encoding="utf-8")
            candidates={
                "javascript":[["node",str(path)]],"js":[["node",str(path)]],
                "typescript":[["tsx",str(path)]],"ts":[["tsx",str(path)]],
                "lua":[["lua",str(path)]],"luau":[["luau",str(path)]],
                "c":[["cc",str(path),"-o",str(root/"program"),"-lm"],[str(root/"program")]],
                "cpp":[["c++",str(path),"-o",str(root/"program")],[str(root/"program")]],
                "java":[["javac",str(path)],["java","-cp",str(root),"Main"]],
                "go":[["go","run",str(path)]],"rust":[["rustc",str(path),"-o",str(root/"program")],[str(root/"program")]],
                "ruby":[["ruby",str(path)]],"php":[["php",str(path)]],"bash":[["bash",str(path)]],"shell":[["bash",str(path)]],
                "csharp":[["dotnet","script",str(path)]]}
            commands=candidates[language]
            for command in commands:
                # Later commands may be temporary executables created by an earlier compile step.
                if os.path.isabs(command[0]) and str(root) in command[0]:
                    continue
                if shutil.which(command[0]) is None:
                    raise ModkecError(f"Native block at line {self._python_start_line}: '{command[0]}' is not installed; cannot run {language} code.")
            try:
                for command in commands:
                    result=subprocess.run(command,cwd=temp,text=True,capture_output=True,timeout=15,check=False)
                    if result.stdout: self.output.extend(result.stdout.rstrip("\n").splitlines())
                    if result.stderr: self.output.extend("[stderr] "+line for line in result.stderr.rstrip("\n").splitlines())
                    if result.returncode != 0: raise ModkecError(f"{language} block failed (exit code {result.returncode}).")
            except subprocess.TimeoutExpired as exc:
                raise ModkecError(f"{language} block exceeded the 15-second execution limit.") from exc
            except OSError as exc:
                raise ModkecError(f"Could not launch {language} runtime: {exc}") from exc

    def _value(self, raw: str):
        raw=raw.strip()
        if raw in self.variables: return self.variables[raw]
        if raw=='t': return True
        if raw=='f': return False
        if raw in ('nil','null','none'): return None
        try: return ast.literal_eval(raw)
        except (ValueError,SyntaxError): pass
        if re.fullmatch(r'-?\d+(?:\.\d+)?',raw): return float(raw) if '.' in raw else int(raw)
        if any(op in raw for op in ('+', '-', '*', '/', '%', '>', '<', '[', '==')) or re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*\(.*\)',raw) or re.search(r'\s+(?:not\s+)?in\s+',raw):
            return self._expr(raw)
        if raw.startswith('[') or raw.startswith('{'):
            try: return ast.literal_eval(raw)
            except Exception: pass
        raise ModkecError(f"Unknown value '{raw}'. Use a quoted string, number, t/f, or an existing variable.")

    def _expr(self, raw: str):
        try: tree=ast.parse(raw.strip(),mode='eval')
        except SyntaxError as e: raise ModkecError(f"Couldn't parse expression '{raw}'.") from e
        def visit(n):
            if isinstance(n,ast.Expression): return visit(n.body)
            if isinstance(n,ast.Constant) and isinstance(n.value,(int,float,str,bool)): return n.value
            if isinstance(n,ast.Subscript):
                container=visit(n.value); index=visit(n.slice)
                return container[index]
            if isinstance(n,ast.List): return [visit(x) for x in n.elts]
            if isinstance(n,ast.Tuple): return tuple(visit(x) for x in n.elts)
            if isinstance(n,ast.Dict): return {visit(k):visit(v) for k,v in zip(n.keys,n.values)}
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and not n.keywords:
                degrees=self.variables.get('angle_mode','RAD')=='DEG'
                safe={'len':len,'str':str,'int':int,'float':float,'bool':bool,'abs':abs,'min':min,'max':max,'round':round,'sorted':sorted,'sum':sum,'any':any,'all':all,'range':range,'sqrt':math.sqrt,'sin':lambda x:math.sin(math.radians(x) if degrees else x),'cos':lambda x:math.cos(math.radians(x) if degrees else x),'tan':lambda x:math.tan(math.radians(x) if degrees else x),'asin':lambda x:math.degrees(math.asin(x)) if degrees else math.asin(x),'acos':lambda x:math.degrees(math.acos(x)) if degrees else math.acos(x),'atan':lambda x:math.degrees(math.atan(x)) if degrees else math.atan(x),'ln':math.log,'log':math.log10,'exp':math.exp,'floor':math.floor,'ceil':math.ceil,'factorial':math.factorial,'sinh':math.sinh,'cosh':math.cosh,'tanh':math.tanh,'type_of':lambda x: 'nil' if x is None else ('boolean' if isinstance(x,bool) else 'number' if isinstance(x,(int,float)) else 'text' if isinstance(x,str) else 'list' if isinstance(x,list) else 'object' if isinstance(x,dict) else 'tuple')}
                fn=safe.get(n.func.id)
                if fn is None: raise ModkecError(f"Function '{n.func.id}' is not available inside expressions.")
                args=[visit(x) for x in n.args]
                try:
                    result=fn(*args)
                    if isinstance(result,range): return list(result)
                    return result
                except (TypeError,ValueError,OverflowError) as e: raise ModkecError(f"{n.func.id}() failed: {e}") from e
            if isinstance(n,ast.Name):
                if n.id=='t': return True
                if n.id=='f': return False
                if n.id=='pi': return math.pi
                if n.id=='e': return math.e
                if n.id=='Ans': return self.variables.get('answer',0)
                if n.id in self.variables: return self.variables[n.id]
                raise ModkecError(f"Unknown variable '{n.id}'. Set it before using it.")
            if isinstance(n,ast.BinOp) and type(n.op) in BINOPS:
                left, right = visit(n.left), visit(n.right)
                if isinstance(n.op, ast.Pow):
                    if isinstance(right, (int, float)) and abs(right) > 10000:
                        raise ModkecError('Exponent is too large (maximum absolute exponent: 10,000).')
                return BINOPS[type(n.op)](left, right)
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd,ast.Not)):
                v=visit(n.operand); return -v if isinstance(n.op,ast.USub) else (+v if isinstance(n.op,ast.UAdd) else not v)
            if isinstance(n,ast.Compare) and len(n.ops)==1:
                left=visit(n.left); right=visit(n.comparators[0]); op=n.ops[0]
                if type(op) in CMPS: return CMPS[type(op)](left,right)
                if isinstance(op,ast.In): return left in right
                if isinstance(op,ast.NotIn): return left not in right
                raise ModkecError('Unsupported comparison operator.')
            if isinstance(n,ast.BoolOp):
                if isinstance(n.op, ast.And):
                    for item in n.values:
                        if not bool(visit(item)):
                            return False
                    return True
                if isinstance(n.op, ast.Or):
                    for item in n.values:
                        if bool(visit(item)):
                            return True
                    return False
                raise ModkecError('Unsupported boolean operator.')
            raise ModkecError('Unsupported expression.')
        try: return visit(tree)
        except (TypeError,ValueError,ZeroDivisionError,OverflowError) as e: raise ModkecError(f'Expression failed: {e}') from e

    def _need(self, module: str, command: str):
        if module not in self.imported_modules: raise ModkecError(f"{command}() requires import({module}).")

    def _normalize_module(self, raw: str) -> str:
        name = raw.strip().strip("'\"").lower()
        return MODULE_ALIASES.get(name, name.replace(' ', ''))

    def _import_module(self, module: str, stack: tuple[str, ...] = ()) -> None:
        known = set(MODULE_COMMANDS) | {'py'}
        known.update(self.extension_packages)
        if module not in known:
            raise ModkecError(f"Unknown module '{module}'. Available: {', '.join(sorted(known))}.")
        if module in stack:
            cycle = stack[stack.index(module):] + (module,)
            raise ModkecError('Circular module dependency: ' + ' -> '.join(cycle) + '.')
        if module in self.imported_modules:
            return

        if module in self.extension_packages:
            from .plugins import load_extension_package
            try:
                registered = load_extension_package(module)
                for name, (handler, _description) in registered.items():
                    if name not in self.extension_commands:
                        raise ValueError(f"Command {name!r} was not present in extension metadata.")
                    self.extension_commands[name] = (module, handler)
            except Exception as exc:
                raise ModkecError(f"Could not load extension '{module}': {type(exc).__name__}: {exc}") from exc

        dependencies = tuple(self._normalize_module(item) for item in MODULE_DEPENDENCIES.get(module, ()))
        for dependency in dependencies:
            self._import_module(dependency, stack + (module,))

        self.imported_modules.add(module)
        self.imported_module_dependencies[module] = dependencies
        self.module_import_order.append(module)
    def _name(self, raw):
        n=raw.strip()
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',n): raise ModkecError(f"'{n}' is not a valid variable or action name.")
        return n
    def _result(self, line, value):
        m=re.fullmatch(r'(.*?)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)\s*',line)
        if m: self.variables[m.group(2)]=value; return True
        return False
    def _execute_line(self,line,number):
        chained=split_commands(line)
        if len(chained)>1:
            for command_line in chained: self._execute_line(command_line,number)
            return
        # Result assignment: command(args) -> result
        core=line
        result_name=None
        m=re.fullmatch(r'(.*?)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)\s*',line)
        if m: core=m.group(1).strip(); result_name=m.group(2)
        # Original conditional syntax from the user's design.
        if core.startswith('if('):
            m=re.fullmatch(r'if\((.*)\)\s*=\s*([tf])\s*,\s*do\(([A-Za-z_][A-Za-z0-9_]*)\)',core)
            if not m: raise ModkecError('Use if(score > 10)=t, do(win).')
            condition=self._expr(m.group(1)); expected=m.group(2)=='t'; self._last_condition=bool(condition)==expected
            if self._last_condition: self._run_action(m.group(3))
            return
        # The compact control-flow syntax from the original specification.
        m=re.fullmatch(r'(repeat|while|on|timer)\((.*)\)\s+do\(([A-Za-z_][A-Za-z0-9_]*)\)',core)
        if m:
            control, raw, action = m.groups()
            self._need('web' if control=='timer' else 'logic', control)
            if control=='repeat':
                count=int(self._value(raw))
                for _ in range(max(0,min(count,10000))):
                    try: self._run_action(action)
                    except _BreakLoop: break
                return
            if control=='while':
                iterations=0
                while bool(self._expr(raw)) and iterations<10000:
                    try: self._run_action(action)
                    except _BreakLoop: break
                    iterations+=1
                if iterations>=10000: raise ModkecError('while() stopped after 10,000 iterations to prevent a runaway loop.')
                return
            if control=='on': self.events[raw.strip()]=action; return
            if control=='timer': time.sleep(max(0,min(float(self._value(raw)),30))); self._run_action(action); return
        if core.startswith('else()'):
            m=re.fullmatch(r'else\(\)\s+do\(([A-Za-z_][A-Za-z0-9_]*)\)',core)
            if not m: raise ModkecError('Use else() do(action_name).')
            self._need('logic','else')
            if self._last_condition is False: self._run_action(m.group(1))
            return
        cmd,args=call_parts(core)
        if cmd is None: raise ModkecError(f"Expected a command such as set(score, 10), got '{line}'.")
        # Action declarations are block syntax.
        if cmd in ('action','command'):
            if not args: raise ModkecError('action() needs an action name, optionally followed by parameter names.')
            name=self._name(args[0]); params=[self._name(x) for x in args[1:]]
            reserved={'say','ask','set','store','get','delete','increment','decrement','type_of','show','wait','stop','comment','import','run','translate','export','action','command','python','code','end','end_python'}
            reserved.update(command for commands in MODULE_COMMANDS.values() for command in commands)
            if cmd=='command' and name in reserved:
                raise ModkecError(f"'{name}' is already a Modkec command. Choose a different custom command name.")
            if len(set(params)) != len(params): raise ModkecError('An action cannot have duplicate parameter names.')
            self.actions[name]=[]; self.action_params[name]=params; self._active_action=name
            self._active_definition_kind=cmd
            if cmd=='command': self.custom_commands.add(name)
            return
        if cmd=='code':
            raise ModkecError('Use code(language) ... code(language) end with matching language names.')
        if cmd=='python':
            if args: raise ModkecError('Use python() ... end_python() with no arguments.')
            self._need('py','python')
            self._active_python=True; self._python_lines=[]; self._python_start_line=number; return
        if cmd=='end_python': raise ModkecError('end_python() only closes a python() block.')
        if cmd=='end': raise ModkecError('end() only closes an action() or command() definition.')
        # Core commands are always available.
        if cmd in ('set','store'):
            if len(args)!=2: raise ModkecError(f'{cmd}() needs a name and value.')
            try: value=self._value(args[1])
            except ModkecError: value=self._expr(args[1])
            target=args[0].strip()
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',target):
                self.variables[target]=value
                if cmd == 'store':
                    self.persistent_values[target] = value
                    self._save_persistent_values()
                return
            try: target_tree=ast.parse(target,mode='eval').body
            except SyntaxError as e: raise ModkecError('set() target must be a variable or an indexed list/object value.') from e
            if isinstance(target_tree,ast.Subscript) and isinstance(target_tree.value,ast.Name):
                base=target_tree.value.id
                if base not in self.variables: raise ModkecError(f"Variable '{base}' does not exist.")
                container=self.variables[base]; index=self._expr(ast.unparse(target_tree.slice))
                try: container[index]=value
                except (TypeError,IndexError,KeyError) as e: raise ModkecError(f'set() could not update {target}: {e}') from e
                return
            raise ModkecError('set() target must be a variable or an indexed list/object value.')
        if cmd=='get':
            if len(args)!=1: raise ModkecError('get() needs one variable name.')
            key = args[0].strip()
            if key not in self.variables and key in self.persistent_values:
                self.variables[key] = self.persistent_values[key]
            value=self.variables.get(key)
            if key not in self.variables: raise ModkecError(f"Variable '{key}' does not exist.")
            if result_name: self.variables[result_name]=value
            else: self.output.append(str(value))
            return
        if cmd=='delete':
            if len(args)!=1: raise ModkecError('delete() needs one variable name.')
            key = args[0].strip()
            self.variables.pop(key,None)
            if key in self.persistent_values:
                self.persistent_values.pop(key, None)
                self._save_persistent_values()
            return
        if cmd in ('increment','decrement'):
            if len(args) not in (1,2): raise ModkecError(f'{cmd}() needs a variable and optional amount.')
            name=self._name(args[0]); amount=self._value(args[1]) if len(args)==2 else 1
            current=self.variables.get(name,0)
            try: self.variables[name]=current+amount if cmd=='increment' else current-amount
            except TypeError as e: raise ModkecError(f'{cmd}() requires numeric values: {e}') from e
            return
        if cmd=='type_of':
            if len(args)!=1: raise ModkecError('type_of() needs one value.')
            value=self._value(args[0]); result='nil' if value is None else 'boolean' if isinstance(value,bool) else 'number' if isinstance(value,(int,float)) else 'text' if isinstance(value,str) else 'list' if isinstance(value,list) else 'object' if isinstance(value,dict) else 'unknown'
            if result_name: self.variables[result_name]=result
            else: self.output.append(result)
            return
        if cmd in ('say','show'):
            if len(args)!=1: raise ModkecError(f'{cmd}() needs one value.')
            raw=args[0]
            if cmd=='show' and 'visele' in self.imported_modules:
                try: candidate=str(self._value(raw))
                except ModkecError: candidate=raw.strip()
                matched=[v for v in self.visuals if v.get('name')==candidate or v.get('text')==candidate]
                if matched:
                    for v in matched: v['hidden']=False
                    return
            val=self._value(raw); self.output.append(str(val)); return
        if cmd=='ask':
            prompt=str(self._value(args[0])) if args else ''
            val=self.input_fn(prompt+' ')
            # Convert plain numeric answers so ask("Guess?") can be compared
            # directly with numeric variables; leave other answers as text.
            if isinstance(val, str):
                answer=val.strip()
                if re.fullmatch(r'-?(?:0|[1-9]\d*)', answer):
                    try: val=int(answer)
                    except ValueError: pass
                elif re.fullmatch(r'-?(?:0|[1-9]\d*)\.\d+', answer):
                    try: val=float(answer)
                    except ValueError: pass
            self.variables[result_name or 'answer']=val; return
        if cmd=='wait':
            if len(args)!=1: raise ModkecError('wait() needs seconds.')
            time.sleep(max(0,min(float(self._value(args[0])),30))); return
        if cmd=='stop': raise _StopProgram()
        if cmd=='comment': return
        if cmd=='import':
            if len(args)!=1: raise ModkecError('import() needs one module name.')
            module=self._normalize_module(args[0])
            self._import_module(module)
            return
        if cmd=='run':
            if len(args)==0:
                if 'visele' not in self.imported_modules: raise ModkecError('run() without an argument is for running a Visele interaction preview; use run("intro") for an action or script.')
                return
            if len(args)!=1: raise ModkecError('run() needs an action name or script path.')
            name=str(self._value(args[0])) if args[0].startswith(('"',"'")) else args[0].strip()
            if name in self.actions: self._run_action(name)
            else:
                path=Path(name)
                if not path.is_file(): raise ModkecError(f"No action or script named '{name}' was found.")
                nested=ModkecEngine(input_fn=self.input_fn, source_name=str(path.resolve()), media_callback=self.media_callback); nested.run(path.read_text(encoding='utf-8'))
                self.output.extend(nested.output); self.variables.update(nested.variables); self.visuals.extend(nested.visuals)
                self.media_actions.extend(nested.media_actions); self.animations.extend(nested.animations)
            return
        if cmd=='translate':
            if len(args)!=1: raise ModkecError('translate() needs a target language, such as translate(python).')
            target=args[0].strip().strip("'\"").lower()
            from .translator import translate
            try: generated=translate(self._source_text,target)
            except ModkecError: raise
            self.output.append(generated.rstrip())
            return
        if cmd=='export':
            raise ModkecError("Use translate(language) in Modkec code. Save generated code with Studio Export.")
        # command module lookup
        module=next((mod for mod,commands in MODULE_COMMANDS.items() if cmd in commands),None)
        if module:
            self._need(module,cmd)
            value=self._module_command(module,cmd,args)
            if result_name: self.variables[result_name]=value
            elif value is not _NO_OUTPUT and value is not None: self.output.append(str(value))
            return
        if cmd in self.custom_commands:
            call_args=[self._value(x) for x in args]
            result=self._run_action(cmd,call_args)
            if result_name: self.variables[result_name]=result
            elif result is not None: self.output.append(str(result))
            return
        if cmd in self.extension_commands:
            package_id, handler = self.extension_commands[cmd]
            if package_id not in self.imported_modules:
                raise ModkecError(f"{cmd}() requires import({package_id}).")
            from .plugins import ExtensionContext
            values = []
            for item in args:
                try:
                    values.append(self._value(item))
                except ModkecError:
                    # Bare identifiers are useful for extension enum/template arguments,
                    # e.g. calculator(basic). Existing variable names still resolve first.
                    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]*", item.strip()):
                        values.append(item.strip())
                    else:
                        raise
            try:
                result = handler(ExtensionContext(self, package_id), values)
            except ModkecError:
                raise
            except Exception as exc:
                raise ModkecError(f"Extension command '{cmd}' failed: {type(exc).__name__}: {exc}") from exc
            if result_name:
                self.variables[result_name] = result
            elif result is not None and result is not _NO_OUTPUT:
                self.output.append(str(result))
            return
        raise ModkecError(f"Unknown command '{cmd}'. Check the command reference or import its module.")

    def _record_media_action(self, command: str, args: list[Any]) -> None:
        """Record a media action and dispatch it immediately when a host is attached."""
        action = {"command": command, "args": list(args)}
        self.media_actions.append(action)
        if self.media_callback is not None:
            self.media_callback(action, self)

    def _persistent_path(self) -> Path:
        """Return the hidden persistence file beside the running source file."""
        source = Path(self.source_name).expanduser() if self.source_name else Path.cwd() / "__modkec_session__.modkec"
        return source.resolve().parent / ".modkec_store.json"

    def _load_persistent_values(self) -> None:
        try:
            raw = json.loads(self._persistent_path().read_text(encoding="utf-8"))
            self.persistent_values = raw if isinstance(raw, dict) else {}
        except (OSError, ValueError):
            self.persistent_values = {}

    def _save_persistent_values(self) -> None:
        path = self._persistent_path()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(self.persistent_values, ensure_ascii=False, indent=2), encoding="utf-8")
        except (OSError, TypeError, ValueError) as exc:
            raise ModkecError(f"Could not save persistent data to {path}: {exc}") from exc

    def _run_action(self,name,args=None):
        if name not in self.actions: raise ModkecError(f"Action '{name}' hasn't been defined. Define it with action({name}) ... end().")
        args=list(args or []); params=self.action_params.get(name,[])
        if len(args)!=len(params): raise ModkecError(f"Action '{name}' expects {len(params)} argument(s), but received {len(args)}.")
        if self._call_depth>=200: raise ModkecError('Maximum action call depth (200) exceeded; check for runaway recursion.')
        missing=object(); previous={p:self.variables.get(p,missing) for p in params}
        self.variables.update(zip(params,args)); self._call_depth+=1
        try:
            for number,line in self.actions[name]:
                if self.variables.pop('_cancelled_'+name, False):
                    break
                try: self._execute_line(line,number)
                except _ReturnAction as returned: return returned.value
                except _StopProgram: raise
        finally:
            self._call_depth-=1
            for p,old in previous.items():
                if old is missing: self.variables.pop(p,None)
                else: self.variables[p]=old

    def _visual_target_indexes(self, target):
        if isinstance(target, (int, float)) and int(target) == target:
            index = int(target)
            return [index] if 0 <= index < len(self.visuals) else []
        key = str(target)
        if key.lower() == 'last': return [len(self.visuals) - 1] if self.visuals else []
        if key.isdigit():
            index = int(key)
            return [index] if 0 <= index < len(self.visuals) else []
        return [i for i, item in enumerate(self.visuals) if item.get('name') == key or item.get('text') == key]

    def _module_command(self,module,cmd,a):
        if module=='visele' and cmd=='hex':
            raw=a[0].strip().strip("'\"#") if a else ''
            if not re.fullmatch(r'[0-9a-fA-F]{6}',raw): raise ModkecError('hex() expects six hexadecimal digits, for example hex(FF0000).')
            color='#'+raw; self.variables['_visele_color']=color
            if self.visuals: self.visuals[-1]['color']=color
            return _NO_OUTPUT
        if module=='visele' and cmd=='button':
            self._need('visele','button')
            if len(a) < 3 or len(a) > 4:
                raise ModkecError('Use button(label, x, y, optional_action_name).')
            label=str(self._value(a[0])); x=int(self._value(a[1])); y=int(self._value(a[2]))
            action=a[3].strip().strip("'\"") if len(a)==4 else None
            self.visuals.append({'kind':'button','name':label,'path':label,'text':label,'x':x,'y':y,'w':58,'h':35,'color':self.variables.get('_visele_color','#000000'),'layer':0,'opacity':100,'hidden':False,'interactive':True,'action':action})
            return _NO_OUTPUT
        if module=='visele' and cmd=='update_text':
            self._need('visele','update_text')
            if len(a)!=2: raise ModkecError('Use update_text(name, value).')
            name=str(self._value(a[0])); value=str(self._value(a[1]))
            matches=[item for item in self.visuals if item.get('kind')=='text' and item.get('name')==name]
            if not matches: raise ModkecError(f"update_text(): no text element named '{name}'.")
            for item in matches: item['text']=value
            return _NO_OUTPUT
        if module=='calculator' and cmd=='evaluate':
            self._need('calculator','evaluate')
            if len(a)!=1: raise ModkecError('Use evaluate("sin(30) + 2^3").')
            raw=a[0].strip()
            if raw in self.variables: raw=str(self.variables[raw])
            elif len(raw)>=2 and raw[0]==raw[-1] and raw[0] in "'\"": raw=raw[1:-1]
            raw=re.sub(r'(?<![A-Za-z0-9_])(\d+(?:\.\d+)?)!',r'factorial(\1)',raw)
            raw=raw.replace('^','**')
            try:
                tree=ast.parse(raw,mode='eval')
                for node in ast.walk(tree):
                    if isinstance(node,(ast.Attribute,ast.Subscript,ast.Lambda,ast.ListComp,ast.DictComp,ast.SetComp,ast.GeneratorExp,ast.Compare,ast.BoolOp)):
                        raise ModkecError('Unsupported mathematical expression.')
                value=self._expr(raw)
                if isinstance(value,bool) or not isinstance(value,(int,float)): raise ModkecError('Expression did not produce a number.')
                if not math.isfinite(value): raise ModkecError('Result is not finite.')
                return value
            except (SyntaxError,ValueError,TypeError,ZeroDivisionError,OverflowError) as exc:
                raise ModkecError(f'evaluate() failed: {exc}') from exc
        if module=='data' and cmd in ('list','object'):
            if len(a)!=1: raise ModkecError(f'{cmd}() needs a variable name.')
            name=self._name(a[0]); value=[] if cmd=='list' else {}; self.variables[name]=value; return _NO_OUTPUT
        if module=='actions' and cmd in ('do','call','trigger','cancel','event'):
            if not a: raise ModkecError(f'{cmd}() needs an action or event name.')
            name=a[0].strip().strip("'\"")
            if cmd in ('do','call'):
                call_args=[self._value(x) for x in a[1:]]
                result=self._run_action(name,call_args)
                return result if cmd=='call' else _NO_OUTPUT
            if len(a)!=1: raise ModkecError(f'{cmd}() needs one action or event name.')
            if cmd=='trigger': self._run_action(self.events.get(name,name)); return _NO_OUTPUT
            if cmd=='cancel': self.variables['_cancelled_'+name]=True; return _NO_OUTPUT
            return name
        if module=='actions' and cmd=='input':
            if len(a)!=1: raise ModkecError('input() needs one variable name.')
            return self.variables.get(a[0].strip(), '')
        vals=[self._value(x) for x in a]
        if module=='calculator':
            ops={'add':lambda:vals[0]+vals[1],'subtract':lambda:vals[0]-vals[1],'multiply':lambda:vals[0]*vals[1],'divide':lambda:vals[0]/vals[1],'mod':lambda:vals[0]%vals[1],'power':lambda:vals[0]**vals[1],'round':lambda:round(vals[0]),'floor':lambda:math.floor(vals[0]),'ceil':lambda:math.ceil(vals[0]),'absolute':lambda:abs(vals[0]),'min':lambda:min(vals),'max':lambda:max(vals),'random':lambda:random.randint(int(vals[0]),int(vals[1])),'percentage':lambda:vals[0]/vals[1]*100,'sqrt':lambda:math.sqrt(vals[0]),'sin':lambda:math.sin(vals[0]),'cos':lambda:math.cos(vals[0]),'tan':lambda:math.tan(vals[0]),'asin':lambda:math.asin(vals[0]),'acos':lambda:math.acos(vals[0]),'atan':lambda:math.atan(vals[0]),'ln':lambda:math.log(vals[0]),'log':lambda:math.log10(vals[0]),'exp':lambda:math.exp(vals[0]),'factorial':lambda:math.factorial(int(vals[0]))}
            try: return ops[cmd]()
            except (IndexError,ZeroDivisionError,ValueError,TypeError) as e: raise ModkecError(f'{cmd}() failed: {e}') from e
        if module=='logic':
            if cmd=='equal': return vals[0]==vals[1]
            if cmd=='greater': return vals[0]>vals[1]
            if cmd=='less': return vals[0]<vals[1]
            if cmd=='and': return all(vals)
            if cmd=='or': return any(vals)
            if cmd=='not': return not vals[0]
            if cmd=='else':
                if self._last_condition is False and len(a)==1: self._run_action(str(a[0]))
                return _NO_OUTPUT
            if cmd=='repeat':
                count=int(vals[0]); action=a[1].strip() if len(a)>1 else ''
                if action.startswith('do('): action=action[3:-1]
                if not action: raise ModkecError('Use repeat(5, do(action_name)).')
                for _ in range(max(0,min(count,10000))): self._run_action(action)
                return _NO_OUTPUT
            if cmd=='while':
                action=a[1].strip() if len(a)>1 else ''
                if action.startswith('do('): action=action[3:-1]
                iterations=0
                while bool(self._expr(a[0])) and iterations<10000:
                    self._run_action(action); iterations+=1
                if iterations>=10000: raise ModkecError('while() stopped after 10,000 iterations to prevent a runaway loop.')
                return _NO_OUTPUT
            if cmd=='break': raise _BreakLoop()
            if cmd=='on':
                m=re.fullmatch(r'on\(([^)]+)\)\s*do\(([^)]+)\)',','.join(a))
                if m: self.events[m.group(1)]=m.group(2); return _NO_OUTPUT
                if len(a)==2: self.events[str(vals[0])]=str(vals[1]); return _NO_OUTPUT
                raise ModkecError('Use on(start, begin) to connect an event to an action.')
            if cmd=='wait_until':
                tries=0
                while not bool(self._expr(a[0])) and tries<300: time.sleep(.1); tries+=1
                if tries>=300: raise ModkecError('wait_until() timed out after 30 seconds.')
                return _NO_OUTPUT
        if module=='actions':
            if cmd in ('do','call','trigger'):
                name=str(vals[0]); name=self.events.get(name,name) if cmd=='trigger' else name
                self._run_action(name); return _NO_OUTPUT
            if cmd=='return': raise _ReturnAction(vals[0] if vals else None)
            if cmd=='input':
                if len(a)!=1: raise ModkecError('input() needs a variable name.')
                return self.variables.get(str(a[0]),'')
            if cmd=='event':
                if len(a)!=1: raise ModkecError('event() needs an event name.')
                return str(vals[0])
            if cmd=='cancel': self.variables['_cancelled_'+str(vals[0])]=True; return _NO_OUTPUT
        if module=='data':
            if cmd=='list': return list(vals)
            if cmd=='append': vals[0].append(vals[1]); return _NO_OUTPUT
            if cmd=='remove_item':
                try: vals[0].remove(vals[1])
                except ValueError: pass
                return _NO_OUTPUT
            if cmd=='count': return len(vals[0])
            if cmd=='contains': return vals[1] in vals[0]
            if cmd=='sort': vals[0].sort(); return _NO_OUTPUT
            if cmd=='reverse': vals[0].reverse(); return _NO_OUTPUT
            if cmd=='object': return {}
            if cmd=='key': return vals[0].get(vals[1]) if isinstance(vals[0],dict) else None
            if cmd=='save':
                self._need('files',cmd); Path(str(vals[0])).write_text(json.dumps(vals[1],indent=2),encoding='utf-8'); return _NO_OUTPUT
            if cmd=='load':
                self._need('files',cmd); return json.loads(Path(str(vals[0])).read_text(encoding='utf-8'))
            if cmd=='dimp':
                self._need('files',cmd); return json.loads(Path(str(vals[0])).read_text(encoding='utf-8'))
        if module=='text':
            if cmd=='join': return ''.join(str(x) for x in vals)
            if cmd=='drop_last': return str(vals[0])[:-1] if vals else ''
            if cmd=='length': return len(str(vals[0]))
            if cmd=='upper': return str(vals[0]).upper()
            if cmd=='lower': return str(vals[0]).lower()
            if cmd=='replace': return str(vals[0]).replace(str(vals[1]),str(vals[2]))
            if cmd=='contains_text': return str(vals[1]) in str(vals[0])
            if cmd=='split': return str(vals[0]).split(str(vals[1]))
            if cmd=='trim': return str(vals[0]).strip()
            if cmd=='number':
                s=str(vals[0]); return float(s) if '.' in s else int(s)
            if cmd=='format':
                s=str(vals[0])
                for k,v in self.variables.items(): s=s.replace('{'+k+'}',str(v))
                return s
        if module=='files':
            if cmd=='dimp':
                path=Path(str(vals[0])); raw=path.read_text(encoding='utf-8')
                try: return json.loads(raw)
                except json.JSONDecodeError: return raw
            if cmd=='read_file': return Path(str(vals[0])).read_text(encoding='utf-8')
            if cmd=='write_file': Path(str(vals[0])).write_text(str(vals[1]),encoding='utf-8'); return _NO_OUTPUT
            if cmd=='file_exists': return Path(str(vals[0])).is_file()
            if cmd=='copy_file': shutil.copy2(str(vals[0]),str(vals[1])); return _NO_OUTPUT
            if cmd=='rename_file': Path(str(vals[0])).rename(str(vals[1])); return _NO_OUTPUT
            if cmd=='list_files': return [p.name for p in Path(str(vals[0])).iterdir()]
            if cmd=='create_folder': Path(str(vals[0])).mkdir(parents=True,exist_ok=True); return _NO_OUTPUT
        if module=='web':
            if cmd.startswith('site_'):
                if self.site_builder is None and cmd != 'site_start': raise ModkecError(f"{cmd}() requires site_start() first.")
                if cmd == 'site_start':
                    if not vals: raise ModkecError('site_start(title, tagline) needs at least a title.')
                    self.site_builder = SiteBuilder(); self.site_builder.title = str(vals[0]); self.site_builder.tagline = str(vals[1]) if len(vals)>1 else ''
                    return _NO_OUTPUT
                site = self.site_builder
                if cmd == 'site_nav_item':
                    if len(vals) != 2: raise ModkecError('site_nav_item(label, target) needs two values.')
                    site.nav.append((str(vals[0]), str(vals[1]))); return _NO_OUTPUT
                if cmd == 'site_hero': site.add('hero', *vals); return _NO_OUTPUT
                if cmd == 'site_text': site.add('text', *vals); return _NO_OUTPUT
                if cmd == 'site_button': site.add('button', *vals); return _NO_OUTPUT
                if cmd == 'site_image': site.add('image', *vals); return _NO_OUTPUT
                if cmd == 'site_link': site.add('link', *vals); return _NO_OUTPUT
                if cmd == 'site_theme':
                    if len(vals) not in (1, 2): raise ModkecError('site_theme(primary_color, optional_background_color) needs one or two values.')
                    site.theme = {'primary': str(vals[0]), 'background': str(vals[1]) if len(vals) > 1 else site.theme.get('background', '#0d0c14')}
                    return _NO_OUTPUT
                if cmd == 'site_custom_css':
                    if len(vals) != 1: raise ModkecError('site_custom_css(css_text) needs one value.')
                    site.custom_css.append(str(vals[0])); return _NO_OUTPUT
                if cmd == 'site_stat': site.add('stat', *vals); return _NO_OUTPUT
                if cmd == 'site_section':
                    if len(vals) < 4: raise ModkecError('site_section(id, kicker, title, description, optional_style) needs four values.')
                    site.add('section', *vals); return _NO_OUTPUT
                if cmd == 'site_card': site.add('card', *vals); return _NO_OUTPUT
                if cmd == 'site_search': site.add('search', *vals); return _NO_OUTPUT
                if cmd == 'site_list_start': site.add('list_start', *vals); return _NO_OUTPUT
                if cmd == 'site_list_end': site.add('list_end', *vals); return _NO_OUTPUT
                if cmd == 'site_download': site.add('download', *vals); return _NO_OUTPUT
                if cmd == 'site_depot': site.add('depot', *vals); return _NO_OUTPUT
                if cmd == 'site_empty': site.add('empty', *vals); return _NO_OUTPUT
                if cmd == 'site_warning': site.add('warning', *vals); return _NO_OUTPUT
                if cmd == 'site_step': site.add('step', *vals); return _NO_OUTPUT
                if cmd == 'site_command': site.add('command', *vals); return _NO_OUTPUT
                if cmd == 'site_faq': site.add('faq', *vals); return _NO_OUTPUT
                if cmd == 'site_code': site.add('code', *vals); return _NO_OUTPUT
                if cmd == 'site_footer': site.footer = {'kind':'footer','values':list(vals)}; return _NO_OUTPUT
                if cmd == 'site_build':
                    if len(vals) != 1: raise ModkecError('site_build(path) needs an output path.')
                    try: result = build_site(site, str(vals[0]))
                    except OSError as exc: raise ModkecError(f'Could not build website: {exc}') from exc
                    self.output.append('Website generated: ' + result); return _NO_OUTPUT
            
            if cmd=='open_url': webbrowser.open(str(vals[0])); return _NO_OUTPUT
            if cmd in ('request','get_page'):
                if cmd=='request': method,url=str(vals[0]).upper(),str(vals[1])
                else: method,url='GET',str(vals[0])
                req=urllib.request.Request(url,method=method)
                with urllib.request.urlopen(req,timeout=10) as response: return response.read(1_000_000).decode('utf-8','replace')
            if cmd=='send':
                if len(vals) not in (2, 3): raise ModkecError('Use send(url, data, optional_content_type).')
                url = str(vals[0])
                payload = vals[1]
                content_type = str(vals[2]) if len(vals) == 3 else ('application/json' if not isinstance(payload, str) else 'text/plain; charset=utf-8')
                body = payload.encode('utf-8') if isinstance(payload, str) else json.dumps(payload).encode('utf-8')
                request = urllib.request.Request(url, data=body, headers={'Content-Type': content_type}, method='POST')
                try:
                    with urllib.request.urlopen(request, timeout=10) as response:
                        return response.read(1_000_000).decode('utf-8', 'replace')
                except Exception as exc:
                    raise ModkecError(f'send() request failed: {type(exc).__name__}: {exc}') from exc
            if cmd=='listen': raise ModkecError('listen() needs a runtime event source; it is not enabled in this starter.')
            if cmd=='timer':
                seconds=float(vals[0]); action=a[1].strip() if len(a)>1 else ''
                if action.startswith('do('): action=action[3:-1]
                time.sleep(max(0,min(seconds,30))); self._run_action(action); return _NO_OUTPUT
        if module=='visele':
            if cmd=='clear': self.visuals=[]; return _NO_OUTPUT
            if cmd=='rgb':
                color='#%02x%02x%02x'%tuple(max(0,min(255,int(v))) for v in vals[:3]); self.variables['_visele_color']=color
                if self.visuals: self.visuals[-1]['color']=color
                return _NO_OUTPUT
            if cmd in ('c1','c2','c3','c4'): self.variables['_'+cmd]=vals[0]; return _NO_OUTPUT
            if cmd=='p':
                x=int(vals[0]); y=int(vals[1]) if len(vals)>1 else 0
                self.visuals.append(dict(kind='pixel',x=x,y=y,color=self.variables.get('_visele_color','#000000'),layer=0)); return _NO_OUTPUT
            if cmd in ('rect','square','circle','line','text','image','button'):
                kind=cmd; item={'kind':kind,'color':self.variables.get('_visele_color','#000000'),'layer':0,'opacity':100,'hidden':False,'interactive':False}
                if cmd=='rect': item.update(x=int(vals[0]),y=int(vals[1]),w=int(vals[2]),h=int(vals[3]))
                elif cmd=='square': item.update(x=int(vals[0]),y=int(vals[1]),w=int(vals[2]),h=int(vals[2]))
                elif cmd in ('circle',): item.update(x=int(vals[0]),y=int(vals[1]),r=int(vals[2]))
                elif cmd=='line': item.update(x1=int(vals[0]),y1=int(vals[1]),x2=int(vals[2]),y2=int(vals[3]))
                elif cmd=='text': item.update(text=str(vals[0]),x=int(vals[1]) if len(vals)>1 else 10,y=int(vals[2]) if len(vals)>2 else 20,name=str(vals[3]) if len(vals)>3 else str(vals[0]))
                elif cmd=='image':
                    if len(vals) not in (1, 3, 5):
                        raise ModkecError('Use image(path), image(path, x, y), or image(path, x, y, width, height).')
                    item.update(name=str(vals[0]),path=str(vals[0]),x=int(vals[1]) if len(vals)>1 else 10,y=int(vals[2]) if len(vals)>2 else 10,w=int(vals[3]) if len(vals)>3 else 100,h=int(vals[4]) if len(vals)>4 else 100)
                elif cmd=='button': item.update(name=str(vals[0]),path=str(vals[0]),text=str(vals[0]),x=int(vals[1]) if len(vals)>1 else 10,y=int(vals[2]) if len(vals)>2 else 10,w=100,h=35)
                self.visuals.append(item); return _NO_OUTPUT
            if cmd in ('move','resize','hide','show','remove','interact','layer','opacity'):
                # Modify the most recently created item when no element name is supplied.
                target=None; extras=[]
                if cmd in ('move','resize') and len(vals)>=2: extras=vals
                elif cmd in ('hide','show','remove') and vals:
                    target=next((v for v in self.visuals if v.get('name')==str(vals[0]) or v.get('text')==str(vals[0])),None)
                elif vals: extras=vals
                item=target or (self.visuals[-1] if self.visuals else None)
                if cmd=='interact':
                    enabled=bool(vals[0]) if vals else True
                    for v in self.visuals: v['interactive']=enabled
                    return _NO_OUTPUT
                if item is None: raise ModkecError(f'{cmd}() needs an existing visual element.')
                if cmd=='move': item.update(x=int(vals[0]),y=int(vals[1]))
                elif cmd=='resize': item.update(w=int(vals[0]),h=int(vals[1]))
                elif cmd=='hide': item['hidden']=True
                elif cmd=='show': item['hidden']=False
                elif cmd=='remove': self.visuals.remove(item)
                elif cmd=='layer': item['layer']=int(vals[0])
                elif cmd=='opacity': item['opacity']=max(0,min(100,int(vals[0])))
                return _NO_OUTPUT
        if module=='translation':
            if cmd=='check':
                depth=0
                for line_no, raw in enumerate(self._source_text.splitlines(),1):
                    line=raw.strip()
                    if not line or line.startswith('#') or line.startswith('if(') or line.startswith(('repeat(', 'while(', 'on(')): continue
                    if line.startswith('action('): depth+=1
                    elif line=='end()': depth-=1
                    if depth<0: raise ModkecError(f'Line {line_no}: end() has no matching action().')
                if depth: raise ModkecError('An action definition is missing end().')
                return 'Basic structure checks passed. This is not a full static analysis.'
            if cmd=='explain':
                notes=[]
                for raw in self._source_text.splitlines():
                    line=raw.strip()
                    if not line or line.startswith('#'): continue
                    command,_=call_parts(line)
                    if command: notes.append(f'{command}(): {COMMAND_DESCRIPTIONS.get(command, "command or module instruction")}.')
                    elif line.startswith('if('): notes.append('if: checks a condition and may run an action.')
                    else: notes.append(f'{line}: control-flow or combined command.')
                return '\n'.join(notes) if notes else 'The program is empty.'
        if module=='media':
            if cmd in ('animate', 'fade', 'rotate', 'stop_animation'):
                if not self.visuals: raise ModkecError(f'{cmd}() needs at least one Visele element; create one with import(visele) first.')
                if cmd == 'stop_animation':
                    target = str(vals[0]) if vals else 'all'
                    if target == 'all': self.animations.clear()
                    else:
                        indexes = self._visual_target_indexes(target)
                        self.animations = [a for a in self.animations if a.get('target_index') not in indexes]
                    return _NO_OUTPUT
                target_index = len(self.visuals) - 1
                if cmd == 'animate':
                    if len(vals) == 4:
                        prop, start, end, duration = vals
                    elif len(vals) == 5:
                        target, prop, start, end, duration = vals
                        indexes = self._visual_target_indexes(target)
                        if not indexes: raise ModkecError(f'animate(): no visual element matches {target!r}.')
                        target_index = indexes[0]
                    else:
                        raise ModkecError('Use animate(property, from, to, seconds) on the last element, or animate(target, property, from, to, seconds).')
                    prop = str(prop).lower()
                    if prop not in {'x','y','w','h','r','opacity'}: raise ModkecError('animate() property must be x, y, w, h, r, or opacity.')
                    try: start, end, duration = float(start), float(end), float(duration)
                    except (TypeError, ValueError) as exc: raise ModkecError('animate() start, end, and duration must be numbers.') from exc
                    if duration <= 0 or duration > 120: raise ModkecError('animate() duration must be greater than 0 and at most 120 seconds.')
                    item=self.visuals[target_index]
                    if prop not in item: item[prop] = 100 if prop == 'opacity' else 0
                    item[prop] = start
                    self.animations.append({'target_index':target_index,'property':prop,'start':start,'end':end,'duration':duration,'kind':'property'})
                    return _NO_OUTPUT
                if cmd == 'fade':
                    if len(vals) == 3:
                        start, end, duration = vals
                    elif len(vals) == 4:
                        target, start, end, duration = vals
                        indexes = self._visual_target_indexes(target)
                        if not indexes: raise ModkecError(f'fade(): no visual element matches {target!r}.')
                        target_index = indexes[0]
                    else: raise ModkecError('Use fade(from_opacity, to_opacity, seconds) on the last element, or fade(target, from_opacity, to_opacity, seconds).')
                    try: start, end, duration = float(start), float(end), float(duration)
                    except (TypeError, ValueError) as exc: raise ModkecError('fade() values must be numbers.') from exc
                    if duration <= 0 or duration > 120: raise ModkecError('fade() duration must be greater than 0 and at most 120 seconds.')
                    start=max(0,min(100,start)); end=max(0,min(100,end))
                    self.visuals[target_index]['opacity']=start
                    self.animations.append({'target_index':target_index,'property':'opacity','start':start,'end':end,'duration':duration,'kind':'fade'})
                    return _NO_OUTPUT
                if cmd == 'rotate':
                    if len(vals) == 2:
                        degrees, duration = vals
                    elif len(vals) == 3:
                        target, degrees, duration = vals
                        indexes = self._visual_target_indexes(target)
                        if not indexes: raise ModkecError(f'rotate(): no visual element matches {target!r}.')
                        target_index = indexes[0]
                    else: raise ModkecError('Use rotate(degrees, seconds) on the last element, or rotate(target, degrees, seconds).')
                    try: degrees, duration = float(degrees), float(duration)
                    except (TypeError, ValueError) as exc: raise ModkecError('rotate() values must be numbers.') from exc
                    if duration <= 0 or duration > 120: raise ModkecError('rotate() duration must be greater than 0 and at most 120 seconds.')
                    self.animations.append({'target_index':target_index,'property':'rotation','start':0.0,'end':degrees,'duration':duration,'kind':'rotate'})
                    return _NO_OUTPUT
            if cmd == 'play_sound':
                if len(vals) not in (1, 2): raise ModkecError('Use play_sound(path, optional_loop_boolean).')
                self._record_media_action(cmd, vals)
                return _NO_OUTPUT
            if cmd == 'stop_sound':
                if len(vals) > 1: raise ModkecError('Use stop_sound() or stop_sound(path).')
                self._record_media_action(cmd, vals)
                return _NO_OUTPUT
            if cmd == 'volume':
                if len(vals) != 1: raise ModkecError('Use volume(level) with a value from 0 to 100.')
                try: level = float(vals[0])
                except (TypeError, ValueError) as exc: raise ModkecError('volume() needs a number from 0 to 100.') from exc
                if not 0 <= level <= 100: raise ModkecError('volume() must be between 0 and 100.')
                self._record_media_action(cmd, [level])
                return _NO_OUTPUT
            if cmd == 'play_video':
                if len(vals) != 1: raise ModkecError('Use play_video(path).')
                self._record_media_action(cmd, vals)
                return _NO_OUTPUT
            raise ModkecError(f'{cmd}() has no runtime implementation.')
        raise ModkecError(f'{cmd}() is listed but not implemented yet.')

class _StopProgram(Exception): pass
class _BreakLoop(Exception): pass
class _ReturnAction(Exception):
    def __init__(self, value): self.value=value
_NO_OUTPUT=object()
