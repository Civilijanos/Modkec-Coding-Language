"""Local, opt-in Modkec community extension API.

Extensions are ordinary Python programs. Loading one grants it the same access
as running Python directly, so Studio requires an explicit user install action
and never installs a package from a URL automatically.
"""
from __future__ import annotations

import importlib.util
import json
import re
import shutil
import tempfile
import zipfile
from pathlib import PurePosixPath
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .extensions import extension_directory

API_VERSION = 1
MAX_ARCHIVE_BYTES = 10 * 1024 * 1024
MAX_UNPACKED_BYTES = 10 * 1024 * 1024
MAX_FILES = 200
EXTENSION_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{1,63}$")


@dataclass
class ExtensionContext:
    """Supported API exposed to community command handlers."""
    engine: Any
    extension_id: str

    @property
    def variables(self) -> dict[str, Any]:
        return self.engine.variables

    @property
    def output(self) -> list[str]:
        return self.engine.output

    @property
    def project_directory(self) -> Path:
        source = Path(self.engine.source_name).expanduser() if self.engine.source_name else Path.cwd()
        return source.resolve().parent if source.suffix else source.resolve()

    def evaluate(self, expression: str) -> Any:
        """Evaluate a Modkec expression with the same semantics as the interpreter."""
        return self.engine._value(expression)

    def say(self, value: Any) -> None:
        self.engine.output.append(str(value))

    def set_variable(self, name: str, value: Any) -> None:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(name)):
            raise ValueError("Variable names must be valid Modkec identifiers.")
        self.engine.variables[str(name)] = value


class ExtensionAPI:
    """Registration surface passed to an extension's ``register(api)`` hook."""
    def __init__(self, extension_id: str) -> None:
        self.extension_id = extension_id
        self.commands: dict[str, tuple[Callable[..., Any], str]] = {}

    def register_command(self, name: str, handler: Callable[..., Any], description: str = "Community extension command") -> None:
        if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
            raise ValueError("Command names must be Python-style identifiers.")
        if name in self.commands:
            raise ValueError(f"Command {name!r} is already registered by this extension.")
        if not callable(handler):
            raise TypeError("Command handler must be callable.")
        self.commands[name] = (handler, str(description))


def community_extension_directory() -> Path:
    return extension_directory() / "community"


def _read_manifest(folder: Path) -> dict[str, Any]:
    candidates = (folder / "modkec-extension.json", folder / "extension.json")
    manifest_path = next((item for item in candidates if item.is_file()), None)
    if manifest_path is None:
        raise ValueError("Extension package must contain modkec-extension.json.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError("Extension manifest must be a JSON object.")
    extension_id = manifest.get("id")
    if not isinstance(extension_id, str) or not EXTENSION_ID_RE.fullmatch(extension_id):
        raise ValueError("Manifest id must be 2–64 lowercase letters, numbers, dots, underscores, or hyphens, starting with a letter/number.")
    if manifest.get("api_version") != API_VERSION:
        raise ValueError(f"Extension API version must be {API_VERSION}.")
    entrypoint = manifest.get("entrypoint", "main.py")
    if not isinstance(entrypoint, str) or not entrypoint.endswith(".py") or Path(entrypoint).is_absolute() or ".." in Path(entrypoint).parts:
        raise ValueError("entrypoint must be a relative Python file inside the package.")
    entry = (folder / entrypoint).resolve()
    if folder.resolve() not in entry.parents or not entry.is_file():
        raise ValueError("The extension entrypoint is missing or escapes the package directory.")
    commands = manifest.get("commands", [])
    if not isinstance(commands, list) or any(not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) for name in commands):
        raise ValueError("Manifest commands must be a list of command identifiers.")
    return {**manifest, "entrypoint": entrypoint, "commands": commands}


def list_community_extensions() -> list[dict[str, Any]]:
    root = community_extension_directory()
    if not root.is_dir():
        return []
    result = []
    for folder in sorted(root.iterdir(), key=lambda item: item.name.casefold()):
        if not folder.is_dir():
            continue
        try:
            manifest = _read_manifest(folder)
            result.append({"id": manifest["id"], "name": str(manifest.get("name") or manifest["id"]),
                           "version": str(manifest.get("version") or "0.0.0"),
                           "commands": list(manifest["commands"]), "folder": folder, "error": ""})
        except Exception as exc:
            result.append({"id": folder.name, "name": folder.name, "version": "—", "commands": [],
                           "folder": folder, "error": str(exc)})
    return result


def _load_extension_module(folder: Path, manifest: dict[str, Any]) -> dict[str, tuple[Callable[..., Any], str]]:
    ext_id = manifest["id"]
    entry = (folder / manifest["entrypoint"]).resolve()
    module_key = "_modkec_extension_" + re.sub(r"[^A-Za-z0-9_]", "_", ext_id)
    spec = importlib.util.spec_from_file_location(module_key, entry)
    if spec is None or spec.loader is None:
        raise ValueError("Could not load extension entrypoint.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    api = ExtensionAPI(ext_id)
    register = getattr(module, "register", None)
    if callable(register):
        register(api)
    elif isinstance(getattr(module, "COMMANDS", None), dict):
        for name, handler in module.COMMANDS.items():
            api.register_command(name, handler)
    else:
        raise ValueError("Entry point must define register(api) or a COMMANDS mapping.")
    manifest_names = set(manifest["commands"])
    actual_names = set(api.commands)
    if manifest_names and manifest_names != actual_names:
        raise ValueError("Manifest commands do not match the commands registered by the entrypoint.")
    if not manifest_names:
        raise ValueError("Manifest must declare at least one command.")
    return api.commands


def load_extension_package(extension_id: str) -> dict[str, tuple[Callable[..., Any], str]]:
    """Load one extension's Python entrypoint. Called only by import(extension_id)."""
    if not EXTENSION_ID_RE.fullmatch(extension_id):
        raise ValueError("Invalid extension ID.")
    folder = (community_extension_directory() / extension_id).resolve()
    root = community_extension_directory().resolve()
    if root not in folder.parents:
        raise ValueError("Extension path escaped the community extension directory.")
    manifest = _read_manifest(folder)
    if manifest["id"] != extension_id:
        raise ValueError("The extension folder name must match the manifest id.")
    return _load_extension_module(folder, manifest)


def load_installed_extensions(load_code: bool = False) -> tuple[dict[str, tuple[str, Callable[..., Any] | None]], dict[str, tuple[str, ...]], list[str]]:
    """Read extension metadata. Python entrypoints load lazily when import(id) is run."""
    commands: dict[str, tuple[str, Callable[..., Any] | None]] = {}
    packages: dict[str, tuple[str, ...]] = {}
    errors: list[str] = []
    reserved = {"say", "ask", "set", "store", "get", "delete", "increment", "decrement", "type_of", "show", "wait", "stop", "comment", "import", "run", "translate", "export", "action", "command", "python", "end", "end_python"}
    from .engine import MODULE_COMMANDS
    reserved.update(command for names in MODULE_COMMANDS.values() for command in names)
    for item in list_community_extensions():
        folder = Path(item["folder"])
        try:
            manifest = _read_manifest(folder)
            ext_id = manifest["id"]
            packages[ext_id] = tuple(manifest["commands"])
            loaded_commands = _load_extension_module(folder, manifest) if load_code else {name: (None, "") for name in manifest["commands"]}
            for name, (handler, _description) in loaded_commands.items():
                if name in reserved:
                    raise ValueError(f"Extension command {name!r} conflicts with a built-in Modkec command.")
                if name in commands:
                    raise ValueError(f"Extension command {name!r} conflicts with another installed extension.")
                commands[name] = (ext_id, handler)
        except Exception as exc:
            errors.append(f"{folder.name}: {type(exc).__name__}: {exc}")
    return commands, packages, errors


def install_extension_archive(archive_path: str | Path) -> dict[str, Any]:
    """Validate and install a local extension ZIP. Does not fetch remote packages."""
    archive = Path(archive_path)
    if not archive.is_file() or archive.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("Choose a ZIP archive no larger than 10 MiB.")
    root = community_extension_directory()
    root.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zf:
        infos = [info for info in zf.infolist() if not info.is_dir()]
        if len(infos) > MAX_FILES:
            raise ValueError(f"Extension package contains too many files (maximum {MAX_FILES}).")
        total = sum(info.file_size for info in infos)
        if total > MAX_UNPACKED_BYTES:
            raise ValueError("Extension package expands to more than 10 MiB.")
        allowed = {".py", ".json", ".md", ".txt", ".modkec"}
        for info in infos:
            normalized_name = info.filename.replace("\\", "/")
            parts = PurePosixPath(normalized_name).parts
            if "\\" in info.filename or PurePosixPath(normalized_name).is_absolute() or ".." in parts or not parts:
                raise ValueError(f"Unsafe ZIP path: {info.filename!r}")
            if PurePosixPath(normalized_name).suffix.lower() not in allowed:
                raise ValueError(f"Unsupported package file type: {info.filename}. Allowed: .py, .json, .md, .txt, .modkec")
            mode = (info.external_attr >> 16) & 0xFFFF
            if mode and (mode & 0o170000) == 0o120000:
                raise ValueError("Symbolic links are not allowed in extension packages.")
        with tempfile.TemporaryDirectory(prefix="modkec-extension-") as temp:
            staging = Path(temp) / "package"
            staging.mkdir()
            for info in infos:
                destination = (staging / PurePosixPath(info.filename)).resolve()
                if staging.resolve() not in destination.parents:
                    raise ValueError(f"Unsafe ZIP path: {info.filename!r}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as source, destination.open("wb") as target:
                    shutil.copyfileobj(source, target)
            manifest = _read_manifest(staging)
            # Require commands to be declared, making package capabilities visible before execution.
            if not manifest["commands"]:
                raise ValueError("Manifest must declare at least one command in its commands list.")
            # Validate implementation and command declarations before copying into the live registry.
            entry = (staging / manifest["entrypoint"]).resolve()
            source_text = entry.read_text(encoding="utf-8")
            if not source_text.strip():
                raise ValueError("Extension entrypoint is empty.")
            dest = root / manifest["id"]
            if dest.exists():
                raise FileExistsError(f"Extension {manifest['id']!r} is already installed. Uninstall it before replacing it.")
            shutil.copytree(staging, dest)
            # Test-load the installed package to make sure the API matches its manifest.
            registered = _load_extension_module(dest, _read_manifest(dest))
            if set(manifest["commands"]) != set(registered):
                shutil.rmtree(dest, ignore_errors=True)
                raise ValueError("Manifest commands do not match the loaded extension.")
            return {"id": manifest["id"], "name": str(manifest.get("name") or manifest["id"]),
                    "version": str(manifest.get("version") or "0.0.0"), "commands": sorted(registered)}


def install_bundled_extension(extension_id: str) -> dict[str, Any]:
    """Install a catalogued, locally bundled partnered extension on user request."""
    from .extensions import PARTNERED_EXTENSIONS

    spec = PARTNERED_EXTENSIONS.get(extension_id)
    if spec is None:
        raise ValueError(f"Unknown partnered extension: {extension_id}")
    package = Path(spec["package_path"]).resolve()
    if not package.is_file():
        raise FileNotFoundError(f"Bundled extension package is missing: {package}")
    result = install_extension_archive(package)
    if result["id"] != extension_id:
        uninstall_community_extension(result["id"])
        raise ValueError("Bundled package ID does not match its partnered catalog entry.")
    return result


def uninstall_community_extension(extension_id: str) -> None:
    if not isinstance(extension_id, str) or not EXTENSION_ID_RE.fullmatch(extension_id):
        raise ValueError("Invalid extension ID.")
    target = (community_extension_directory() / extension_id).resolve()
    root = community_extension_directory().resolve()
    if root not in target.parents:
        raise ValueError("Extension path escaped the community extension directory.")
    if target.exists():
        shutil.rmtree(target)
