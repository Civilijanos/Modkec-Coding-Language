# Compact Kit

Compact Kit is an optional partnered extension for Modkec Studio. It is available in the partnered-extension catalog but is not installed or activated automatically.

## Use templates

```modkec
import(compact_kit)
calculator(basic)
```

Template commands print editable Modkec source. Copy that output into your project and modify it as needed.

## Add your own templates using Modkec code

Open `templates.modkec` in a text editor or Modkec Studio. Each template is defined with a `template(...)` line. The first argument is the command group, the second is the template name, and the third is the Modkec source to generate. Write newlines in the source as `\n` and escape quote marks inside strings as `\"`.

For example, add this line to create `game(inventory)`:

```modkec
template("game", "inventory", "# Inventory template\nset(inventory, 0)\nincrement(inventory, 1)\nsay(inventory)")
```

Then run:

```modkec
import(compact_kit)
game(inventory)
```

The output will be Modkec source code. You can add a template to an existing group (`calculator`, `game`, or `utility`) by adding another `template(...)` line with that group name. The loader is Python, but template definitions and the source they generate are stored in `templates.modkec`, not in Python code.

### Important

- Save `templates.modkec` beside `main.py` in the installed Compact Kit extension folder.
- Restart Modkec Studio or start a fresh run after changing the extension files.
- This version supports adding variants to the three existing command groups. Adding an entirely new command group requires registering that group in `main.py` and the extension manifest.
- Generated code is printed as text; it is not inserted into the editor automatically.
