"""Compact Kit loader. Template definitions live in templates.modkec."""
import json
import re
from pathlib import Path


def _load_templates():
    """Read template definitions written as Modkec-style template(...) calls."""
    path = Path(__file__).with_name("templates.modkec")
    templates = {}
    pattern = re.compile(r'^\s*template\((.*)\)\s*$')
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        match = pattern.fullmatch(stripped)
        if not match:
            raise ValueError(f"templates.modkec line {line_number}: expected template(command, variant, source)")
        # Each argument is a JSON string, separated only by commas outside strings.
        args, current, quoted, escaped = [], [], False, False
        for char in match.group(1):
            if quoted:
                current.append(char)
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    quoted = False
            elif char == '"':
                quoted = True
                current.append(char)
            elif char == ',':
                args.append(''.join(current).strip())
                current = []
            else:
                current.append(char)
        args.append(''.join(current).strip())
        if len(args) != 3:
            raise ValueError(f"templates.modkec line {line_number}: template needs command, variant, and source")
        try:
            command, variant, source = (json.loads(arg) for arg in args)
        except (json.JSONDecodeError, TypeError) as exc:
            raise ValueError(f"templates.modkec line {line_number}: arguments must be quoted strings") from exc
        if not all(isinstance(item, str) for item in (command, variant, source)):
            raise ValueError(f"templates.modkec line {line_number}: all arguments must be strings")
        if not re.fullmatch(r"[a-z_][a-z0-9_]*", command) or not re.fullmatch(r"[a-z_][a-z0-9_]*", variant):
            raise ValueError(f"templates.modkec line {line_number}: command and variant must be lowercase identifiers")
        key = (command, variant)
        if key in templates:
            raise ValueError(f"templates.modkec line {line_number}: duplicate template {command}({variant})")
        templates[key] = source.rstrip()
    if not templates:
        raise ValueError("templates.modkec does not define any templates")
    return templates


def _generate(kind, args):
    if len(args) != 1 or not isinstance(args[0], str):
        raise ValueError(f"{kind}() needs one template name, for example {kind}(basic)")
    variant = args[0].strip().lower()
    templates = _load_templates()
    source = templates.get((kind, variant))
    if source is None:
        options = sorted(name for (template_kind, name) in templates if template_kind == kind)
        if not options:
            raise ValueError(f"No templates are defined for {kind} in templates.modkec")
        raise ValueError(f"Unknown {kind} template {variant!r}. Available: {', '.join(options)}")
    return source


def calculator(context, args):
    return _generate("calculator", args)


def game(context, args):
    return _generate("game", args)


def utility(context, args):
    return _generate("utility", args)


def register(api):
    api.register_command("calculator", calculator, "Generate editable calculator source from templates.modkec")
    api.register_command("game", game, "Generate editable game source from templates.modkec")
    api.register_command("utility", utility, "Generate editable utility source from templates.modkec")
