#!/bin/sh
# Run the complete test suite, creating a virtual X display for Tk GUI tests when needed.
set -eu
cd "$(dirname "$0")"
if [ -z "${DISPLAY:-}" ] && command -v xvfb-run >/dev/null 2>&1; then
    exec xvfb-run -a python3 -m pytest -q "$@"
fi
exec python3 -m pytest -q "$@"
