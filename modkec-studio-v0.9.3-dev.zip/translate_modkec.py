#!/usr/bin/env python3
"""Translate or export a Modkec source file to Python, JavaScript, Lua, Luau, C, HTML, or all targets."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.pycache_prefix = str(ROOT / ".pytest_cache" / "pycache")
sys.path.insert(0, str(ROOT))

from modkec import ModkecError
from modkec.translator import LANGUAGES, export, translate
from modkec.extensions import TARGETS, installed_targets


def main() -> int:
    parser = argparse.ArgumentParser(description="Translate or export a Modkec program")
    parser.add_argument("file", help="Path to a .modkec source file")
    parser.add_argument("target", choices=sorted(LANGUAGES | {"all"}), help="Target language")
    parser.add_argument("--export", metavar="OUTPUT", help="Write generated code to this file instead of printing it")
    args = parser.parse_args()
    try:
        installed = installed_targets()
        required = set(TARGETS) if args.target == "all" else {args.target}
        missing = sorted(required - installed)
        if missing:
            raise ModkecError("Install the matching translation extension in Studio first: " + ", ".join(missing))
        source = Path(args.file).read_text(encoding="utf-8")
        if args.export:
            path = export(source, args.target, args.export)
            print(f"[Modkec] Exported {args.target} code to {path}")
        else:
            print(translate(source, args.target), end="")
        return 0
    except (OSError, ModkecError) as exc:
        print(f"[Modkec] Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
