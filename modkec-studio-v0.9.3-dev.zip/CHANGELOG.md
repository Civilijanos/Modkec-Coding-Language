## v0.9.3 development update
- Replaced the single-document editor buffer with document tabs that retain each file's source, path, and dirty state; added per-tab close and Save All.
- Changed the project explorer to lazily populate folders recursively and avoid traversing directory symlinks.
- Added an interactive native console with live output, stdin entry, Stop, and process exit codes; routed common compiled-language run output through it.
- Added a versioned community extension API (`register(api)`, `api.register_command`) with explicit local ZIP installation, command manifests, safe ZIP-path checks, archive size/count limits, and lazy loading on `import(extension_id)`.
- Added a runnable sample extension package and tests for command registration and archive path traversal.
- Made `store(name, value)` persist values in `.modkec_store.json` beside the source file; `get()` reads saved values and `delete()` removes them.
- Connected `play_sound`, `stop_sound`, `volume`, and `play_video` to available native audio/video players, with relative paths resolved beside the script; dispatch now happens in program order and looping is supported on Windows WAV playback and ffplay.
- Replaced the Visele image placeholder with Tk image loading for supported formats, with an explicit error placeholder for unsupported/missing images.
- Implemented basic HTTP POST behavior for `send(url, data, optional_content_type)` and included nested script media actions in the caller.
- Added regression coverage for persistent storage, media dispatch, extension ZIP installation, and path traversal.

## v0.9.2 development update
- Added a button-color setting and automatic light/dark text selection based on background and button brightness.
- F5 now auto-runs native files by extension and saves dirty native-source buffers before launch; renamed the misleading Save All entry to Save Current File.
- Removed Modkec-specific syntax colors from native-language files rather than applying incorrect highlighting.
- Expanded background color changes across Studio surfaces and updated syntax colors for light backgrounds.
- Redirected Python bytecode caches into `.pytest_cache/pycache`; added cache settings to launch scripts and test startup.
- Expanded the Extensions manager to show native language support separately from translation/export packs, including detected runtime status for 41 catalog entries.
- Bound Ctrl+F to a Find window with next/previous search and a Close action that clears search highlights and the selection.
- Replaced the placeholder-insertion flow with a dedicated Command Maker script panel that inserts a command wrapper only after the user writes and submits a body.
- Removed the duplicate Extensions menu so Compact Kit and the extension manager share one menu.
- Changed Source Control to inspect the active project/workspace and explain its purpose; it now reports that staging, commits, diffs, and history remain unimplemented.
- Added native-run paths for C#, Visual Basic, and F# through temporary .NET projects, added more native language catalog entries, and fixed compiler output naming for Windows.
- Added extension-registry and contrast-selection tests.
- Blocked Modkec-only tools (Command Maker, Compact Kit, preview, translation, and export) from accidentally parsing or modifying an open native-language file.

## v0.9.1 development update
- Reworked Beatmaker into a larger step-pad sequencer with clearer track colors and controls.
- Fixed project-tree folder behavior: Studio no longer toggles folders a second time on mouse release.
- Expanded the custom background color setting from the editor to the main Studio surfaces.
- Moved Compact Kit templates from Program to Extensions → Compact Kit Extension.
- Added New Source File with common language choices and Run Native for saved source files when their system runtime/compiler is installed.
- Added native-run mappings for Python, JavaScript, TypeScript (tsx), Lua, Luau, Ruby, PHP, Perl, R, Julia, Go, Rust, Java, Kotlin, Swift, Dart, Scala, Clojure, Elixir, Haskell, Bash, PowerShell, Lisp, Scheme, Fortran, C, C++, SQL, and browser-openable HTML/CSS/SVG.
- Native programs run with the user's normal operating-system permissions; this is not a sandbox. Runtime availability varies by operating system.

## v0.9 development build
- Added explicit built-in module dependency resolution, automatic dependency imports, duplicate-import handling, dependency tracking, and circular-dependency errors. `import(media)` now imports `visele` automatically.
- Added regression tests for module dependency loading, duplicate imports, unknown modules, and circular dependencies.
- Made the Explorer, Search, Source Control, and Extensions activity buttons functional.
- Added single-click project opening and arrow-key/Enter navigation in the project tree.
- Reworked Quick Start into a scrollable window to prevent text overflow.
- Combined Problems and Output into one panel tab and made the editor/bottom-panel divider resizable.
- Added an initial Compact Kit menu with editable templates for basic calculators, game score/health, and random utilities.
- Added a dependency-free 16-step beatmaker with synthesized audio and WAV export; playback uses an available system player when possible.
- Added an initial translation-target extension manager and GitHub fork browser. Forks are shown for discovery only and are not downloaded or executed automatically.
- Added a custom background color control.
- Expanded C translation to support basic action definitions and conditional action calls.
- Improved HTML translation so simple action/condition programs can execute in the generated page and display their output.

## v0.8.4
- Added native scientific expression evaluation, including trigonometry, inverse trigonometry, logarithms, exponentials, factorials, powers, constants, and safe arithmetic expressions.
- Added button-specific Visele actions using `button(label, x, y, action_name)`, passing the clicked label into the action.
- Added named Visele text elements and `update_text(name, value)` for interactive displays.
- Added a native Modkec scientific calculator example.
- Added tests for scientific evaluation and button actions.

## v0.8.3
- Implemented timed Visele preview animations for element position, size, radius, opacity, and rotation.
- Implemented `fade()`, `rotate()`, and target-specific or global `stop_animation()` behavior in the Studio preview.
- Expanded native website building with semantic text, buttons, images, links, theme colors, and custom CSS commands.
- Added tests for animation tracks, stopping animations, and generated native-site components.

# Changelog

## v0.8.2
- Fixed Python translation for `ask()`, `equal()`, `greater()`, `less()`, `and()`, `or()`, and `not()` commands.
- Added translation support for conditional action calls inside action/command bodies.
- Preserved Modkec shared-variable behavior in generated Python functions by emitting global declarations for variables already defined before an action.
- Added regression tests that compile and run a translated calculator, including modulus, invalid-operation, and division-by-zero cases.
- Verified Python export writes syntactically valid Python files.

## v0.8.1
- Added a native Modkec website builder under `import(web)` using semantic `site_*` commands.
- Added standalone HTML generation with generated responsive styling and search interactions; website authors do not write raw HTML/CSS/JavaScript.
- Added `examples/community_hub.modkec` and automated site-builder tests.

## v0.8.0
- Added `command(name, parameters...) ... end()` for user-defined commands that can be called directly.
- Added a Studio menu wizard: Program → Create Custom Command…
- Added opt-in Python blocks using `import(py)`, `python() ... end_python()`.
- Python blocks share variables with Modkec and forward `print()` output to the Studio output.
- Added Python-target passthrough in the translator; non-Python targets reject native Python blocks explicitly.
- Added custom-command and Python interop examples and automated tests.

## v0.7.2
- Added web-source blocks for assembling HTML/CSS/JavaScript into HTML pages or JavaScript bundles.
- Retained the v0.7 language-core improvements.

