#!/bin/sh
cd "$(dirname "$0")"
export PYTHONPYCACHEPREFIX="$PWD/.pytest_cache/pycache"
exec python3 studio.py
