# Sample Modkec community extension

ZIP the contents of this folder so `modkec-extension.json` and `main.py` sit at the ZIP root. Then install the ZIP from **Extensions → Manage Extensions → Install local extension ZIP…**.

Example Modkec script:

```text
import(sample-math)
double(21) -> answer
say(answer)
```

The command should print `42`.

Extensions are Python code and run with the current user's permissions. Inspect the source before installing. API version 1 supports `register(api)` and `api.register_command(name, handler, description)`. Handlers receive `(context, args)`; `args` are evaluated Modkec values. They may return a value, which is printed or assigned with `-> result`, and `None` produces no output. `context.variables`, `context.output`, `context.project_directory`, `context.evaluate(expression)`, `context.say(value)`, and `context.set_variable(name, value)` are available.
