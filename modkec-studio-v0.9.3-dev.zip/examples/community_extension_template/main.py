def double(context, args):
    if len(args) != 1:
        raise ValueError("double() needs exactly one argument")
    return args[0] * 2


def register(api):
    api.register_command("double", double, "Return a number multiplied by two")
