"""Keep Python bytecode caches inside the project test-cache directory."""
from pathlib import Path
import sys

_PROJECT_ROOT = Path(__file__).resolve().parent
sys.pycache_prefix = str(_PROJECT_ROOT / ".pytest_cache" / "pycache")
