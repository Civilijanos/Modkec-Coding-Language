#!/usr/bin/env python3
"""Modkec Studio: a small desktop IDE built with Python's standard Tkinter library."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.pycache_prefix = str(ROOT / ".pytest_cache" / "pycache")

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk, colorchooser
import re
import time
import json
import threading
import urllib.request
import webbrowser
import subprocess
import os
import shutil
import tempfile
import queue

sys.path.insert(0, str(ROOT))
from modkec import ModkecEngine, ModkecError  # noqa: E402
from modkec.translator import LANGUAGES, export, translate  # noqa: E402
from modkec.compact_kit import get_templates  # noqa: E402
from modkec.extensions import TARGETS, NATIVE_LANGUAGES, installed_targets, install_target, uninstall_target, custom_background, custom_button_color, save_custom_background, save_custom_button_color, contrast_text_color  # noqa: E402
from modkec.beatmaker import BeatMaker  # noqa: E402
from modkec.plugins import install_extension_archive, uninstall_community_extension, list_community_extensions  # noqa: E402

STARTER = '''# Modkec — first program
say("Hello from Modkec!")
set(score, 12)
import(logic)

action(win)
    say("You win!")
end()

if(score > 10)=t, do(win)
'''

COMMAND_HELP = {
    "say(value)": "Core: display text or a value. Example: say(\"Hello!\")",
    "ask(prompt) -> name": "Core: ask for input and store it in a variable.",
    "set(name, value) / store(name, value)": "Core: set or store a variable for this run.",
    "get(name) / get(name) -> result": "Core: retrieve a variable, printing it or assigning its value.",
    "delete(name)": "Core: remove a variable.",
    "wait(seconds) / stop()": "Core: pause for a short time or stop the program.",
    "import(module)": "Core: load a module. Modules: visele, calculator, logic, actions, data, text, files, web, media, translation, py.",
    "command(name, parameters...) ... end()": "Define your own Modkec command. Example: command(greet, name), then say(name), then end(); call it with greet(\"Ada\"). Custom commands use Modkec syntax by default.",
    "import(py) + python() ... end_python()": "Opt into native Python for a block. Python can access variables shared with Modkec. Python blocks can access your computer and installed libraries, so only run code you trust.",
    "run(\"intro\")": "Core: run a defined action or another Modkec script. run() can launch the Visele preview flow.",
    "comment(\"note\")": "Core: explanatory note; does not execute anything.",
    "translate(python)": "Translate the current Modkec script to Python, JavaScript, Lua, Luau, C, HTML, or all targets. Use Studio's target selector for the preview.",
    "if(score > 10)=t, do(win)": "Logic: run an action if the condition is true; use =f for false.",
    "else() do(lose)": "Logic: run an alternative action when the previous condition was false.",
    "repeat(5) do(action)": "Logic: run an action a set number of times.",
    "while(alive) do(action)": "Logic: repeat an action while a condition remains true; has a safety iteration limit.",
    "on(start) do(begin)": "Logic: connect an event name to an action; trigger it with trigger(start).",
    "add(5,10) -> result": "Calculator: arithmetic includes add, subtract, multiply, divide, mod, power, round, floor, ceil, absolute, min, max, random, percentage, sqrt.",
    "p(120) hex(FF0000)": "Visele: draw a pixel and set its color. Also supports rect, square, circle, line, c1-c4, hex, rgb, text, image, button, resize, move, hide, show, remove, interact, clear, layer, opacity.",
    "interact(t) run()": "Visele: enable interaction and open the visual preview. Clickable buttons can trigger an event named click.",
    "list(items) / append(items, value)": "Data: create and manipulate lists. Also supports remove_item, count, contains, sort, reverse, object, key, save, load.",
    "dimp(\"data.json\") -> data": "Files: import data from a file; requires import(files). JSON files are parsed as data.",
    "join(\"Hello \", \"world\") -> result": "Text: join, length, upper, lower, replace, contains_text, split, trim, number, format.",
    "read_file(\"notes.txt\") -> contents": "Files: read/write files, check existence, copy, rename, list directories, and create folders. Use trusted scripts only.",
    "open_url(\"https://example.com\")": "Web: open a URL. request/get_page make network requests; network use should be restricted to trusted scripts.",
    "animate(\"x\", 10, 210, 2)": "Media: animate the last Visele element property over seconds. Properties: x, y, w, h, r, opacity. Also supports fade(from, to, seconds), rotate(degrees, seconds), and stop_animation(). Requires import(media).",
    "site_text(\"Welcome\", \"h2\")": "Web: add a paragraph or heading to a native website. Also supports site_button, site_image, site_link, site_theme, and site_custom_css. Requires import(web) and site_start().",
}

class ModkecStudio:
    def __init__(self, root: tk.Tk, profile_path: str | None = None) -> None:
        profile_data = {}
        if profile_path:
            try:
                profile_data = json.loads(Path(profile_path).read_text(encoding="utf-8"))
            except (OSError, ValueError):
                profile_data = {}
        self.root = root
        self.root.title("Modkec Studio")
        self.root.geometry("1240x820")
        self.root.minsize(900, 620)
        self.current_path: Path | None = None
        self.workspace_folders: list[Path] = [ROOT]
        self.recent_files: list[Path] = []
        self.dirty = False
        self.documents: list[dict] = []
        self.active_document_index = -1
        self._switching_document = False
        self.show_descriptions = tk.BooleanVar(value=bool(profile_data.get("show_command_descriptions", True)))
        self.auto_save = tk.BooleanVar(value=bool(profile_data.get("auto_save", False)))
        self.target = tk.StringVar(value="python")
        self.installed_targets = installed_targets()
        self.saved_background = profile_data.get("background") or custom_background()
        self.saved_button_color = profile_data.get("button_color") or custom_button_color()
        self.status = tk.StringVar(value="Ready")
        self.find_window = None
        self.find_var = None
        self._configure_theme()
        self._build_menu()
        self._build_ui()
        self._apply_custom_theme()
        self._load_starter()
        self._capture_document_state()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_menu(self) -> None:
        menu = tk.Menu(self.root)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="New Text File", accelerator="Ctrl+N", command=self.new_file)
        file_menu.add_command(label="New Source File…", command=self.new_source_file)
        file_menu.add_command(label="New Window", command=self.new_window)
        file_menu.add_command(label="New Window with Profile…", command=self.new_window_with_profile)
        file_menu.add_separator()
        file_menu.add_command(label="Open File…", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="Open Folder…", command=self.open_folder)
        file_menu.add_command(label="Open Workspace…", command=self.open_workspace)
        file_menu.add_command(label="Add Folder to Workspace…", command=self.add_folder_to_workspace)
        self.recent_menu = tk.Menu(file_menu, tearoff=False)
        file_menu.add_cascade(label="Open Recent", menu=self.recent_menu)
        self._refresh_recent_menu()
        file_menu.add_separator()
        file_menu.add_command(label="Save", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="Save As…", command=self.save_as)
        file_menu.add_command(label="Save All", command=self.save_all)
        file_menu.add_command(label="Save Current File", command=self.save_file)
        file_menu.add_command(label="Save Workspace As…", command=self.save_workspace_as)
        file_menu.add_command(label="Duplicate File…", command=self.duplicate_file)
        file_menu.add_command(label="Share Current File…", command=self.share_current_file)
        file_menu.add_command(label="Export Profile…", command=self.export_profile)
        file_menu.add_checkbutton(label="Auto Save", variable=self.auto_save)
        file_menu.add_separator()
        file_menu.add_command(label="Close File", command=self.close_document)
        file_menu.add_command(label="Close Window", command=self.on_close)
        file_menu.add_command(label="Exit", command=self.on_close)
        menu.add_cascade(label="File", menu=file_menu)
        edit_menu = tk.Menu(menu, tearoff=False)
        edit_menu.add_command(label="Undo", accelerator="Ctrl+Z", command=lambda: self.editor.edit_undo())
        edit_menu.add_command(label="Redo", accelerator="Ctrl+Y", command=lambda: self.editor.edit_redo())
        edit_menu.add_separator()
        edit_menu.add_command(label="Cut", accelerator="Ctrl+X", command=lambda: self.editor.event_generate("<<Cut>>"))
        edit_menu.add_command(label="Copy", accelerator="Ctrl+C", command=lambda: self.editor.event_generate("<<Copy>>"))
        edit_menu.add_command(label="Paste", accelerator="Ctrl+V", command=lambda: self.editor.event_generate("<<Paste>>"))
        edit_menu.add_command(label="Select All", accelerator="Ctrl+A", command=lambda: self.editor.tag_add("sel", "1.0", "end-1c"))
        menu.add_cascade(label="Edit", menu=edit_menu)
        run_menu = tk.Menu(menu, tearoff=False)
        run_menu.add_command(label="Run Current Source", accelerator="F5", command=self.run_program)
        run_menu.add_command(label="Translate", command=self.translate_program)
        run_menu.add_command(label="Export…", command=self.export_program)
        run_menu.add_separator()
        run_menu.add_command(label="Command Maker…", command=self.create_custom_command)
        run_menu.add_command(label="Run Current File (native language)", accelerator="Shift+F5", command=self.run_current_file)
        run_menu.add_command(label="Beatmaker…", command=self.open_beatmaker)
        menu.add_cascade(label="Program", menu=run_menu)
        extensions_menu = tk.Menu(menu, tearoff=False)
        extensions_menu.add_command(label="Manage Extensions…", command=self.open_extensions)
        extensions_menu.add_command(label="Browse Community Forks…", command=self.check_github_forks)
        kit_menu = tk.Menu(extensions_menu, tearoff=False)
        for template_name in get_templates():
            kit_menu.add_command(label=template_name, command=lambda n=template_name: self.insert_compact_kit(n))
        extensions_menu.add_cascade(label="Compact Kit Extension", menu=kit_menu)
        menu.add_cascade(label="Extensions", menu=extensions_menu)
        settings = tk.Menu(menu, tearoff=False)
        settings.add_checkbutton(label="Show command descriptions", variable=self.show_descriptions, command=self._refresh_help)
        settings.add_command(label="Change Studio background…", command=self.change_background_color)
        settings.add_command(label="Change button color…", command=self.change_button_color)
        menu.add_cascade(label="Settings", menu=settings)
        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label="Modkec quick start", command=self.show_tutorial)
        help_menu.add_command(label="About Modkec Studio", command=self.show_about)
        menu.add_cascade(label="Help", menu=help_menu)
        self.root.config(menu=menu)
        self.root.bind("<Control-n>", lambda _e: self.new_file())
        self.root.bind("<Control-o>", lambda _e: self.open_file())
        self.root.bind("<Control-s>", lambda _e: self.save_file())
        self.root.bind("<Control-z>", lambda _e: self.editor.edit_undo())
        self.root.bind("<Control-y>", lambda _e: self.editor.edit_redo())
        self.root.bind_class("Text", "<Control-f>", self._open_find_dialog)
        self.root.bind_class("Text", "<Control-F>", self._open_find_dialog)
        self.root.bind("<F5>", lambda _e: self.run_program())
        self.root.bind("<Shift-F5>", lambda _e: self.run_current_file())

    def _configure_theme(self) -> None:
        """Apply a dark, VS Code-inspired palette using only Tkinter/ttk."""
        self.colors = {
            "window": "#1e1e1e", "panel": "#252526", "toolbar": "#333333",
            "editor": "#1e1e1e", "gutter": "#1e1e1e", "gutter_text": "#858585",
            "text": "#d4d4d4", "muted": "#9da0a6", "border": "#3c3c3c",
            "accent": "#0e639c", "accent_hover": "#1177bb", "green": "#4ec9b0",
            "blue": "#569cd6", "purple": "#c586c0", "yellow": "#dcdcaa",
            "orange": "#ce9178", "comment": "#6a9955", "number": "#b5cea8",
        }
        if self.saved_background:
            for surface in ("window", "editor", "panel", "toolbar", "gutter"):
                self.colors[surface] = self.saved_background
        self.colors["text"] = contrast_text_color(self.colors["window"])
        self.colors["button"] = self.saved_button_color or "#3c3c3c"
        self.colors["button_text"] = contrast_text_color(self.colors["button"])
        self.root.configure(background=self.colors["window"])
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=self.colors["window"])
        style.configure("Toolbar.TFrame", background=self.colors["toolbar"])
        style.configure("Sidebar.TFrame", background=self.colors["panel"])
        style.configure("TLabel", background=self.colors["window"], foreground=self.colors["text"], font=("Segoe UI", 10))
        style.configure("Toolbar.TLabel", background=self.colors["toolbar"], foreground=self.colors["text"])
        style.configure("Sidebar.TLabel", background=self.colors["panel"], foreground=self.colors["text"])
        style.configure("TButton", background=self.colors["button"], foreground=self.colors["button_text"], bordercolor=self.colors["border"], padding=(10, 5), font=("Segoe UI", 9))
        style.map("TButton", background=[("active", self.colors["button"]), ("pressed", self.colors["accent"])], foreground=[("disabled", "#777777"), ("pressed", contrast_text_color(self.colors["accent"]))])
        style.configure("Accent.TButton", background=self.colors["accent"], foreground=contrast_text_color(self.colors["accent"]), bordercolor=self.colors["accent"], padding=(12, 5), font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", self.colors["accent_hover"]), ("pressed", self.colors["accent"])], foreground=[("active", contrast_text_color(self.colors["accent_hover"]))])
        style.configure("TCombobox", fieldbackground="#3c3c3c", background="#3c3c3c", foreground=self.colors["text"], arrowcolor=self.colors["text"], bordercolor=self.colors["border"])
        style.map("TCombobox", fieldbackground=[("readonly", "#3c3c3c")], foreground=[("readonly", self.colors["text"])])
        style.configure("TPanedwindow", background=self.colors["window"])
        style.configure("TSeparator", background=self.colors["border"])
        style.configure("Treeview", background=self.colors["panel"], fieldbackground=self.colors["panel"], foreground=contrast_text_color(self.colors["panel"]), borderwidth=0, rowheight=25, font=("Segoe UI", 9))
        style.map("Treeview", background=[("selected", self.colors["accent"])], foreground=[("selected", contrast_text_color(self.colors["accent"]))])
        style.configure("Status.TLabel", background="#007acc", foreground="#ffffff", padding=(9, 4), font=("Segoe UI", 9))
        # Native Tk menus do not use ttk styling, so set their palette explicitly.
        self.root.option_add("*Menu.background", self.colors["panel"])
        self.root.option_add("*Menu.foreground", contrast_text_color(self.colors["panel"]))
        self.root.option_add("*Menu.activeBackground", self.colors["accent"])
        self.root.option_add("*Menu.activeForeground", contrast_text_color(self.colors["accent"]))
        self.root.option_add("*Menu.borderWidth", 0)

    def _build_ui(self) -> None:
        """Build a VS Code-like workbench using Tkinter widgets."""
        # Compact command bar across the top.
        top = tk.Frame(self.root, bg="#323233", height=38)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)
        tk.Label(top, text="◈", bg="#323233", fg="#75beff", font=("Segoe UI", 16, "bold")).pack(side="left", padx=(12, 7))
        tk.Label(top, text="Modkec Studio", bg="#323233", fg="#eeeeee", font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Label(top, text="  •  Workspace", bg="#323233", fg="#bdbdbd", font=("Segoe UI", 9)).pack(side="left", padx=12)
        ttk.Button(top, text="New", command=self.new_file).pack(side="right", padx=(3, 8), pady=5)
        ttk.Button(top, text="Run Native", command=self.run_current_file).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Open", command=self.open_file).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Save", command=self.save_file).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Translate", command=self.translate_program).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Preview", command=self.preview_program).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Export", command=self.export_program).pack(side="right", padx=3, pady=5)
        ttk.Label(top, text="Target", style="Toolbar.TLabel").pack(side="right", padx=(8, 3))
        initial_targets = sorted(self.installed_targets)
        if set(TARGETS).issubset(self.installed_targets):
            initial_targets.append("all")
        self.target_box = ttk.Combobox(top, textvariable=self.target, values=tuple(initial_targets) or ("python",), state="readonly", width=12)
        self.target_box.pack(side="right", padx=3, pady=5)

        # Main workbench: activity rail, explorer, and editor/terminal area.
        workbench = tk.Frame(self.root, bg=self.colors["window"])
        workbench.pack(fill="both", expand=True)
        rail = tk.Frame(workbench, bg="#333333", width=48)
        rail.pack(side="left", fill="y")
        rail.pack_propagate(False)
        for glyph, hint in (("▤", "Explorer"), ("⌕", "Search"), ("⑂", "Source Control"), ("▣", "Extensions")):
            b = tk.Button(rail, text=glyph, relief="flat", bd=0, bg="#333333", fg="#c5c5c5", activebackground="#444444", activeforeground="#ffffff", font=("Segoe UI Symbol", 19), width=2, pady=5, cursor="hand2", command=lambda h=hint: self._open_activity(h))
            b.pack(fill="x")
            b.bind("<Enter>", lambda e, w=hint: self.status.set(w))
            b.bind("<Leave>", lambda e: self.status.set("Ready"))
        tk.Frame(rail, bg="#007acc", width=3).place(x=0, y=0, relheight=0.12)
        ttk.Separator(workbench, orient="vertical").pack(side="left", fill="y")

        self.panes = ttk.Panedwindow(workbench, orient="horizontal")
        self.panes.pack(side="left", fill="both", expand=True)
        explorer = tk.Frame(self.panes, bg="#252526", width=225)
        self.panes.add(explorer, weight=0)
        tk.Label(explorer, text="EXPLORER", bg="#252526", fg="#bbbbbb", font=("Segoe UI", 9, "bold"), anchor="w", padx=16, pady=12).pack(fill="x")
        tk.Label(explorer, text="MODKEC PROJECT", bg="#252526", fg="#cccccc", font=("Segoe UI", 9, "bold"), anchor="w", padx=12, pady=6).pack(fill="x")
        tree_frame = tk.Frame(explorer, bg="#252526")
        tree_frame.pack(fill="both", expand=True, padx=(7, 2), pady=(0, 8))
        self.file_tree = ttk.Treeview(tree_frame, show="tree", selectmode="browse")
        self.file_tree.pack(fill="both", expand=True)
        self.file_tree.bind("<ButtonRelease-1>", self._tree_open_selected)
        self.file_tree.bind("<<TreeviewOpen>>", self._tree_directory_opened)
        self.file_tree.bind("<Return>", self._tree_open_selected)
        self.file_tree.bind("<KP_Enter>", self._tree_open_selected)
        self.file_tree.bind("<Up>", self._tree_move_selection)
        self.file_tree.bind("<Down>", self._tree_move_selection)
        self._refresh_explorer()

        center = tk.Frame(self.panes, bg=self.colors["window"])
        self.panes.add(center, weight=5)
        # A vertical sash lets users resize the editor and bottom tool panel.
        self.center_panes = ttk.Panedwindow(center, orient="vertical")
        self.center_panes.pack(fill="both", expand=True)
        upper_editor = tk.Frame(self.center_panes, bg=self.colors["window"])
        self.center_panes.add(upper_editor, weight=5)
        # Editor tab strip.
        self.tab_strip = tk.Frame(upper_editor, bg="#252526", height=36)
        self.tab_strip.pack(fill="x")
        self.document_tab_buttons = tk.Frame(self.tab_strip, bg="#252526")
        self.document_tab_buttons.pack(side="left", fill="x", expand=True)
        tk.Button(self.tab_strip, text="+", relief="flat", bd=0, bg="#252526", fg="#cccccc", activebackground="#333333", activeforeground="#ffffff", font=("Segoe UI", 12), command=self.new_file, cursor="hand2", width=3).pack(side="right", fill="y")
        tk.Frame(self.tab_strip, bg="#007acc", height=2).pack(side="bottom", fill="x")

        self.editor_area = tk.Frame(upper_editor, bg=self.colors["editor"])
        self.editor_area.pack(fill="both", expand=True)
        self.line_numbers = tk.Text(self.editor_area, width=4, padx=8, takefocus=0, borderwidth=0, state="disabled", wrap="none", background=self.colors["editor"], foreground="#858585", font=("Consolas", 11), selectbackground=self.colors["editor"])
        self.line_numbers.pack(side="left", fill="y")
        self.editor = tk.Text(self.editor_area, undo=True, wrap="none", font=("Consolas", 11), padx=10, pady=9, background=self.colors["editor"], foreground="#d4d4d4", insertbackground="#ffffff", selectbackground="#264f78", selectforeground="#ffffff", borderwidth=0, highlightthickness=0, spacing1=1, spacing3=1)
        self.editor.pack(side="left", fill="both", expand=True)
        scroll_y = ttk.Scrollbar(self.editor_area, orient="vertical", command=self._scroll_editor)
        scroll_y.pack(side="right", fill="y")
        scroll_x = ttk.Scrollbar(upper_editor, orient="horizontal", command=self.editor.xview)
        scroll_x.pack(fill="x")
        self.editor.configure(yscrollcommand=self._sync_scroll, xscrollcommand=scroll_x.set)
        self.editor.bind("<Control-f>", self._open_find_dialog)
        self.editor.bind("<Control-F>", self._open_find_dialog)
        self.editor.bind("<<Modified>>", self._on_modified)
        self.editor.bind("<KeyRelease>", self._on_editor_key_release)
        self.editor.bind("<MouseWheel>", lambda _e: self._update_line_numbers())
        self._configure_syntax_tags()

        # Bottom panel with terminal and command reference as switchable tabs.
        self.bottom_panel = tk.Frame(self.center_panes, bg="#1e1e1e", height=190)
        self.center_panes.add(self.bottom_panel, weight=1)
        panel_header = tk.Frame(self.bottom_panel, bg="#252526", height=32)
        panel_header.pack(fill="x")
        panel_header.pack_propagate(False)
        self.panel_choice = tk.StringVar(value="OUTPUT")
        for name in ("PROBLEMS / OUTPUT", "COMMANDS"):
            tk.Button(panel_header, text=name, relief="flat", bd=0, bg="#252526", fg="#cccccc", activebackground="#333333", activeforeground="#ffffff", font=("Segoe UI", 8, "bold"), command=lambda n=name: self._show_bottom_tab(n)).pack(side="left", padx=10)
        ttk.Button(panel_header, text="Run  ▶  F5", style="Accent.TButton", command=self.run_program).pack(side="right", padx=8, pady=3)
        self.panel_body = tk.Frame(self.bottom_panel, bg="#1e1e1e")
        self.panel_body.pack(fill="both", expand=True)
        self.output = tk.Text(self.panel_body, height=7, wrap="word", state="disabled", font=("Consolas", 10), padx=9, pady=7, background="#181818", foreground="#cccccc", insertbackground="#ffffff", selectbackground="#264f78", borderwidth=0, highlightthickness=0)
        self.output.pack(fill="both", expand=True)
        self.help_text = tk.Text(self.panel_body, height=7, wrap="word", state="disabled", font=("Consolas", 9), padx=9, pady=7, background="#181818", foreground="#cccccc", insertbackground="#ffffff", selectbackground="#264f78", borderwidth=0, highlightthickness=0)
        self._refresh_help()

        # Status bar resembles VS Code's blue bottom strip.
        statusbar = tk.Frame(self.root, bg="#007acc", height=24)
        statusbar.pack(fill="x", side="bottom")
        statusbar.pack_propagate(False)
        tk.Label(statusbar, textvariable=self.status, bg="#007acc", fg="#ffffff", font=("Segoe UI", 9), anchor="w", padx=8).pack(side="left", fill="y")
        tk.Label(statusbar, text="Modkec  |  UTF-8  |  Spaces: 4", bg="#007acc", fg="#ffffff", font=("Segoe UI", 9), padx=8).pack(side="right", fill="y")

    def _refresh_explorer(self) -> None:
        if not hasattr(self, "file_tree"):
            return
        self.file_tree.delete(*self.file_tree.get_children())
        ignored = {".git", ".pytest_cache", "__pycache__", ".venv", "venv", "node_modules"}
        for folder in self.workspace_folders:
            if not folder.is_dir():
                continue
            root_id = self.file_tree.insert("", "end", text=folder.name or str(folder), open=True, values=(str(folder), "dir"))
            self._populate_tree_directory(root_id, folder, ignored)

    def _populate_tree_directory(self, parent_id: str, folder: Path, ignored: set[str] | None = None) -> None:
        """Load the immediate children of a folder; descendants are lazy-loaded on expansion."""
        ignored = ignored or {".git", ".pytest_cache", "__pycache__", ".venv", "venv", "node_modules"}
        try:
            paths = sorted(folder.iterdir(), key=lambda item: (not item.is_dir(), item.name.casefold()))
        except (OSError, PermissionError):
            return
        for path in paths:
            if path.name in ignored:
                continue
            try:
                is_dir = path.is_dir() and not path.is_symlink()
            except OSError:
                continue
            iid = self.file_tree.insert(parent_id, "end", text=path.name, values=(str(path), "dir" if is_dir else "file"))
            if is_dir:
                # A path-less placeholder signals that this directory has not been loaded yet.
                self.file_tree.insert(iid, "end", text="", values=("", "placeholder"))

    def _tree_directory_opened(self, _event=None) -> None:
        item = self.file_tree.focus()
        if not item:
            selection = self.file_tree.selection()
            item = selection[0] if selection else ""
        if not item:
            return
        values = self.file_tree.item(item, "values")
        if not values or len(values) < 2 or values[1] != "dir" or not values[0]:
            return
        children = self.file_tree.get_children(item)
        if children and self.file_tree.item(children[0], "values") == ("", "placeholder"):
            self.file_tree.delete(*children)
            self._populate_tree_directory(item, Path(values[0]))

    def _tree_open_selected(self, _event=None) -> None:
        selected = self.file_tree.selection()
        if not selected:
            return
        values = self.file_tree.item(selected[0], "values")
        if values:
            path = Path(values[0])
            # ttk.Treeview already toggles folders as part of its mouse handling.
            # Toggling again on release made folders appear to close immediately.
            kind = values[1] if len(values) > 1 else ("dir" if path.is_dir() else "file")
            if kind == "file" and path.is_file():
                self._open_path(path)
        return "break"

    def _tree_move_selection(self, event=None):
        children = list(self.file_tree.get_children(""))
        visible = []
        def walk(parent):
            for item in self.file_tree.get_children(parent):
                visible.append(item)
                if self.file_tree.item(item, "open"):
                    walk(item)
        walk("")
        if not visible:
            return "break"
        selected = self.file_tree.selection()
        current = visible.index(selected[0]) if selected and selected[0] in visible else 0
        next_index = max(0, min(len(visible) - 1, current + (-1 if event.keysym == "Up" else 1)))
        self.file_tree.selection_set(visible[next_index])
        self.file_tree.focus(visible[next_index])
        self.file_tree.see(visible[next_index])
        return "break"

    def _open_path(self, path: Path, confirm: bool = True) -> None:
        if not path.is_file():
            return
        resolved = path.expanduser().resolve()
        for index, document in enumerate(self.documents):
            existing = document.get("path")
            if existing is not None and Path(existing).resolve() == resolved:
                self._switch_document(index)
                self.status.set(f"Opened {path.name}")
                return
        try:
            source = resolved.read_text(encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Open failed", str(exc))
            return
        self._capture_document_state()
        self.documents.append({"path": resolved, "source": source, "dirty": False})
        self._switch_document(len(self.documents) - 1)
        self._add_recent(resolved)
        self.status.set(f"Opened {resolved.name}")

    def _capture_document_state(self) -> None:
        """Save the active buffer and its metadata into the open-document list."""
        if not hasattr(self, "editor"):
            return
        if self.active_document_index < 0 or self.active_document_index >= len(self.documents):
            self.documents.append({"path": self.current_path, "source": self._source(), "dirty": self.dirty})
            self.active_document_index = len(self.documents) - 1
        document = self.documents[self.active_document_index]
        document["path"] = self.current_path
        document["source"] = self._source()
        document["dirty"] = self.dirty
        try:
            document["cursor"] = self.editor.index("insert")
            document["yview"] = self.editor.yview()[0]
            document["xview"] = self.editor.xview()[0]
            selected = self.editor.tag_ranges("sel")
            document["selection"] = (str(selected[0]), str(selected[1])) if len(selected) >= 2 else None
        except tk.TclError:
            pass
        self._refresh_document_tabs()

    def _switch_document(self, index: int) -> None:
        if not 0 <= index < len(self.documents) or index == self.active_document_index:
            self._capture_document_state()
            return
        self._capture_document_state()
        document = self.documents[index]
        self._switching_document = True
        try:
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", document["source"])
            self.editor.edit_reset()  # Prevent undo from one document changing another tab's buffer.
            self.editor.edit_modified(False)
            self.active_document_index = index
            self.current_path = Path(document["path"]) if document.get("path") else None
            self.dirty = bool(document.get("dirty"))
            try:
                self.editor.mark_set("insert", document.get("cursor", "1.0"))
                self.editor.xview_moveto(float(document.get("xview", 0.0)))
                self.editor.yview_moveto(float(document.get("yview", 0.0)))
                selected = document.get("selection")
                if selected:
                    self.editor.tag_add("sel", selected[0], selected[1])
                else:
                    self.editor.tag_remove("sel", "1.0", "end")
            except (tk.TclError, TypeError, ValueError):
                self.editor.mark_set("insert", "1.0")
        finally:
            self._switching_document = False
        self._highlight_syntax()
        self._update_line_numbers()
        self._set_title()
        self.editor.focus_set()

    def _refresh_document_tabs(self) -> None:
        if not hasattr(self, "document_tab_buttons"):
            return
        for widget in self.document_tab_buttons.winfo_children():
            widget.destroy()
        for index, document in enumerate(self.documents):
            path = document.get("path")
            label = path.name if path else "Untitled.modkec"
            if document.get("dirty"):
                label = "* " + label
            active = index == self.active_document_index
            background = self.colors["editor"] if active else "#252526"
            foreground = contrast_text_color(background) if active else "#cccccc"
            tab = tk.Frame(self.document_tab_buttons, bg=background, bd=0)
            tab.pack(side="left", fill="y")
            button = tk.Button(tab, text=label, relief="flat", bd=0, bg=background, fg=foreground,
                               activebackground=background, activeforeground=foreground,
                               font=("Segoe UI", 9), padx=10, pady=7, cursor="hand2",
                               command=lambda i=index: self._switch_document(i))
            button.pack(side="left", fill="y")
            close = tk.Button(tab, text="×", relief="flat", bd=0, bg=background, fg=foreground,
                              activebackground=background, activeforeground=foreground, padx=6,
                              cursor="hand2", command=lambda i=index: self.close_document(i))
            close.pack(side="left", fill="y")
            tk.Frame(tab, bg=self.colors["accent"] if active else "#3e3e42", height=2).pack(side="bottom", fill="x")

    def _add_recent(self, path: Path) -> None:
        resolved = path.expanduser().resolve()
        self.recent_files = [item for item in self.recent_files if item != resolved]
        self.recent_files.insert(0, resolved)
        self.recent_files = self.recent_files[:12]
        if hasattr(self, "recent_menu"):
            self._refresh_recent_menu()

    def _refresh_recent_menu(self) -> None:
        if not hasattr(self, "recent_menu"):
            return
        self.recent_menu.delete(0, "end")
        existing = [path for path in self.recent_files if path.is_file()]
        if not existing:
            self.recent_menu.add_command(label="No recent files", state="disabled")
            return
        for path in existing:
            self.recent_menu.add_command(label=path.name, command=lambda p=path: self._open_path(p))

    def open_folder(self) -> None:
        folder = filedialog.askdirectory(title="Open Folder as Workspace", parent=self.root)
        if not folder:
            return
        self.workspace_folders = [Path(folder).resolve()]
        self._refresh_explorer()
        self.status.set(f"Workspace folder: {Path(folder).name}")

    def add_folder_to_workspace(self) -> None:
        folder = filedialog.askdirectory(title="Add Folder to Workspace", parent=self.root)
        if not folder:
            return
        path = Path(folder).resolve()
        if path not in self.workspace_folders:
            self.workspace_folders.append(path)
        self._refresh_explorer()
        self.status.set(f"Added {path.name} to workspace")

    def open_workspace(self) -> None:
        name = filedialog.askopenfilename(title="Open Modkec Workspace", filetypes=(("Modkec workspace", "*.ws"), ("JSON files", "*.json"), ("All files", "*")), parent=self.root)
        if not name:
            return
        try:
            data = json.loads(Path(name).read_text(encoding="utf-8"))
            folders = [Path(p).expanduser().resolve() for p in data.get("folders", []) if Path(p).expanduser().exists()]
            if not folders:
                raise ValueError("This workspace has no existing folders.")
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror("Workspace could not be opened", str(exc), parent=self.root)
            return
        self.workspace_folders = folders
        self._refresh_explorer()
        self.status.set(f"Opened workspace {Path(name).name}")

    def save_workspace_as(self) -> None:
        name = filedialog.asksaveasfilename(title="Save Modkec Workspace", defaultextension=".ws", filetypes=(("Modkec workspace", "*.ws"),), parent=self.root)
        if not name:
            return
        try:
            Path(name).write_text(json.dumps({"format": "modkec-workspace", "version": 1, "folders": [str(p) for p in self.workspace_folders]}, indent=2), encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Workspace save failed", str(exc), parent=self.root)
            return
        self.status.set(f"Saved workspace {Path(name).name}")

    def new_window(self) -> None:
        try:
            subprocess.Popen([sys.executable, str(ROOT / "studio.py")], cwd=str(ROOT))
        except OSError as exc:
            messagebox.showerror("New window failed", str(exc), parent=self.root)

    def new_window_with_profile(self) -> None:
        profile = filedialog.askopenfilename(title="Choose Modkec Profile", filetypes=(("Modkec profile", "*.json"),), parent=self.root)
        if not profile:
            return
        try:
            data = json.loads(Path(profile).read_text(encoding="utf-8"))
            if data.get("format") != "modkec-profile":
                raise ValueError("This file is not a Modkec profile.")
        except (OSError, ValueError, AttributeError) as exc:
            messagebox.showerror("Invalid profile", str(exc), parent=self.root)
            return
        try:
            subprocess.Popen([sys.executable, str(ROOT / "studio.py"), "--profile", profile], cwd=str(ROOT))
        except OSError as exc:
            messagebox.showerror("New window failed", str(exc), parent=self.root)

    def duplicate_file(self) -> None:
        if self.current_path is None:
            messagebox.showinfo("Duplicate file", "Save the current file before duplicating it.", parent=self.root)
            return
        self.save_as()

    def share_current_file(self) -> None:
        if self.current_path is None:
            messagebox.showinfo("Share current file", "Save the file first.", parent=self.root)
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(str(self.current_path.resolve()))
        messagebox.showinfo("File path copied", "The local file path was copied to the clipboard. This does not upload or publicly share the file.", parent=self.root)

    def export_profile(self) -> None:
        name = filedialog.asksaveasfilename(title="Export Modkec Profile", defaultextension=".json", filetypes=(("JSON profile", "*.json"),), parent=self.root)
        if not name:
            return
        data = {"format": "modkec-profile", "version": 1, "background": self.colors["window"], "button_color": self.colors["button"], "show_command_descriptions": self.show_descriptions.get(), "auto_save": self.auto_save.get()}
        try:
            Path(name).write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Profile export failed", str(exc), parent=self.root)
            return
        self.status.set(f"Exported profile {Path(name).name}")

    def _update_tab_label(self) -> None:
        if hasattr(self, "document_tab_buttons"):
            if 0 <= self.active_document_index < len(self.documents):
                self.documents[self.active_document_index].update(path=self.current_path, source=self._source(), dirty=self.dirty)
            self._refresh_document_tabs()

    def _show_bottom_tab(self, name: str) -> None:
        self.panel_choice.set(name)
        for widget in self.panel_body.winfo_children():
            widget.pack_forget()
        if name == "COMMANDS":
            if self.show_descriptions.get():
                self.help_text.pack(fill="both", expand=True)
            else:
                self.help_text.configure(state="normal")
                self.help_text.delete("1.0", "end")
                self.help_text.insert("1.0", "Command descriptions are hidden. Enable them under Settings.")
                self.help_text.configure(state="disabled")
                self.help_text.pack(fill="both", expand=True)
        else:
            self.output.pack(fill="both", expand=True)

    def _configure_syntax_tags(self) -> None:
        palette = self.colors
        light_background = contrast_text_color(self.colors["editor"]) == "#171717"
        if light_background:
            syntax = {"comment": "#527545", "orange": "#93411f", "yellow": "#795b00", "purple": "#773b8d", "number": "#28653a", "blue": "#1e5f98"}
        else:
            syntax = {"comment": palette["comment"], "orange": palette["orange"], "yellow": palette["yellow"], "purple": palette["purple"], "number": palette["number"], "blue": palette["blue"]}
        self.editor.tag_configure("comment", foreground=syntax["comment"], font=("Consolas", 11, "italic"))
        self.editor.tag_configure("string", foreground=syntax["orange"])
        self.editor.tag_configure("command", foreground=syntax["yellow"])
        self.editor.tag_configure("keyword", foreground=syntax["purple"], font=("Consolas", 11, "bold"))
        self.editor.tag_configure("number", foreground=syntax["number"])
        self.editor.tag_configure("module", foreground=syntax["blue"])

    def _on_editor_key_release(self, _event=None) -> None:
        self._update_line_numbers()
        self._highlight_syntax()

    def _highlight_syntax(self) -> None:
        """Lightweight syntax coloring for Modkec source."""
        if not hasattr(self, "editor"):
            return
        source = self._source()
        syntax_tags = ("comment", "string", "command", "keyword", "number", "module")
        for tag in syntax_tags:
            self.editor.tag_remove(tag, "1.0", "end")
        native_suffixes = {spec["suffix"] for spec in NATIVE_LANGUAGES.values()}
        native_suffixes.update({".pyw", ".mjs", ".cjs", ".htm", ".bash", ".ex", ".cc", ".cxx"})
        if self.current_path is not None and self.current_path.suffix.lower() in native_suffixes:
            # Until language-specific lexers land, do not miscolor native code
            # using Modkec's keyword/comment rules.
            return
        patterns = (
            ("comment", r"#[^\n]*"),
            ("string", r""""(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'"""),
            ("keyword", r"\b(?:action|command|end|end_python|python|if|else|do|return|import|t|f)\b"),
            ("module", r"\b(?:visele|logic|actions|calculator|calculations|data|text|files|web|media|translation|py)\b"),
            ("number", r"(?<![A-Za-z_])\b\d+(?:\.\d+)?\b"),
            ("command", r"\b(?:say|ask|set|store|get|delete|wait|stop|run|comment|translate|export|p|rect|square|circle|line|hex|rgb|text|image|button|resize|move|hide|show|remove|interact|clear|layer|opacity|add|subtract|multiply|divide|mod|power|round|floor|ceil|absolute|min|max|random|percentage|sqrt|repeat|while|on|trigger|cancel|list|append|remove_item|count|contains|sort|reverse|object|key|save|load|dimp|join|length|upper|lower|replace|contains_text|split|trim|number|format|read_file|write_file|file_exists|copy_file|rename_file|list_files|create_folder|open_url|request|get_page|send|listen|timer|animate|fade|rotate|play_sound|stop_sound|volume|play_video|stop_animation)\b"),
        )
        for tag, pattern in patterns:
            for match in re.finditer(pattern, source):
                # Don't color syntax inside comments or quoted strings.
                start, end = match.span()
                if tag not in ("comment", "string") and (self.editor.tag_names()):
                    index = f"1.0+{start}c"
                    existing = self.editor.tag_names(index)
                    if "comment" in existing or "string" in existing:
                        continue
                self.editor.tag_add(tag, f"1.0+{start}c", f"1.0+{end}c")

    def _load_starter(self) -> None:
        self.editor.insert("1.0", STARTER)
        self.editor.edit_modified(False)
        self.dirty = False
        self._update_line_numbers()
        self._highlight_syntax()

    def create_custom_command(self) -> None:
        """Open a dedicated body editor and wrap its contents as a Modkec command on insert."""
        if not self._require_modkec_source("Command Maker"):
            return
        window = tk.Toplevel(self.root)
        window.title("Command Maker")
        window.geometry("760x560")
        window.minsize(580, 420)
        window.transient(self.root)
        frame = ttk.Frame(window, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="COMMAND MAKER", font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Write the command body below. Modkec will add the command() and end() wrapper when you insert it.", wraplength=710).pack(anchor="w", pady=(4, 10))
        name_row = ttk.Frame(frame)
        name_row.pack(fill="x", pady=(0, 7))
        ttk.Label(name_row, text="Command name", width=14).pack(side="left")
        name_var = tk.StringVar(value="my_command")
        ttk.Entry(name_row, textvariable=name_var).pack(side="left", fill="x", expand=True)
        params_row = ttk.Frame(frame)
        params_row.pack(fill="x", pady=(0, 8))
        ttk.Label(params_row, text="Parameters", width=14).pack(side="left")
        params_var = tk.StringVar()
        ttk.Entry(params_row, textvariable=params_var).pack(side="left", fill="x", expand=True)
        ttk.Label(frame, text="Script body (Modkec commands):").pack(anchor="w", pady=(0, 4))
        body = tk.Text(frame, wrap="none", undo=True, font=("Consolas", 11), padx=9, pady=8, height=18)
        body.pack(fill="both", expand=True)
        body.insert("1.0", 'say("Hello from my custom command!")')
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(10, 0))

        def insert_command() -> None:
            name = name_var.get().strip()
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
                messagebox.showerror("Invalid command name", "Use a name starting with a letter or underscore, followed by letters, numbers, or underscores.", parent=window)
                return
            params = [item.strip() for item in params_var.get().split(",") if item.strip()]
            if any(not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", item) for item in params) or len(set(params)) != len(params):
                messagebox.showerror("Invalid parameters", "Parameters must be valid, unique names separated by commas.", parent=window)
                return
            if name in {"say", "ask", "set", "store", "get", "delete", "import", "run", "command", "action", "python"}:
                messagebox.showerror("Reserved command name", f"'{name}' is reserved by Modkec.", parent=window)
                return
            source = body.get("1.0", "end-1c").strip("\n \t")
            if not source:
                messagebox.showerror("Empty script body", "Add at least one Modkec command to the script body.", parent=window)
                return
            signature = ", ".join([name, *params])
            indented = "\n".join(("    " + line if line.strip() else "") for line in source.splitlines())
            definition = f"command({signature})\n{indented}\nend()\n"
            insertion = self.editor.index("insert")
            prefix = "" if insertion == "1.0" or self.editor.get(f"{insertion} - 1 chars", insertion).endswith("\n") else "\n"
            self.editor.insert(insertion, prefix + definition)
            self.editor.edit_modified(True)
            self.dirty = True
            self._set_title()
            self._highlight_syntax()
            self.editor.see(insertion)
            self.status.set(f"Command Maker inserted: {name}")
            window.destroy()

        ttk.Button(buttons, text="Insert command into current script", style="Accent.TButton", command=insert_command).pack(side="right")
        ttk.Button(buttons, text="Close", command=window.destroy).pack(side="right", padx=(0, 8))
        self._apply_custom_theme()
        body.focus_set()

    def insert_compact_kit(self, name: str) -> None:
        """Insert a Compact Kit template as ordinary editable Modkec source."""
        if not self._require_modkec_source("Compact Kit"):
            return
        templates = get_templates()
        if name not in templates:
            return
        description, source = templates[name]
        if self._source().strip() and not self._source().endswith("\n"):
            self.editor.insert("end-1c", "\n")
        self.editor.insert("end-1c", ("\n" if self._source().strip() else "") + source)
        self.editor.edit_modified(True)
        self.editor.see("end")
        self._highlight_syntax()
        self.status.set(f"Compact Kit inserted: {name} — {description}")

    def open_beatmaker(self) -> None:
        self.beatmaker = BeatMaker(self.root)
        self._apply_custom_theme()

    def _apply_custom_theme(self) -> None:
        """Apply configured button colors and, when selected, the app-wide background."""
        background = self.colors["window"]
        foreground = self.colors["text"]
        button = self.colors["button"]
        button_text = self.colors["button_text"]
        use_custom_background = bool(self.saved_background)

        beatmaker_pads = set()
        beatmaker = getattr(self, "beatmaker", None)
        if beatmaker is not None:
            beatmaker_pads = set(beatmaker.step_buttons.values())

        def recolor(widget):
            try:
                if isinstance(widget, tk.Button) and widget not in beatmaker_pads:
                    widget.configure(background=button, foreground=button_text, activebackground=button, activeforeground=button_text)
                elif use_custom_background and isinstance(widget, (tk.Frame, tk.Label, tk.Text, tk.Canvas, tk.Listbox)):
                    widget.configure(background=background)
                    if isinstance(widget, (tk.Label, tk.Text, tk.Listbox)):
                        widget.configure(foreground=foreground)
                    if isinstance(widget, tk.Text):
                        widget.configure(insertbackground=foreground, selectbackground=self.colors["accent"], selectforeground=contrast_text_color(self.colors["accent"]))
            except (tk.TclError, TypeError):
                pass
            try:
                children = widget.winfo_children()
            except tk.TclError:
                children = []
            for child in children:
                recolor(child)

        recolor(self.root)
        style = ttk.Style(self.root)
        if use_custom_background:
            self.root.configure(background=background)
            for style_name in ("TFrame", "Toolbar.TFrame", "Sidebar.TFrame"):
                style.configure(style_name, background=background)
            for style_name in ("TLabel", "Toolbar.TLabel", "Sidebar.TLabel"):
                style.configure(style_name, background=background, foreground=foreground)
            style.configure("TEntry", fieldbackground=background, foreground=foreground)
            style.configure("TCombobox", fieldbackground=background, background=background, foreground=foreground, arrowcolor=foreground)
            style.map("TCombobox", fieldbackground=[("readonly", background)], foreground=[("readonly", foreground)])
            style.configure("Treeview", background=background, fieldbackground=background, foreground=foreground)
            style.map("Treeview", background=[("selected", self.colors["accent"])], foreground=[("selected", contrast_text_color(self.colors["accent"]))])
            style.configure("TPanedwindow", background=background)
            self.root.option_add("*Menu.background", background)
            self.root.option_add("*Menu.foreground", foreground)
            self.root.option_add("*Text.background", background)
            self.root.option_add("*Text.foreground", foreground)
        style.configure("TButton", background=button, foreground=button_text, bordercolor=self.colors["border"])
        style.map("TButton", background=[("active", button), ("pressed", self.colors["accent"])], foreground=[("pressed", contrast_text_color(self.colors["accent"]))])
        style.configure("Accent.TButton", background=self.colors["accent"], foreground=contrast_text_color(self.colors["accent"]), bordercolor=self.colors["accent"])
        style.map("Accent.TButton", background=[("active", self.colors["accent_hover"]), ("pressed", self.colors["accent"])], foreground=[("active", contrast_text_color(self.colors["accent_hover"]))])
        self.root.option_add("*Menu.activeBackground", self.colors["accent"])
        self.root.option_add("*Menu.activeForeground", contrast_text_color(self.colors["accent"]))
        if use_custom_background:
            self.root.option_add("*Text.background", background)
            self.root.option_add("*Text.foreground", foreground)

    def change_background_color(self) -> None:
        selected = colorchooser.askcolor(color=self.colors["window"], title="Choose Studio background color", parent=self.root)
        if not selected or not selected[1]:
            return
        color = selected[1]
        self.saved_background = color
        for surface in ("window", "editor", "panel", "toolbar", "gutter"):
            self.colors[surface] = color
        self.colors["text"] = contrast_text_color(color)
        try:
            save_custom_background(color)
        except OSError as exc:
            self.status.set(f"Color changed for this session; could not save preference: {exc}")
        self._apply_custom_theme()
        self._configure_syntax_tags()
        self._highlight_syntax()
        self.status.set(f"Studio background: {color}; text contrast adjusted automatically")

    def change_button_color(self) -> None:
        selected = colorchooser.askcolor(color=self.colors["button"], title="Choose button color", parent=self.root)
        if not selected or not selected[1]:
            return
        color = selected[1]
        self.saved_button_color = color
        self.colors["button"] = color
        self.colors["button_text"] = contrast_text_color(color)
        try:
            save_custom_button_color(color)
        except OSError as exc:
            self.status.set(f"Button color changed for this session; could not save preference: {exc}")
        self._apply_custom_theme()
        self.status.set(f"Button color: {color}; button text contrast adjusted automatically")

    def _open_activity(self, name: str) -> None:
        if name == "Explorer":
            self.file_tree.focus_set()
            self.status.set("Explorer focused — click a project once or use arrow keys and Enter")
        elif name == "Search":
            self._open_find_dialog()
        elif name == "Source Control":
            self._open_source_control()
        elif name == "Extensions":
            self.open_extensions()

    def _open_find_dialog(self, _event=None):
        """Open the current-file finder. Closing it removes all search highlights."""
        if self.find_window is not None and self.find_window.winfo_exists():
            self.find_window.deiconify()
            self.find_window.lift()
            self.find_entry.focus_set()
            self.find_entry.selection_range(0, "end")
            return "break"
        window = tk.Toplevel(self.root)
        self.find_window = window
        window.title("Find in File")
        window.resizable(False, False)
        window.transient(self.root)
        frame = ttk.Frame(window, padding=10)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Find in current file:").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.find_var = tk.StringVar()
        self.find_entry = ttk.Entry(frame, textvariable=self.find_var, width=32)
        self.find_entry.grid(row=0, column=1, sticky="ew")
        frame.columnconfigure(1, weight=1)
        status = tk.StringVar(value="Search highlights are cleared when this window closes.")
        ttk.Label(frame, textvariable=status).grid(row=1, column=0, columnspan=2, sticky="w", pady=(5, 8))

        def update_matches(*_args):
            count = self._highlight_find_matches(self.find_var.get())
            status.set(f"{count} match(es)" if self.find_var.get() else "Enter text to search. Closing clears highlights.")

        def step(direction: int):
            query = self.find_var.get()
            count = self._highlight_find_matches(query)
            if not query or not count:
                status.set("No matches found" if query else "Enter text to search.")
                return
            origin = self.editor.index("insert")
            if direction > 0:
                hit = self.editor.search(query, f"{origin}+1c", stopindex="end", nocase=True)
                if not hit:
                    hit = self.editor.search(query, "1.0", stopindex="end", nocase=True)
            else:
                hit = self.editor.search(query, origin, stopindex="1.0", backwards=True, nocase=True)
                if not hit:
                    hit = self.editor.search(query, "end-1c", stopindex="1.0", backwards=True, nocase=True)
            if hit:
                self.editor.mark_set("insert", hit)
                self.editor.see(hit)
                status.set(f"Match at line {self.editor.index(hit).split('.')[0]} of {count}")

        self.find_var.trace_add("write", update_matches)
        self.find_entry.bind("<Return>", lambda _e: (step(1), "break")[1])
        self.find_entry.bind("<Shift-Return>", lambda _e: (step(-1), "break")[1])
        ttk.Button(frame, text="Previous", command=lambda: step(-1)).grid(row=2, column=0, sticky="ew", padx=(0, 4))
        ttk.Button(frame, text="Next", command=lambda: step(1)).grid(row=2, column=1, sticky="ew", padx=(4, 0))
        ttk.Button(frame, text="Close", command=self._close_find_dialog).grid(row=3, column=0, columnspan=2, sticky="e", pady=(8, 0))
        window.protocol("WM_DELETE_WINDOW", self._close_find_dialog)
        self._apply_custom_theme()
        self.find_entry.focus_set()
        return "break"

    def _highlight_find_matches(self, query: str) -> int:
        self.editor.tag_remove("search_result", "1.0", "end")
        if not query:
            return 0
        self.editor.tag_configure("search_result", background="#f2d95c", foreground="#171717")
        start, count = "1.0", 0
        while True:
            found = self.editor.search(query, start, stopindex="end", nocase=True)
            if not found:
                break
            end = f"{found}+{len(query)}c"
            self.editor.tag_add("search_result", found, end)
            start = end
            count += 1
        return count

    def _close_find_dialog(self) -> None:
        self.editor.tag_remove("search_result", "1.0", "end")
        self.editor.tag_remove("sel", "1.0", "end")
        if self.find_window is not None:
            try:
                self.find_window.destroy()
            except tk.TclError:
                pass
        self.find_window = None
        self.find_var = None
        self.status.set("Search closed; highlights cleared")

    def _open_source_control(self) -> None:
        window = tk.Toplevel(self.root)
        window.title("Source Control — Git")
        window.geometry("640x410")
        frame = ttk.Frame(window, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="What is Source Control?", font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Source control records changes to project files so you can compare versions, review edits, and restore earlier work. Modkec uses Git for this panel. It is optional and does not run or repair your code.", wraplength=600).pack(anchor="w", pady=(5, 10))
        text = tk.Text(frame, wrap="word", padx=10, pady=10, height=12)
        text.pack(fill="both", expand=True)
        candidates = []
        if self.current_path:
            candidates.append(self.current_path.parent)
        candidates.extend(self.workspace_folders)
        repo = None
        for folder in candidates:
            try:
                result = subprocess.run(["git", "-C", str(folder), "rev-parse", "--show-toplevel"], capture_output=True, text=True, timeout=3, check=False)
                if result.returncode == 0 and result.stdout.strip():
                    repo = Path(result.stdout.strip())
                    break
            except (OSError, subprocess.TimeoutExpired):
                text.insert("1.0", "Git is not installed or could not be started. Install Git to use source control.\n")
                break
        if repo:
            try:
                result = subprocess.run(["git", "-C", str(repo), "status", "--short", "--branch"], capture_output=True, text=True, timeout=5, check=False)
                detail = result.stdout.strip() or "Git returned no status output."
                if result.returncode:
                    detail = result.stderr.strip() or "Could not read Git status."
                text.insert("end", f"Repository: {repo}\n\n{detail}\n\nThis view currently displays status only; staging, commits, and history navigation are not yet implemented.")
            except (OSError, subprocess.TimeoutExpired) as exc:
                text.insert("end", f"Could not read Git status: {exc}")
        else:
            if not text.get("1.0", "end-1c").strip():
                text.insert("end", "No Git repository was found for the current file or workspace folders.\n\nTo use this feature, install Git and open a project folder that is already a Git repository (or initialize one with git init). This panel is currently read-only status display; it does not yet provide staging, commits, branches, diffs, or history navigation.")
        text.configure(state="disabled")
        ttk.Button(frame, text="Close", command=window.destroy).pack(anchor="e", pady=(8, 0))
        self._apply_custom_theme()

    def open_extensions(self) -> None:
        window = tk.Toplevel(self.root)
        window.title("Modkec Extension Manager")
        window.geometry("880x580")
        window.minsize(680, 440)
        frame = ttk.Frame(window, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="EXTENSIONS AND LANGUAGE SUPPORT", font=("TkDefaultFont", 11, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Translation packs enable Modkec export. Native-language runners use your installed compilers. Community extensions can add Modkec commands; installing one runs its Python code, so install only code you trust.", wraplength=830).pack(anchor="w", pady=(3, 10))
        search_var = tk.StringVar()
        search_row = ttk.Frame(frame)
        search_row.pack(fill="x", pady=(0, 7))
        ttk.Label(search_row, text="Search").pack(side="left", padx=(0, 6))
        ttk.Entry(search_row, textvariable=search_var).pack(side="left", fill="x", expand=True)
        list_frame = ttk.Frame(frame)
        list_frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(list_frame, columns=("category", "status", "name", "details"), show="headings", selectmode="browse")
        for column, title in (("category", "Type"), ("status", "Status"), ("name", "Extension / language"), ("details", "Runtime / purpose")):
            tree.heading(column, text=title)
        tree.column("category", width=120, stretch=False)
        tree.column("status", width=130, stretch=False)
        tree.column("name", width=230, stretch=False)
        tree.column("details", width=360, stretch=True)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=tree.yview)
        scrollbar.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scrollbar.set)

        runtime_checks = {
            "python": ("python3", "python"), "javascript": ("node",), "typescript": ("tsx",),
            "java": ("java", "javac"), "c": ("gcc",), "cpp": ("g++",), "csharp": ("dotnet",),
            "rust": ("rustc",), "go": ("go",), "lua": ("lua",), "luau": ("luau",),
            "ruby": ("ruby",), "php": ("php",), "perl": ("perl",), "r": ("Rscript",),
            "julia": ("julia",), "kotlin": ("kotlinc", "java"), "swift": ("swift",),
            "dart": ("dart",), "scala": ("scala",), "clojure": ("clojure",),
            "haskell": ("runghc",), "elixir": ("elixir",), "bash": ("bash",),
            "powershell": ("pwsh",), "sql": ("sqlite3",), "fortran": ("gfortran",),
            "lisp": ("sbcl",), "scheme": ("guile",), "visual-basic": ("dotnet",),
            "fsharp": ("dotnet",), "objective-c": ("clang",), "groovy": ("groovy",),
            "ocaml": ("ocaml",), "erlang": ("escript",), "octave": ("octave",),
            "zig": ("zig",), "cobol": ("cobc",),
        }

        def runtime_status(key, spec):
            checks = runtime_checks.get(key, ())
            if not checks:
                return "Built in", spec.get("runtime", "No external runtime")
            if key == "python":
                found = [executable for executable in checks if shutil.which(executable)]
                if found:
                    return "Runtime found", "Uses " + " or ".join(found)
                return "Runtime missing", "Needs python3 or python"
            missing = [executable for executable in checks if not shutil.which(executable)]
            if missing:
                return "Runtime missing", "Needs " + " + ".join(missing)
            return "Runtime found", "Uses " + " + ".join(checks)

        def refresh():
            tree.delete(*tree.get_children())
            self.installed_targets = installed_targets()
            query = search_var.get().strip().lower()
            rows = []
            for target, spec in TARGETS.items():
                if target not in self.installed_targets and query and query not in target.lower() and query not in spec["label"].lower() and "translation" not in query and "export" not in query:
                    continue
                rows.append((f"target:{target}", "Translator / export", "Installed" if target in self.installed_targets else "Not installed", spec["label"], f"Target: {target}; required for Modkec Translate / Export"))
            for key, spec in NATIVE_LANGUAGES.items():
                haystack = f"{key} {spec['label']} {spec['suffix']} {spec['runtime']}".lower()
                if query and query not in haystack:
                    continue
                status, detail = runtime_status(key, spec)
                rows.append((f"native:{key}", "Native language", status, f"{spec['label']} ({spec['suffix']})", detail))
            if not query or any(term in "compact kit compact-kit templates" for term in query.split()):
                rows.append(("builtin:compact-kit", "Built-in extension", "Built in", "Compact Kit", "Editable templates for calculators, game systems, and utilities"))
            for extension in list_community_extensions():
                haystack = f"{extension['id']} {extension['name']} {extension['version']} {' '.join(extension['commands'])} {extension['error']}".lower()
                if query and query not in haystack:
                    continue
                state = "Load error" if extension["error"] else "Installed"
                detail = extension["error"] or ("Commands: " + ", ".join(extension["commands"]) if extension["commands"] else "No commands registered")
                rows.append((f"community:{extension['id']}", "Community extension", state,
                             f"{extension['name']} v{extension['version']}", detail))
            for iid, category, status, name, detail in rows:
                tree.insert("", "end", iid=iid, values=(category, status, name, detail))

        search_var.trace_add("write", lambda *_: refresh())

        def toggle_target():
            selected = tree.selection()
            if not selected:
                messagebox.showinfo("Select an extension", "Select a translator pack, native language, or built-in extension first.", parent=window)
                return
            selected_id = selected[0]
            if selected_id.startswith("target:"):
                target = selected_id.split(":", 1)[1]
                try:
                    if target in self.installed_targets:
                        uninstall_target(target)
                    else:
                        install_target(target)
                except (OSError, ValueError) as exc:
                    messagebox.showerror("Could not save extensions", str(exc), parent=window)
                    return
                refresh()
                values = sorted(installed_targets())
                if set(TARGETS).issubset(values):
                    values.append("all")
                self.installed_targets = installed_targets()
                self.target_box.configure(values=tuple(values) or ("python",))
                if self.target.get() not in values:
                    self.target.set(values[0] if values else "python")
                self.status.set("Translation extension settings updated")
                return
            if selected_id.startswith("native:"):
                key = selected_id.split(":", 1)[1]
                spec = NATIVE_LANGUAGES[key]
                state, detail = runtime_status(key, spec)
                messagebox.showinfo(spec["label"] + " support", f"Native editing support is built into Modkec Studio.\\n\\nRuntime status: {state}\\n{detail}\\n\\nInstall the runtime/compiler separately using your operating system's package manager or the language's official installer. Modkec does not download compilers automatically.", parent=window)
                return
            if selected_id.startswith("community:"):
                extension_id = selected_id.split(":", 1)[1]
                item = next((extension for extension in list_community_extensions() if extension["id"] == extension_id), None)
                if item:
                    detail = item["error"] or ("Registered commands: " + ", ".join(item["commands"]))
                    messagebox.showinfo(item["name"], f"ID: {item['id']}\nVersion: {item['version']}\n\n{detail}\n\nPython extensions run with your normal user permissions. Review their source before executing a script that imports them.", parent=window)
                return
            messagebox.showinfo("Compact Kit", "Compact Kit is built in. Use Extensions → Compact Kit Extension to insert one of its editable templates into the current script.", parent=window)

        def install_community():
            archive = filedialog.askopenfilename(parent=window, title="Install local Modkec extension package",
                                                 filetypes=(("Modkec extension ZIP", "*.zip"), ("All files", "*")))
            if not archive:
                return
            if not messagebox.askyesno("Install executable extension?",
                    "A Modkec extension can run arbitrary Python code with your user permissions, read and write files, and access the network. Only install a package whose source you have reviewed. Continue?", parent=window):
                return
            try:
                result = install_extension_archive(archive)
            except Exception as exc:
                messagebox.showerror("Extension installation failed", str(exc), parent=window)
                return
            refresh()
            self.status.set(f"Installed extension {result['name']}. Commands are available after import({result['id']}).")
            messagebox.showinfo("Extension installed", f"{result['name']} v{result['version']} installed.\n\nCommands: {', '.join(result['commands'])}\n\nUse import({result['id']}) in a Modkec script to enable its commands.", parent=window)

        def uninstall_community():
            selected = tree.selection()
            if not selected or not selected[0].startswith("community:"):
                messagebox.showinfo("Select community extension", "Select an installed community extension first.", parent=window)
                return
            extension_id = selected[0].split(":", 1)[1]
            item = next((extension for extension in list_community_extensions() if extension["id"] == extension_id), None)
            label = item["name"] if item else extension_id
            if not messagebox.askyesno("Uninstall extension", f"Remove {label} from Modkec Studio?", parent=window):
                return
            try:
                uninstall_community_extension(extension_id)
            except (OSError, ValueError) as exc:
                messagebox.showerror("Uninstall failed", str(exc), parent=window)
                return
            refresh()
            self.status.set(f"Uninstalled extension {extension_id}")

        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=(10, 0))
        ttk.Button(buttons, text="Install / Uninstall selected translator", command=toggle_target).pack(side="left")
        ttk.Button(buttons, text="Install local extension ZIP…", command=install_community).pack(side="left", padx=6)
        ttk.Button(buttons, text="Uninstall community extension", command=uninstall_community).pack(side="left")
        ttk.Button(buttons, text="Check GitHub forks…", command=self.check_github_forks).pack(side="left", padx=6)
        ttk.Button(buttons, text="Close", command=window.destroy).pack(side="right")
        refresh()
        self._apply_custom_theme()

    def check_github_forks(self) -> None:
        """Show public forks as potential community submissions; never execute them."""
        window = tk.Toplevel(self.root)
        window.title("Modkec Community Forks")
        window.geometry("760x500")
        outer = ttk.Frame(window, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Community forks of Civilijanos/Modkec-Coding-Language").pack(anchor="w")
        ttk.Label(outer, text="Forks are listed for discovery only. Review their code before installing or running anything.", wraplength=700).pack(anchor="w", pady=(3, 8))
        listing = tk.Listbox(outer, activestyle="dotbox")
        listing.pack(fill="both", expand=True)
        status = tk.StringVar(value="Checking GitHub…")
        ttk.Label(outer, textvariable=status).pack(anchor="w", pady=(6, 0))
        repos: list[dict] = []
        def load() -> None:
            try:
                request = urllib.request.Request(
                    "https://api.github.com/repos/Civilijanos/Modkec-Coding-Language/forks?per_page=100&sort=newest",
                    headers={"Accept": "application/vnd.github+json", "User-Agent": "Modkec-Studio-Extension-Manager"},
                )
                with urllib.request.urlopen(request, timeout=8) as response:
                    data = json.loads(response.read().decode("utf-8"))
                repos.extend(data if isinstance(data, list) else [])
                def populate() -> None:
                    for repo in repos:
                        listing.insert("end", f"{repo.get('full_name', 'Unknown')}  ★ {repo.get('stargazers_count', 0)}  —  {repo.get('description') or 'No description'}")
                    status.set(f"Loaded {len(repos)} public fork(s). Select one and double-click to open it.")
                window.after(0, populate)
            except Exception as exc:
                window.after(0, lambda: status.set(f"Could not check GitHub: {exc}"))
        def open_selected(_event=None) -> None:
            selection = listing.curselection()
            if selection and selection[0] < len(repos):
                webbrowser.open(repos[selection[0]].get("html_url", "https://github.com/Civilijanos/Modkec-Coding-Language/forks"))
        listing.bind("<Double-1>", open_selected)
        ttk.Button(outer, text="Open selected fork", command=open_selected).pack(anchor="e", pady=(6, 0))
        self._apply_custom_theme()
        threading.Thread(target=load, daemon=True).start()

    def _scroll_editor(self, *args) -> None:
        self.editor.yview(*args)
        self.line_numbers.yview(*args)

    def _sync_scroll(self, first: str, last: str) -> None:
        self.line_numbers.yview_moveto(first)
        self._update_line_numbers()

    def _update_line_numbers(self) -> None:
        count = int(self.editor.index("end-1c").split(".")[0])
        text = "\n".join(str(i) for i in range(1, count + 1))
        self.line_numbers.configure(state="normal")
        self.line_numbers.delete("1.0", "end")
        self.line_numbers.insert("1.0", text)
        self.line_numbers.configure(state="disabled")

    def _on_modified(self, _event=None) -> None:
        if self._switching_document:
            return
        if self.editor.edit_modified():
            self.dirty = True
            self._set_title()
            self.editor.edit_modified(False)
            self._update_line_numbers()
            if 0 <= self.active_document_index < len(self.documents):
                self.documents[self.active_document_index].update(source=self._source(), path=self.current_path, dirty=True)
            if self.auto_save.get() and self.current_path is not None:
                self.root.after(1000, self._autosave_if_needed)

    def _autosave_if_needed(self) -> None:
        if self.auto_save.get() and self.dirty and self.current_path is not None:
            self.save_file()

    def _set_title(self) -> None:
        label = self.current_path.name if self.current_path else "Untitled.modkec"
        self.root.title(f"{'*' if self.dirty else ''}{label} — Modkec Studio")
        self._update_tab_label()

    def _source(self) -> str:
        return self.editor.get("1.0", "end-1c")

    def _require_modkec_source(self, feature: str) -> bool:
        """Prevent Modkec-only tools from parsing an open native-language file."""
        if self.current_path is None:
            return True
        native_suffixes = {spec["suffix"].lower() for spec in NATIVE_LANGUAGES.values()}
        native_suffixes.update({".pyw", ".mjs", ".cjs", ".htm", ".bash", ".ex", ".cc", ".cxx"})
        if self.current_path.suffix.lower() not in native_suffixes:
            return True
        messagebox.showinfo(
            f"{feature} requires Modkec source",
            f"{feature} works with Modkec scripts, not {self.current_path.suffix} source files.\n\n"
            "Create or open a .modkec file to use this feature.",
            parent=self.root,
        )
        return False

    def _write_output(self, text: str) -> None:
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text.rstrip() + "\n")
        self.output.configure(state="disabled")

    def _refresh_help(self) -> None:
        self.help_text.configure(state="normal")
        self.help_text.delete("1.0", "end")
        if self.show_descriptions.get():
            for command, description in COMMAND_HELP.items():
                self.help_text.insert("end", command + "\n", "heading")
                self.help_text.insert("end", description + "\n\n")
            self.help_text.tag_configure("heading", font=("Segoe UI", 9, "bold"), foreground=self.colors["green"])
        else:
            self.help_text.insert("1.0", "Command descriptions are hidden. Enable them under Settings to see the reference.")
        self.help_text.configure(state="disabled")

    def _confirm_discard(self) -> bool:
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel("Unsaved changes", "Save changes before continuing?")
        if answer is None:
            return False
        if answer:
            return self.save_file()
        return True

    def new_file(self) -> None:
        self._capture_document_state()
        self.documents.append({"path": None, "source": "", "dirty": False})
        self._switch_document(len(self.documents) - 1)
        self.status.set("New file")

    def close_document(self, index: int | None = None) -> None:
        index = self.active_document_index if index is None else index
        if not 0 <= index < len(self.documents):
            return
        document = self.documents[index]
        if document.get("dirty"):
            label = Path(document["path"]).name if document.get("path") else "Untitled.modkec"
            answer = messagebox.askyesnocancel("Unsaved changes", f"Save changes to {label} before closing it?", parent=self.root)
            if answer is None:
                return
            if answer:
                if index != self.active_document_index:
                    self._switch_document(index)
                if not self.save_file():
                    return
        was_active = index == self.active_document_index
        self.documents.pop(index)
        if not self.documents:
            self.documents.append({"path": None, "source": "", "dirty": False})
            self.active_document_index = 0
            self._load_document_into_editor(0)
        elif was_active:
            self.active_document_index = min(index, len(self.documents) - 1)
            self._load_document_into_editor(self.active_document_index)
        elif index < self.active_document_index:
            self.active_document_index -= 1
        self._refresh_document_tabs()

    def _load_document_into_editor(self, index: int) -> None:
        document = self.documents[index]
        self._switching_document = True
        try:
            self.editor.delete("1.0", "end")
            self.editor.insert("1.0", document.get("source", ""))
            self.editor.edit_reset()
            self.editor.edit_modified(False)
            self.current_path = Path(document["path"]) if document.get("path") else None
            self.dirty = bool(document.get("dirty"))
            try:
                self.editor.mark_set("insert", document.get("cursor", "1.0"))
                self.editor.xview_moveto(float(document.get("xview", 0.0)))
                self.editor.yview_moveto(float(document.get("yview", 0.0)))
            except (tk.TclError, TypeError, ValueError):
                self.editor.mark_set("insert", "1.0")
        finally:
            self._switching_document = False
        self._highlight_syntax()
        self._update_line_numbers()
        self._set_title()

    def new_source_file(self) -> None:
        """Create a blank source file for a language handled by native-run support."""
        languages = {spec["label"]: spec["suffix"] for spec in NATIVE_LANGUAGES.values()}
        languages = dict(sorted(languages.items(), key=lambda item: item[0].casefold()))
        dialog = tk.Toplevel(self.root)
        dialog.title("New Source File")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        frame = ttk.Frame(dialog, padding=16)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Choose a language for the new file:").pack(anchor="w", pady=(0, 8))
        choice = tk.StringVar(value="Python")
        combo = ttk.Combobox(frame, textvariable=choice, values=tuple(languages), state="readonly", width=28)
        combo.pack(fill="x", pady=(0, 12))
        ttk.Label(frame, text="Running it requires the matching runtime/compiler installed.", wraplength=300).pack(anchor="w", pady=(0, 12))
        def create():
            ext = languages.get(choice.get(), ".txt")
            dialog.destroy()
            name = filedialog.asksaveasfilename(parent=self.root, title=f"Create {choice.get()} source file", initialfile="main" + ext, defaultextension=ext, filetypes=((f"{choice.get()} files", "*" + ext), ("All files", "*")))
            if not name:
                return
            path = Path(name)
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.touch(exist_ok=False)
            except FileExistsError:
                if not messagebox.askyesno("File exists", f"{path.name} already exists. Open it instead?", parent=self.root):
                    return
            except OSError as exc:
                messagebox.showerror("Create source file failed", str(exc), parent=self.root)
                return
            self._open_path(path, confirm=False)
            self.status.set(f"Created {choice.get()} source file: {path.name}")
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Create", command=create).pack(side="right")
        ttk.Button(buttons, text="Cancel", command=dialog.destroy).pack(side="right", padx=6)
        combo.focus_set()

    def open_file(self) -> None:
        name = filedialog.askopenfilename(title="Open Source File", filetypes=(("Modkec files", "*.modkec"), ("Source files", "*.py *.js *.c *.cpp *.rs *.go *.lua *.html *.java *.ts"), ("Text files", "*.txt"), ("All files", "*")), parent=self.root)
        if not name:
            return
        self._open_path(Path(name), confirm=False)

    def save_file(self) -> bool:
        if self.current_path is None:
            return self.save_as()
        try:
            self.current_path.write_text(self._source(), encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc))
            return False
        self.dirty = False
        if 0 <= self.active_document_index < len(self.documents):
            self.documents[self.active_document_index].update(path=self.current_path, source=self._source(), dirty=False)
        self._add_recent(self.current_path)
        self._set_title()
        self.status.set(f"Saved {self.current_path.name}")
        return True

    def save_as(self) -> bool:
        name = filedialog.asksaveasfilename(title="Save Source File", defaultextension=self.current_path.suffix if self.current_path else ".modkec", filetypes=(("All files", "*"),), parent=self.root)
        if not name:
            return False
        self.current_path = Path(name)
        if 0 <= self.active_document_index < len(self.documents):
            self.documents[self.active_document_index]["path"] = self.current_path
        return self.save_file()

    def save_all(self) -> bool:
        """Save every dirty open document, restoring the previously active tab."""
        self._capture_document_state()
        original_index = self.active_document_index
        for index in range(len(self.documents)):
            document = self.documents[index]
            if not document.get("dirty"):
                continue
            self._switch_document(index)
            if not self.current_path:
                if not self.save_as():
                    self._capture_document_state()
                    if 0 <= original_index < len(self.documents):
                        self._switch_document(original_index)
                    return False
            elif not self.save_file():
                self._capture_document_state()
                if 0 <= original_index < len(self.documents):
                    self._switch_document(original_index)
                return False
        if 0 <= original_index < len(self.documents):
            self._switch_document(original_index)
        self.status.set("All modified documents saved")
        return True

    def _ask_input(self, prompt: str) -> str:
        """Collect ask() input through Tkinter instead of Python's console readline."""
        value = simpledialog.askstring("Modkec Input", prompt, parent=self.root)
        return "" if value is None else value

    def run_program(self) -> None:
        """Run the active file with Modkec or its native runtime based on extension."""
        if self.current_path is not None:
            suffix = self.current_path.suffix.lower()
            native_suffixes = {spec["suffix"] for spec in NATIVE_LANGUAGES.values()}
            native_suffixes.update({".pyw", ".mjs", ".cjs", ".htm", ".bash", ".ex", ".cc", ".cxx"})
            if suffix in native_suffixes and suffix != ".modkec":
                self.run_current_file()
                return
        try:
            engine = ModkecEngine(input_fn=self._ask_input, source_name=str(self.current_path) if self.current_path else None, media_callback=lambda _action, owner: self._process_media_actions(owner, len(owner.media_actions) - 1))
            result = engine.run(self._source())
            lines = [result] if result else ["Program finished without printed output."]
            lines += ["", f"[Modkec] Finished. Variables: {engine.variables}"]
            if engine.imported_modules:
                lines.append(f"[Modkec] Imported modules: {', '.join(sorted(engine.imported_modules))}")
            self._write_output("\n".join(lines))
            self.status.set("Run completed")
            if engine.visuals:
                self._show_visual_preview(engine)
        except ModkecError as exc:
            self._write_output(f"[Modkec] Error: {exc}")
            self.status.set("Run failed")
        except Exception as exc:
            self._write_output(f"[Modkec] Runtime error: {type(exc).__name__}: {exc}")
            self.status.set("Run failed")

    def run_current_file(self) -> None:
        """Run a saved source file using its installed system runtime/compiler."""
        if self.current_path is None:
            messagebox.showinfo("Run native file", "Save the file with its real language extension first (for example .py, .js, .rs, or .go).", parent=self.root)
            return
        if self.dirty and not self.save_file():
            return
        path = self.current_path.resolve()
        if not path.is_file():
            messagebox.showerror("Run native file", "The current file does not exist on disk. Save it first.", parent=self.root)
            return
        ext = path.suffix.lower()
        python_runtime = shutil.which("python3") or shutil.which("python") or sys.executable
        binary_out = path.with_suffix(".exe") if os.name == "nt" else path.with_suffix("")
        commands = {
            ".py": (python_runtime, str(path)), ".pyw": (python_runtime, str(path)),
            ".js": ("node", str(path)), ".mjs": ("node", str(path)), ".cjs": ("node", str(path)),
            ".ts": ("tsx", str(path)),
            ".lua": ("lua", str(path)), ".luau": ("luau", str(path)),
            ".rb": ("ruby", str(path)), ".php": ("php", str(path)),
            ".pl": ("perl", str(path)), ".r": ("Rscript", str(path)),
            ".jl": ("julia", str(path)), ".go": ("go", "run", str(path)),
            ".rs": ("rustc", str(path), "-o", str(binary_out)),
            ".java": ("java", str(path)), ".kt": ("kotlinc", str(path), "-include-runtime", "-d", str(path.with_suffix(".jar"))),
            ".swift": ("swift", str(path)), ".sh": ("bash", str(path)), ".bash": ("bash", str(path)),
            ".ps1": ("pwsh", "-File", str(path)), ".sql": ("sqlite3", ":memory:", ".read " + str(path)),
            ".ex": ("elixir", str(path)), ".exs": ("elixir", str(path)),
            ".hs": ("runghc", str(path)), ".dart": ("dart", str(path)),
            ".scala": ("scala", str(path)), ".clj": ("clojure", str(path)),
            ".lisp": ("sbcl", "--script", str(path)), ".scm": ("guile", str(path)),
            ".f90": ("gfortran", str(path), "-o", str(binary_out)),
            ".cpp": ("g++", str(path), "-o", str(binary_out)),
            ".cc": ("g++", str(path), "-o", str(binary_out)),
            ".cxx": ("g++", str(path), "-o", str(binary_out)),
            ".c": ("gcc", str(path), "-o", str(binary_out)),
            ".m": ("clang", str(path), "-o", str(binary_out)),
            ".groovy": ("groovy", str(path)), ".ml": ("ocaml", str(path)),
            ".erl": ("escript", str(path)), ".zig": ("zig", "run", str(path)),
            ".cob": ("cobc", "-x", "-o", str(binary_out), str(path)),
        }
        if ext in (".html", ".htm", ".css", ".svg"):
            try:
                webbrowser.open(path.as_uri())
                self.status.set(f"Opened {path.name} in the default browser")
            except Exception as exc:
                self._write_output(f"[Native Run] Could not open browser: {exc}")
            return
        if ext in (".cs", ".vb", ".fs"):
            if not shutil.which("dotnet"):
                self._write_output("[Native Run] The .NET SDK was not found. Install the SDK before running C#, Visual Basic, or F# files.")
                self.status.set("Missing runtime: dotnet")
                return
            try:
                sdk_listing = subprocess.run(["dotnet", "--list-sdks"], capture_output=True, text=True, timeout=8, check=False)
                sdk_versions = re.findall(r"(?m)^(\d+)\.\d+\.\d+", sdk_listing.stdout)
                framework = f"net{max(map(int, sdk_versions))}.0" if sdk_versions else "net8.0"
                temp_dir = Path(tempfile.mkdtemp(prefix="modkec-native-"))
                if ext == ".cs":
                    (temp_dir / "NativeRun.csproj").write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>{framework}</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup></Project>', encoding="utf-8")
                    (temp_dir / "Program.cs").write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
                    project = temp_dir / "NativeRun.csproj"
                elif ext == ".vb":
                    (temp_dir / "NativeRun.vbproj").write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>{framework}</TargetFramework><RootNamespace>NativeRun</RootNamespace></PropertyGroup></Project>', encoding="utf-8")
                    (temp_dir / "Program.vb").write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
                    project = temp_dir / "NativeRun.vbproj"
                else:
                    (temp_dir / "NativeRun.fsproj").write_text(f'<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>{framework}</TargetFramework></PropertyGroup><ItemGroup><Compile Include="Program.fs" /></ItemGroup></Project>', encoding="utf-8")
                    (temp_dir / "Program.fs").write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
                    project = temp_dir / "NativeRun.fsproj"
                self._launch_native_console(["dotnet", "run", "--project", str(project), "--verbosity", "quiet"], path.parent, path.name, cleanup_path=temp_dir)
            except (OSError, subprocess.TimeoutExpired) as exc:
                self._write_output(f"[Native Run] Could not build or run {path.suffix}: {exc}")
                self.status.set("Native run failed")
            return
        if ext == ".m":
            try:
                source_prefix = path.read_text(encoding="utf-8")[:1000]
            except OSError:
                source_prefix = ""
            if re.search(r"(?im)^\s*(function|endfunction|pkg\s+load|%|clear\s+all)\b|\bdisp\s*\(", source_prefix):
                commands[".m"] = ("octave", "--quiet", "--no-gui", str(path))
        command = commands.get(ext)
        if not command:
            self._write_output(f"[Native Run] No runner is configured for {ext or 'files without an extension'}. Save as a supported language extension or configure a runtime.")
            self.status.set("No runner for this file type")
            return
        executable = command[0]
        if not shutil.which(executable):
            self._write_output(f"[Native Run] Runtime/compiler '{executable}' was not found. Install it with your operating system's package manager, then try again.")
            self.status.set(f"Missing runtime: {executable}")
            return
        try:
            # Compiled languages build to a sibling executable, then run it.
            if executable in {"gcc", "g++", "rustc", "gfortran", "clang", "cobc"}:
                built = subprocess.run(command, cwd=str(path.parent), capture_output=True, text=True, timeout=60, check=False)
                if built.returncode:
                    self._write_output(f"[Native Run] Build failed (exit {built.returncode}):\n{built.stdout}{built.stderr}")
                    self.status.set("Build failed")
                    return
                self._launch_native_console([str(binary_out)], path.parent, path.name)
                return
            elif ext == ".kt":
                built = subprocess.run(command, cwd=str(path.parent), capture_output=True, text=True, timeout=60, check=False)
                if built.returncode:
                    self._write_output(f"[Native Run] Build failed (exit {built.returncode}):\n{built.stdout}{built.stderr}")
                    self.status.set("Build failed")
                    return
                self._launch_native_console(["java", "-jar", str(path.with_suffix(".jar"))], path.parent, path.name)
                return
            else:
                self._launch_native_console(command, path.parent, path.name)
                return
        except subprocess.TimeoutExpired as exc:
            self._write_output(f"[Native Run] Timed out. Partial output: {exc.stdout or ''}\n{exc.stderr or ''}")
            self.status.set("Native run timed out")
        except OSError as exc:
            self._write_output(f"[Native Run] Could not launch program: {exc}")
            self.status.set("Native run failed")

    def _launch_native_console(self, command: list[str] | tuple[str, ...], cwd: Path, title: str, cleanup_path: Path | None = None) -> None:
        """Run a native program in an interactive console with live output and stdin."""
        try:
            process = subprocess.Popen(list(command), cwd=str(cwd), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, bufsize=1)
        except OSError as exc:
            self._write_output(f"[Native Run] Could not launch {title}: {exc}")
            self.status.set("Native run failed")
            if cleanup_path:
                shutil.rmtree(cleanup_path, ignore_errors=True)
            return
        window = tk.Toplevel(self.root)
        window.title(f"Console — {title}")
        window.geometry("850x520")
        window.minsize(560, 340)
        shell = ttk.Frame(window, padding=8)
        shell.pack(fill="both", expand=True)
        heading = ttk.Label(shell, text=f"Running: {' '.join(str(arg) for arg in command)}", wraplength=800)
        heading.pack(fill="x", pady=(0, 6))
        output_frame = ttk.Frame(shell)
        output_frame.pack(fill="both", expand=True)
        console = tk.Text(output_frame, wrap="word", state="disabled", font=("Consolas", 10), padx=8, pady=6,
                          background="#111318", foreground="#e5e7eb", insertbackground="#ffffff")
        console.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(output_frame, orient="vertical", command=console.yview)
        scroll.pack(side="right", fill="y")
        console.configure(yscrollcommand=scroll.set)
        input_row = ttk.Frame(shell)
        input_row.pack(fill="x", pady=(7, 0))
        user_input = tk.StringVar()
        entry = ttk.Entry(input_row, textvariable=user_input)
        entry.pack(side="left", fill="x", expand=True)
        messages: queue.Queue = queue.Queue()
        state = {"closed": False, "finished": False}

        def append_output(message: str) -> None:
            if state["closed"]:
                return
            console.configure(state="normal")
            console.insert("end", message)
            console.see("end")
            console.configure(state="disabled")

        def send_input(_event=None) -> str:
            value = user_input.get()
            user_input.set("")
            try:
                if process.poll() is not None or process.stdin is None:
                    append_output("\n[Process is not accepting input.]\n")
                    return "break"
                process.stdin.write(value + "\n")
                process.stdin.flush()
            except (OSError, BrokenPipeError) as exc:
                append_output(f"\n[Input failed: {exc}]\n")
            return "break"

        def stop_process() -> None:
            if process.poll() is None:
                try:
                    process.terminate()
                except OSError:
                    pass

        def on_console_close() -> None:
            if process.poll() is None:
                if not messagebox.askyesno("Stop program?", "This program is still running. Stop it and close the console?", parent=window):
                    return
                stop_process()
            state["closed"] = True
            window.destroy()

        ttk.Button(input_row, text="Send", command=send_input).pack(side="left", padx=(6, 0))
        ttk.Button(input_row, text="Stop", command=stop_process).pack(side="left", padx=(6, 0))
        entry.bind("<Return>", send_input)
        entry.focus_set()
        window.protocol("WM_DELETE_WINDOW", on_console_close)

        def read_process() -> None:
            try:
                if process.stdout is not None:
                    # Read one character at a time so prompts without newlines can be displayed.
                    while True:
                        character = process.stdout.read(1)
                        if not character:
                            break
                        messages.put(("output", character))
            except (OSError, ValueError) as exc:
                messages.put(("output", f"\n[Console stream error: {exc}]\n"))
            code = process.wait()
            messages.put(("exit", code))
            if cleanup_path:
                shutil.rmtree(cleanup_path, ignore_errors=True)

        threading.Thread(target=read_process, daemon=True).start()
        append_output(f"$ {' '.join(str(arg) for arg in command)}\n")
        self.status.set(f"Running {title} in native console")

        def poll_messages() -> None:
            if state["closed"] or not window.winfo_exists():
                return
            try:
                while True:
                    kind, payload = messages.get_nowait()
                    if kind == "output":
                        append_output(payload)
                    elif kind == "exit":
                        state["finished"] = True
                        append_output(f"\n[Process exited with code {payload}]\n")
                        self.status.set("Native run completed" if payload == 0 else f"Program exited with code {payload}")
            except queue.Empty:
                pass
            window.after(35, poll_messages)

        window.after(35, poll_messages)

    def _resolve_media_path(self, raw_path: object, engine) -> Path:
        path = Path(str(raw_path)).expanduser()
        if not path.is_absolute():
            source = Path(engine.source_name).expanduser() if engine.source_name else Path.cwd()
            base = source.resolve().parent if source.suffix else source.resolve()
            path = base / path
        return path.resolve()

    def _process_media_actions(self, engine, start_index: int) -> int:
        """Dispatch recorded Modkec media commands through available OS players."""
        actions = engine.media_actions
        for action in actions[start_index:]:
            command, args = action.get("command"), action.get("args", [])
            try:
                if command == "volume":
                    self._media_volume = max(0.0, min(100.0, float(args[0])))
                    self.status.set(f"Media volume set to {self._media_volume:g}% for supported players")
                    continue
                if command == "stop_sound":
                    selected = str(args[0]) if args else None
                    processes = getattr(self, "_sound_processes", [])
                    for source, proc in list(processes):
                        if selected is None or selected == source:
                            if proc.poll() is None:
                                proc.terminate()
                            processes.remove((source, proc))
                    if os.name == "nt":
                        try:
                            import winsound
                            winsound.PlaySound(None, winsound.SND_PURGE)
                        except Exception:
                            pass
                    continue
                if command == "play_sound":
                    path = self._resolve_media_path(args[0], engine)
                    if not path.is_file():
                        self._write_output(f"[Media] Audio file not found: {path}")
                        continue
                    looping = len(args) > 1 and args[1] is True
                    player = None
                    if os.name == "nt" and path.suffix.lower() == ".wav":
                        import winsound
                        flags = winsound.SND_FILENAME | winsound.SND_ASYNC
                        if looping:
                            flags |= winsound.SND_LOOP
                        winsound.PlaySound(str(path), flags)
                        continue
                    if looping and shutil.which("ffplay"):
                        player = ["ffplay", "-loop", "0", "-nodisp", "-autoexit", "-loglevel", "error", "-volume", str(int(getattr(self, '_media_volume', 100.0))), str(path)]
                    elif not looping and sys.platform == "darwin" and shutil.which("afplay"):
                        player = ["afplay", "-v", str(getattr(self, "_media_volume", 100.0) / 50.0), str(path)]
                    elif not looping and shutil.which("paplay"):
                        player = ["paplay", f"--volume={int(getattr(self, '_media_volume', 100.0) * 655.36)}", str(path)]
                    elif shutil.which("ffplay"):
                        player = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "error", "-volume", str(int(getattr(self, '_media_volume', 100.0))), str(path)]
                    elif not looping and shutil.which("aplay"):
                        player = ["aplay", str(path)]
                    if player:
                        proc = subprocess.Popen(player, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        if not hasattr(self, "_sound_processes"):
                            self._sound_processes = []
                        self._sound_processes.append((str(args[0]), proc))
                        if looping and player[0] != "ffplay":
                            self._write_output("[Media] This audio player does not support looping; played once instead.")
                    elif os.name == "nt":
                        if looping:
                            self._write_output("[Media] Looping is available for WAV files through the Windows audio player.")
                        os.startfile(str(path))  # type: ignore[attr-defined]
                    else:
                        raise RuntimeError("No supported audio player found. Install paplay, ffplay, aplay, or afplay.")
                    continue
                if command == "play_video":
                    path = self._resolve_media_path(args[0], engine)
                    if not path.is_file():
                        self._write_output(f"[Media] Video file not found: {path}")
                        continue
                    if shutil.which("ffplay"):
                        subprocess.Popen(["ffplay", "-autoexit", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    elif os.name == "nt":
                        os.startfile(str(path))  # type: ignore[attr-defined]
                    else:
                        opener = "open" if sys.platform == "darwin" else "xdg-open"
                        if not shutil.which(opener):
                            webbrowser.open(path.as_uri())
                        else:
                            subprocess.Popen([opener, str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception as exc:
                self._write_output(f"[Media] {command} failed: {exc}")
        return len(actions)

    def preview_program(self) -> None:
        if not self._require_modkec_source("Visele Preview"):
            return
        try:
            engine = ModkecEngine(source_name=str(self.current_path) if self.current_path else None, media_callback=lambda _action, owner: self._process_media_actions(owner, len(owner.media_actions) - 1))
            engine.run(self._source())
        except ModkecError as exc:
            self._write_output(f"[Modkec] Error: {exc}")
            self.status.set("Preview failed")
            return
        if not engine.visuals:
            messagebox.showinfo("Visele Preview", "No visual elements were created. Add import(visele) and commands such as rect(10,10,100,60) or text(\"Hello\").")
            return
        self._show_visual_preview(engine)

    def _show_visual_preview(self, engine) -> None:
        window = tk.Toplevel(self.root)
        window.title("Visele Preview — Modkec Studio")
        window.geometry("820x560")
        canvas = tk.Canvas(window, width=800, height=500, background="white", highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=8, pady=8)

        animations = [dict(a, started_at=time.monotonic()) for a in engine.animations]
        running = {"after_id": None, "closed": False}
        image_references: dict[tuple[int, str, int, int], tk.PhotoImage] = {}

        def faded_color(color, opacity):
            try:
                raw = str(color).lstrip("#")
                if len(raw) != 6: return color
                rgb = [int(raw[i:i+2], 16) for i in (0, 2, 4)]
                amount = max(0.0, min(100.0, float(opacity))) / 100.0
                return "#" + "".join(f"{round(255 - (255 - channel) * amount):02x}" for channel in rgb)
            except (ValueError, TypeError):
                return color

        def rotated_rect(x, y, w, h, degrees):
            import math
            cx, cy = x + w / 2, y + h / 2
            angle = math.radians(degrees)
            points = [(x,y),(x+w,y),(x+w,y+h),(x,y+h)]
            result=[]
            for px, py in points:
                dx, dy = px-cx, py-cy
                result.extend((cx + dx*math.cos(angle) - dy*math.sin(angle), cy + dx*math.sin(angle) + dy*math.cos(angle)))
            return result

        def draw_frame():
            if running["closed"] or not window.winfo_exists(): return
            now = time.monotonic()
            active=[]
            for animation in animations:
                index = animation["target_index"]
                if index >= len(engine.visuals): continue
                elapsed = max(0.0, now - animation["started_at"])
                progress = min(1.0, elapsed / animation["duration"])
                value = animation["start"] + (animation["end"] - animation["start"]) * progress
                item = engine.visuals[index]
                if animation["property"] == "rotation": item["_rotation"] = value
                else: item[animation["property"]] = value
                if progress < 1.0: active.append(animation)
            animations[:] = active

            canvas.delete("all")
            for index, item in sorted(enumerate(engine.visuals), key=lambda pair: pair[1].get("layer", 0)):
                if item.get("hidden"):
                    continue
                kind = item.get("kind")
                color = faded_color(item.get("color", "#000000"), item.get("opacity", 100))
                rotation = float(item.get("_rotation", 0))
                if kind == "pixel":
                    x, y = item.get("x", 0), item.get("y", 0)
                    canvas.create_rectangle(x, y, x+1, y+1, fill=color, outline=color)
                elif kind in ("rect", "square"):
                    x, y, w, h = item.get("x", 0), item.get("y", 0), item.get("w", 50), item.get("h", 50)
                    if rotation:
                        canvas.create_polygon(*rotated_rect(x,y,w,h,rotation), fill=color, outline=color)
                    else:
                        canvas.create_rectangle(x, y, x+w, y+h, fill=color, outline=color)
                elif kind == "circle":
                    x, y, r = item.get("x", 0), item.get("y", 0), item.get("r", 10)
                    canvas.create_oval(x-r, y-r, x+r, y+r, fill=color, outline=color)
                elif kind == "line":
                    x1,y1,x2,y2 = item.get("x1",0),item.get("y1",0),item.get("x2",50),item.get("y2",50)
                    if rotation:
                        import math
                        cx,cy=(x1+x2)/2,(y1+y2)/2; angle=math.radians(rotation)
                        x1,y1=cx+(x1-cx)*math.cos(angle)-(y1-cy)*math.sin(angle),cy+(x1-cx)*math.sin(angle)+(y1-cy)*math.cos(angle)
                        x2,y2=cx+(x2-cx)*math.cos(angle)-(y2-cy)*math.sin(angle),cy+(x2-cx)*math.sin(angle)+(y2-cy)*math.cos(angle)
                    canvas.create_line(x1,y1,x2,y2,fill=color,width=2)
                elif kind == "text":
                    canvas.create_text(item.get("x",10), item.get("y",20), text=item.get("text", ""), fill=color, anchor="nw", angle=rotation)
                elif kind == "image":
                    x,y=item.get("x",10),item.get("y",10); w,h=max(1,int(item.get("w",100))),max(1,int(item.get("h",100)))
                    try:
                        source_path = self._resolve_media_path(item.get("path", ""), engine)
                        cache_key = (index, str(source_path), w, h)
                        image = image_references.get(cache_key)
                        if image is None:
                            image = tk.PhotoImage(file=str(source_path))
                            factor = max(1, (image.width() + w - 1) // w, (image.height() + h - 1) // h)
                            if factor > 1:
                                image = image.subsample(factor, factor)
                            image_references[cache_key] = image
                        canvas.create_image(x, y, image=image, anchor="nw")
                    except (tk.TclError, OSError, ValueError) as exc:
                        canvas.create_rectangle(x, y, x+w, y+h, outline=color)
                        canvas.create_text(x+w/2, y+h/2, text=f"Image unavailable\n{item.get('path','')}\n{exc}", fill=color, angle=rotation)
                elif kind == "button":
                    x,y,w,h=item.get("x",10),item.get("y",10),item.get("w",100),item.get("h",35)
                    if rotation: shape=canvas.create_polygon(*rotated_rect(x,y,w,h,rotation), fill=faded_color("#e8e8e8",item.get("opacity",100)), outline=color, width=2, tags=("visele_button",))
                    else: shape=canvas.create_rectangle(x,y,x+w,y+h,fill=faded_color("#e8e8e8",item.get("opacity",100)),outline=color,width=2,tags=("visele_button",))
                    text_tag=canvas.create_text(x+w/2,y+h/2,text=item.get("text", "Button"),fill=faded_color("#111111",item.get("opacity",100)),angle=rotation,tags=("visele_button",))
                    if item.get("interactive"):
                        label=item.get("text", "Button")
                        item_action=item.get("action")
                        button_tag=f"visele_button_{index}"
                        canvas.addtag_withtag(button_tag, shape)
                        canvas.addtag_withtag(button_tag, text_tag)
                        def clicked(_event, label=label, item_action=item_action):
                            # Buttons may name their own action in Modkec:
                            # button("7", x, y, press_key). The clicked label is
                            # passed to that action as its first parameter.
                            action=item_action or engine.events.get("click")
                            if action:
                                try:
                                    if item_action:
                                        engine._run_action(action, [label])
                                    else:
                                        engine._run_action(action)
                                    self._write_output("\n".join(engine.output) or f"Clicked: {label}")
                                    draw_frame()
                                except ModkecError as exc:
                                    self._write_output(f"[Modkec] Click event error: {exc}")
                            else:
                                self._write_output(f"Clicked: {label} (define on(click) do(action) to handle it)")
                        canvas.tag_bind(button_tag, "<Button-1>", clicked)
                        canvas.tag_bind(shape, "<Button-1>", clicked)
                        canvas.tag_bind(text_tag, "<Button-1>", clicked)
            if animations:
                running["after_id"] = window.after(16, draw_frame)

        def close_preview():
            running["closed"] = True
            if running["after_id"] is not None:
                try: window.after_cancel(running["after_id"])
                except tk.TclError: pass
            window.destroy()

        window.protocol("WM_DELETE_WINDOW", close_preview)
        draw_frame()
        self.status.set("Visele preview opened" + (" — animation running" if animations else ""))

    def translate_program(self) -> None:
        if not self._require_modkec_source("Translation"):
            return
        target = self.target.get()
        if target == "all":
            missing = sorted(set(TARGETS) - self.installed_targets)
            if missing:
                self._write_output("[Modkec] Install all target extensions first: " + ", ".join(missing))
                self.status.set("Translation extensions required")
                return
        elif target not in self.installed_targets:
            self._write_output(f"[Modkec] The {target} translation extension is not installed. Open Extensions → Manage Extensions to install it.")
            self.status.set("Translation extension required")
            return
        try:
            generated = translate(self._source(), target)
            self._write_output(f"[Modkec] Translated to {target}:\n\n{generated}")
            self.status.set(f"Translated to {target}")
        except ModkecError as exc:
            self._write_output(f"[Modkec] Translation error: {exc}")
            self.status.set("Translation failed")

    def export_program(self) -> None:
        if not self._require_modkec_source("Export"):
            return
        target = self.target.get()
        if target == "all":
            missing = sorted(set(TARGETS) - self.installed_targets)
            if missing:
                messagebox.showinfo("Extensions required", "Install the target extensions first:\n\n" + "\n".join(missing), parent=self.root)
                self.open_extensions()
                return
        elif target not in self.installed_targets:
            self._write_output(f"[Modkec] The {target} translation extension is not installed. Open Extensions → Manage Extensions to install it.")
            self.status.set("Export extension required")
            return
        extensions = {"python": ".py", "javascript": ".js", "lua": ".lua", "luau": ".luau", "c": ".c", "html": ".html", "all": ".zip"}
        suggested = (self.current_path.stem if self.current_path else "program") + extensions[target]
        name = filedialog.asksaveasfilename(title=f"Export {target} code", initialfile=suggested, defaultextension=extensions[target], filetypes=((f"{target} files", f"*{extensions[target]}"), ("All files", "*")))
        if not name:
            return
        try:
            path = export(self._source(), target, name)
            self._write_output(f"[Modkec] Exported {target} code to:\n{path}")
            self.status.set(f"Exported {path.name}")
        except (OSError, ModkecError) as exc:
            self._write_output(f"[Modkec] Export error: {exc}")
            self.status.set("Export failed")

    def show_tutorial(self) -> None:
        window = tk.Toplevel(self.root)
        window.title("Modkec Quick Start")
        window.geometry("650x520")
        window.minsize(480, 360)
        frame = ttk.Frame(window, padding=12)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="MODKEC QUICK START", font=("TkDefaultFont", 12, "bold")).pack(anchor="w", pady=(0, 8))
        body = tk.Text(frame, wrap="word", padx=10, pady=10, font=("TkDefaultFont", 10), height=20)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=body.yview)
        body.configure(yscrollcommand=scrollbar.set)
        body.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        body.insert("1.0", """1. Write Modkec commands in the source editor.

2. Click Run or press F5 to execute your program.

3. Use Program → Create Custom Command to insert a reusable command definition. Use Extensions → Compact Kit Extension to insert editable templates for common operations.

4. Use Program → Beatmaker to create a 16-step rhythm and export it as a WAV file. Run Current File uses installed native runtimes for saved source files.

5. Translation and export require the matching target extension. Open Extensions → Manage Extensions to install target packs.

Example:
say(\"Hello from Modkec!\")
set(score, 12)
say(score)

Modules require import(module), for example import(visele), import(calculator), or import(files). Visele commands can be previewed in Studio.

Native Python blocks require import(py) followed by python() ... end_python(). They can access your computer and installed libraries; only run code you trust.

Use the arrow keys to navigate the project tree and Enter to open a selected file. The editor and bottom panel can be resized by dragging their divider.""")
        body.configure(state="disabled")

    def show_about(self) -> None:
        messagebox.showinfo("About Modkec Studio", "Modkec Studio v0.9.2 development build\nModular Development Kit for Extensible Coding\n\nA beginner-focused editor, interpreter, and extensible development environment. Built with Python and Tkinter; the Compact Kit and beatmaker use the Python standard library.")

    def on_close(self) -> None:
        self._capture_document_state()
        for index in range(len(self.documents)):
            document = self.documents[index]
            if not document.get("dirty"):
                continue
            self._switch_document(index)
            label = Path(document["path"]).name if document.get("path") else "Untitled.modkec"
            answer = messagebox.askyesnocancel("Unsaved changes", f"Save changes to {label} before exiting?", parent=self.root)
            if answer is None:
                return
            if answer and not self.save_file():
                return
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    profile_path = None
    if "--profile" in sys.argv:
        try:
            profile_path = sys.argv[sys.argv.index("--profile") + 1]
        except IndexError:
            profile_path = None
    ModkecStudio(root, profile_path=profile_path)
    root.mainloop()

if __name__ == "__main__":
    main()
