import tempfile
import unittest
from pathlib import Path
from modkec import ModkecEngine


class NativeSiteBuilderTests(unittest.TestCase):
    def test_builds_site_from_native_commands(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "index.html"
            source = f'''import(web)
site_start("Native Modkec Site", "Built from Modkec commands")
site_nav_item("Downloads", "#downloads")
site_hero("Build with", "A native source file.", "Downloads", "#downloads", "Docs", "#docs")
site_stat("Native", "No raw web source")
site_section("downloads", "Release library", "Downloads", "Browse builds.")
site_search("builds", "Search builds")
site_list_start("builds", "versions")
site_download("0.8.1", "Modkec Studio", "Development", "Native site builder included.", "Linux,Windows", "downloads/build.zip", "Development build")
site_list_end()
site_build("{output.as_posix()}")
'''
            engine = ModkecEngine()
            message = engine.run(source)
            self.assertIn("Website generated:", message)
            page = output.read_text(encoding="utf-8")
            self.assertIn("Native Modkec Site", page)
            self.assertIn('id="builds"', page)
            self.assertIn("data-site-search=\"builds\"", page)
            self.assertIn("downloads/build.zip", page)
            self.assertIn("data-searchable", page)

    def test_native_site_text_buttons_images_theme_and_css(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "custom.html"
            source = f'''import(web)
site_start("My Site", "Native website")
site_theme("#ff5500", "#101010")
site_section("intro", "Welcome", "A custom page", "Built in Modkec")
site_text("This is a paragraph.", "p")
site_button("Start here", "#intro", "secondary")
site_image("assets/banner.png", "Banner", "80%")
site_link("Repository", "https://example.com")
site_custom_css(".site-text {{ font-size: 20px; }}")
site_build("{output.as_posix()}")
'''
            ModkecEngine().run(source)
            page = output.read_text(encoding="utf-8")
            self.assertIn("This is a paragraph.", page)
            self.assertIn('href="#intro"', page)
            self.assertIn('src="assets/banner.png"', page)
            self.assertIn('--purple:#ff5500', page)
            self.assertIn('.site-text { font-size: 20px; }', page)
            self.assertIn('https://example.com', page)

    def test_site_commands_require_web_import(self):
        with self.assertRaisesRegex(Exception, r"requires import\(web\)"):
            ModkecEngine().run('site_start("No module")')


if __name__ == "__main__":
    unittest.main()
