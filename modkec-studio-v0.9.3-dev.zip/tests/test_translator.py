import unittest
import io
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
from modkec.translator import export, translate
from modkec.engine import ModkecEngine, ModkecError

class TranslatorTests(unittest.TestCase):
    def test_targets(self):
        source='say("Hello")\nset(score, 12)\nadd(score, 1) -> next_score'
        for target in ('python','javascript','lua','luau'):
            with self.subTest(target=target):
                code=translate(source,target)
                self.assertIn('Hello',code)
                self.assertIn('next_score',code)

    def test_original_condition(self):
        source='action(win)\n say("win")\nend()\nif(score > 10)=t, do(win)'
        self.assertIn('if',translate(source,'python'))

    def test_custom_command_translates_with_parameters_and_return(self):
        source='''import(actions)
command(double, value)
    return(value * 2)
end()
double(21) -> answer
say(answer)'''
        code = translate(source, 'python')
        self.assertIn('def double(value):', code)
        self.assertIn('return (value * 2)', code)
        self.assertIn('answer = double(21)', code)

    def test_python_block_passes_through_only_to_python(self):
        source='''import(py)
python()
answer = 6 * 7
print(answer)
end_python()
say(answer)'''
        code = translate(source, 'python')
        self.assertIn('answer = 6 * 7', code)
        self.assertIn('print(answer)', code)
        with self.assertRaisesRegex(ModkecError, 'only be translated to Python'):
            translate(source, 'javascript')


    def test_c_and_html_basic_targets(self):
        source='say("Hello")\nset(score, 12)\nsay(score)'
        self.assertIn('#include <stdio.h>', translate(source, 'c'))
        self.assertIn('<p>Hello</p>', translate(source, 'html'))

    def test_c_translation_supports_actions_and_conditional_calls(self):
        source = '''set(score, 12)
action(win)
    say("You win!")
end()
if(score > 10)=t, do(win)'''
        code = translate(source, 'c')
        self.assertIn('double score;', code)
        self.assertIn('void win(void)', code)
        self.assertIn('if ((score > 10)) { win(); }', code)

    def test_html_translation_preserves_simple_action_logic(self):
        source = '''set(score, 12)
action(win)
    say("You win!")
end()
if(score > 10)=t, do(win)'''
        code = translate(source, 'html')
        self.assertIn('<pre id="output"></pre>', code)
        self.assertIn('function win()', code)
        self.assertIn('if ((score > 10)) { win(); }', code)

    def test_all_targets_returns_sections(self):
        code=translate('say("Hi")', 'all')
        for label in ('PYTHON','JAVASCRIPT','LUA','LUAU','C','HTML'):
            self.assertIn(label, code)

    def test_web_source_translates_to_html_and_javascript(self):
        source = '''title("Example site")
html()
<main><h1 id="heading">Hello</h1><button id="change">Change</button></main>
end_html()
style()
body { color: purple; }
end_style()
script()
document.querySelector("#change").addEventListener("click", () => {
  document.querySelector("#heading").textContent = "Changed";
});
end_script()'''
        html = translate(source, "html")
        javascript = translate(source, "javascript")
        self.assertIn("<title>Example site</title>", html)
        self.assertIn("body { color: purple; }", html)
        self.assertIn('document.querySelector("#change")', html)
        self.assertIn("document.body.innerHTML", javascript)
        self.assertIn("document.createElement('style')", javascript)
        self.assertIn('document.querySelector("#change")', javascript)

    def test_web_source_rejects_missing_block_terminator(self):
        with self.assertRaises(ModkecError):
            translate('html()\n<main>Oops</main>', 'html')

    def test_unknown_target(self):
        with self.assertRaises(ModkecError): translate('say("x")','unknown')


    def test_basic_calculator_translation_compiles_and_runs(self):
        source = '''import(calculator)
import(logic)
import(text)
ask("Enter the first number:") -> first_text
ask("Enter the second number:") -> second_text
ask("Choose add, subtract, multiply, divide, or modulus:") -> operation
number(first_text) -> first
number(second_text) -> second
equal(operation, "add") -> is_add
equal(operation, "subtract") -> is_subtract
equal(operation, "multiply") -> is_multiply
equal(operation, "divide") -> is_divide
equal(operation, "modulus") -> is_modulus
equal(second, 0) -> second_is_zero
set(valid_operation, False)
action(valid)
    set(valid_operation, True)
end()
action(invalid)
    say("Error: Unknown operation.")
end()
action(addition)
    add(first, second) -> result
    say("Answer:")
    say(result)
end()
action(subtraction)
    subtract(first, second) -> result
    say("Answer:")
    say(result)
end()
action(multiplication)
    multiply(first, second) -> result
    say("Answer:")
    say(result)
end()
action(division_error)
    say("Error: Cannot divide by zero.")
end()
action(division)
    divide(first, second) -> result
    say("Answer:")
    say(result)
end()
action(division_check)
    if(second_is_zero)=t, do(division_error)
    if(second_is_zero)=f, do(division)
end()
action(modulus)
    mod(first, second) -> result
    say("Answer:")
    say(result)
end()
if(is_add)=t, do(valid)
if(is_subtract)=t, do(valid)
if(is_multiply)=t, do(valid)
if(is_divide)=t, do(valid)
if(is_modulus)=t, do(valid)
if(is_add)=t, do(addition)
if(is_subtract)=t, do(subtraction)
if(is_multiply)=t, do(multiplication)
if(is_divide)=t, do(division_check)
if(is_modulus)=t, do(modulus)
if(valid_operation)=f, do(invalid)'''
        generated = translate(source, "python")
        compile(generated, "calculator.py", "exec")
        scenarios = (
            (["5", "12", "modulus"], "Answer:\n5", "Error:"),
            (["5", "0", "divide"], "Error: Cannot divide by zero.", "Answer:"),
            (["5", "12", "unknown"], "Error: Unknown operation.", "Answer:"),
        )
        for answers, expected, unexpected in scenarios:
            with self.subTest(answers=answers):
                inputs = iter(answers)
                output = io.StringIO()
                namespace = {"input": lambda prompt="": next(inputs)}
                with redirect_stdout(output):
                    exec(compile(generated, "calculator.py", "exec"), namespace)
                self.assertIn(expected, output.getvalue())
                self.assertNotIn(unexpected, output.getvalue())


    def test_translate_directive_translates_before_running_program(self):
        engine = ModkecEngine(input_fn=lambda prompt: (_ for _ in ()).throw(AssertionError("input should not run")))
        result = engine.run('''ask("This must not prompt") -> value
say(value)
translate(python)''')
        self.assertIn("value = input(", result)
        self.assertIn("print(value)", result)
        self.assertNotIn("This must not prompt ", "\n".join(engine.output))

    def test_python_export_writes_valid_source(self):
        source = 'say("Hello")\nset(score, 12)\nsay(score)'
        with tempfile.TemporaryDirectory() as temp_dir:
            destination = Path(temp_dir) / "program.py"
            result = export(source, "python", destination)
            self.assertEqual(result, destination)
            generated = destination.read_text(encoding="utf-8")
            self.assertIn("print('Hello')", generated)
            compile(generated, str(destination), "exec")

if __name__ == '__main__':
    unittest.main()
