from modkec.extensions import NATIVE_LANGUAGES, TARGETS, contrast_text_color


def test_contrast_text_changes_for_light_and_dark_colors():
    assert contrast_text_color("#ffffff") == "#171717"
    assert contrast_text_color("#ffff00") == "#171717"
    assert contrast_text_color("#000000") == "#f5f5f5"
    assert contrast_text_color("#18304a") == "#f5f5f5"


def test_native_language_catalog_contains_major_languages():
    labels = {entry["label"] for entry in NATIVE_LANGUAGES.values()}
    assert {"Python", "JavaScript", "TypeScript", "Java", "C", "C++", "C#", "Rust", "Go", "Lua", "HTML", "SQL (SQLite)"}.issubset(labels)
    assert all(entry["suffix"].startswith(".") for entry in NATIVE_LANGUAGES.values())


def test_translation_pack_catalog_remains_separate_from_native_runners():
    assert set(TARGETS) == {"python", "javascript", "lua", "luau", "c", "html"}
    assert "rust" in NATIVE_LANGUAGES
    assert "rust" not in TARGETS


def test_local_extension_zip_registers_a_command_on_import(tmp_path, monkeypatch):
    import json
    import zipfile
    import modkec.plugins as plugins
    from modkec.engine import ModkecEngine

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    package = tmp_path / "sample-extension.zip"
    manifest = {
        "id": "sample-math",
        "name": "Sample Math",
        "version": "1.0.0",
        "api_version": 1,
        "entrypoint": "main.py",
        "commands": ["double"],
    }
    source = '''def double(context, args):\n    if len(args) != 1:\n        raise ValueError("double() needs one argument")\n    return args[0] * 2\n\ndef register(api):\n    api.register_command("double", double, "Double a value")\n'''
    with zipfile.ZipFile(package, "w") as archive:
        archive.writestr("modkec-extension.json", json.dumps(manifest))
        archive.writestr("main.py", source)

    installed = plugins.install_extension_archive(package)
    assert installed["id"] == "sample-math"
    program = ModkecEngine().run("import(sample-math)\ndouble(21) -> answer\nsay(answer)")
    assert program == "42"


def test_extension_archive_rejects_path_traversal(tmp_path, monkeypatch):
    import json
    import zipfile
    import modkec.plugins as plugins
    import pytest

    monkeypatch.setattr(plugins, "extension_directory", lambda: tmp_path / "extensions")
    package = tmp_path / "unsafe.zip"
    with zipfile.ZipFile(package, "w") as archive:
        archive.writestr("../escape.py", "print('no')")
        archive.writestr("modkec-extension.json", json.dumps({"id": "unsafe", "api_version": 1, "entrypoint": "main.py", "commands": ["x"]}))
        archive.writestr("main.py", "def register(api):\n    api.register_command('x', lambda ctx, args: None)\n")
    with pytest.raises(ValueError, match="Unsafe ZIP path"):
        plugins.install_extension_archive(package)
