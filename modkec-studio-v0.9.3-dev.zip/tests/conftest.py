"""Keep test-import bytecode below the pytest cache directory."""
from pathlib import Path
import shutil
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.pycache_prefix = str(PROJECT_ROOT / ".pytest_cache" / "pycache")
# Python compiles conftest.py before executing this file, so remove that one
# already-created cache directory after redirecting all subsequent bytecode.
shutil.rmtree(Path(__file__).resolve().parent / "__pycache__", ignore_errors=True)
