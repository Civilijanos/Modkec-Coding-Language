@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
    echo Usage: run_modkec.bat path\to\program.modkec
    echo Example: run_modkec.bat examples\first_program.modkec
    pause
    exit /b 2
)
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 run_modkec.py "%~1"
    goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
    python run_modkec.py "%~1"
    goto :end
)
echo Python 3 was not found. Install it from https://www.python.org/downloads/windows/
pause
exit /b 1
:end
if not "%errorlevel%"=="0" pause
endlocal
