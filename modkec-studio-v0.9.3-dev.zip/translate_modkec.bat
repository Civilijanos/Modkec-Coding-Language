@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 translate_modkec.py %*
    goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
    python translate_modkec.py %*
    goto :end
)
echo Python 3 was not found. Install it from https://www.python.org/downloads/windows/
pause
exit /b 1
:end
if not "%errorlevel%"=="0" pause
endlocal
