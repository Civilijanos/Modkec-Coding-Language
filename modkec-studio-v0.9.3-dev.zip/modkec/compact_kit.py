"""Reusable, editable Modkec Compact Kit source templates."""
from __future__ import annotations

TEMPLATES: dict[str, tuple[str, str]] = {
    "calculator(basic)": (
        "Basic calculator",
        '''# Compact Kit: basic calculator
import(calculator)
ask("First number:") -> first
ask("Second number:") -> second
add(first, second) -> answer
say(answer)
''',
    ),
    "game(score)": (
        "Score counter for a game",
        '''# Compact Kit: game score
import(actions)
set(score, 0)
command(add_point)
    increment(score)
    say(score)
end()

# Call add_point() whenever the player earns a point.
''',
    ),
    "game(health)": (
        "Player health and damage",
        '''# Compact Kit: health system
import(actions)
set(health, 100)
command(take_damage, amount)
    set(health, health - amount)
    if(health < 1)=t, do(player_defeated)
    say(health)
end()

action(player_defeated)
    say("Player defeated")
end()

# Example: take_damage(25)
''',
    ),
    "utility(random)": (
        "Random number generator",
        '''# Compact Kit: random number
import(calculator)
random(1, 100) -> result
say(result)
''',
    ),
}


def get_templates() -> dict[str, tuple[str, str]]:
    """Return a copy of the available template catalogue."""
    return dict(TEMPLATES)
