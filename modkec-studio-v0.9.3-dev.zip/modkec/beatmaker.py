"""Dependency-free step sequencer and WAV synthesizer for Modkec Studio."""
from __future__ import annotations

import math
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import wave
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

SAMPLE_RATE = 22050
TRACKS = {
    "Kick": ("kick", 36),
    "Snare": ("snare", 38),
    "Hi-hat": ("hat", 42),
    "Bass": ("bass", 40),
}


def _voice(kind: str, frequency: int, duration: float, start: float) -> float:
    t = start
    if t < 0 or t >= duration:
        return 0.0
    fade = max(0.0, 1.0 - t / duration)
    if kind == "kick":
        freq = 120 * math.exp(-t * 22) + 38
        return math.sin(2 * math.pi * freq * t) * fade * 0.9
    if kind == "snare":
        noise = math.sin(t * 12713.7) * math.sin(t * 7131.9)
        tone = math.sin(2 * math.pi * 180 * t) * 0.25
        return (noise * 0.7 + tone) * fade * 0.55
    if kind == "hat":
        noise = math.sin(t * 18371.3) * math.sin(t * 8911.1) * math.sin(t * 317.3)
        return noise * fade * 0.24
    return math.sin(2 * math.pi * frequency * t) * fade * 0.42


def render_wav(pattern: dict[str, list[bool]], bpm: int, destination: str | Path, bars: int = 4) -> Path:
    bpm = max(40, min(240, int(bpm)))
    step_duration = 60.0 / bpm / 4.0
    total_samples = int(SAMPLE_RATE * step_duration * 16 * bars)
    samples = [0.0] * total_samples
    for bar in range(bars):
        for track_name, (kind, midi) in TRACKS.items():
            steps = pattern.get(track_name, [False] * 16)
            frequency = 440.0 * (2 ** ((midi - 69) / 12))
            duration = 0.32 if kind == "kick" else 0.22 if kind == "snare" else 0.10 if kind == "hat" else 0.18
            for step, enabled in enumerate(steps[:16]):
                if not enabled:
                    continue
                begin = int((bar * 16 + step) * step_duration * SAMPLE_RATE)
                voice_samples = min(int(duration * SAMPLE_RATE), total_samples - begin)
                for offset in range(voice_samples):
                    samples[begin + offset] += _voice(kind, int(frequency), duration, offset / SAMPLE_RATE)
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as out:
        out.setnchannels(1)
        out.setsampwidth(2)
        out.setframerate(SAMPLE_RATE)
        pcm = bytearray()
        for sample in samples:
            value = int(max(-1.0, min(1.0, sample * 0.72)) * 32767)
            pcm.extend(struct.pack("<h", value))
        out.writeframes(pcm)
    return path


class BeatMaker:
    """Compact dark step sequencer with large, readable step pads."""
    def __init__(self, parent: tk.Misc):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("Modkec Beatmaker")
        self.window.geometry("940x430")
        self.window.minsize(800, 380)
        self.window.configure(background="#17191f")
        self.bpm = tk.IntVar(value=110)
        self.steps: dict[str, list[tk.BooleanVar]] = {
            track: [tk.BooleanVar(value=(step in default)) for step in range(16)]
            for track, default in (("Kick", (0, 8)), ("Snare", (4, 12)), ("Hi-hat", (2, 6, 10, 14)), ("Bass", (0, 6, 8, 14)))
        }
        self.step_buttons: dict[tuple[str, int], tk.Button] = {}
        shell = tk.Frame(self.window, background="#17191f", padx=18, pady=16)
        shell.pack(fill="both", expand=True)
        head = tk.Frame(shell, background="#17191f")
        head.pack(fill="x", pady=(0, 16))
        tk.Label(head, text="BEATMAKER", bg="#17191f", fg="#f2f4f8", font=("TkDefaultFont", 16, "bold")).pack(side="left")
        tk.Label(head, text="16-STEP SEQUENCER", bg="#17191f", fg="#9ca6b8", font=("TkDefaultFont", 9, "bold")).pack(side="left", padx=14, pady=(5, 0))
        bpm_box = tk.Frame(head, background="#252a35", padx=10, pady=6)
        bpm_box.pack(side="right")
        tk.Label(bpm_box, text="TEMPO", bg="#252a35", fg="#aeb8ca", font=("TkDefaultFont", 8, "bold")).pack(side="left", padx=(0, 8))
        tk.Spinbox(bpm_box, from_=40, to=240, width=5, textvariable=self.bpm, bg="#343b4a", fg="#ffffff", buttonbackground="#343b4a", insertbackground="#ffffff", relief="flat", font=("TkDefaultFont", 11)).pack(side="left")

        board = tk.Frame(shell, bg="#222631", padx=12, pady=12)
        board.pack(fill="both", expand=True)
        tk.Label(board, text="TRACK", bg="#222631", fg="#8792a7", font=("TkDefaultFont", 8, "bold"), width=9, anchor="w").grid(row=0, column=0, sticky="w", padx=(0, 8), pady=(0, 8))
        for col in range(16):
            group_color = "#e6b85c" if col % 4 == 0 else "#a3acbe"
            tk.Label(board, text=f"{col + 1:02}", bg="#222631", fg=group_color, font=("TkDefaultFont", 8, "bold"), width=3).grid(row=0, column=col + 1, padx=2, pady=(0, 8))
        self.track_colors = {"Kick": "#e6b85c", "Snare": "#e47783", "Hi-hat": "#6dc9b0", "Bass": "#8f9cff"}
        for row, track in enumerate(TRACKS, start=1):
            tk.Label(board, text=track.upper(), bg="#222631", fg=self.track_colors[track], font=("TkDefaultFont", 9, "bold"), width=9, anchor="w").grid(row=row, column=0, sticky="w", padx=(0, 8), pady=5)
            for col, var in enumerate(self.steps[track]):
                button = tk.Button(board, text="", width=2, height=1, relief="flat", bd=0, cursor="hand2", command=lambda t=track, i=col: self.toggle_step(t, i))
                button.grid(row=row, column=col + 1, sticky="ew", padx=2, pady=5, ipady=4)
                self.step_buttons[(track, col)] = button
            board.rowconfigure(row, weight=1)
        for col in range(1, 17):
            board.columnconfigure(col, weight=1, uniform="step")
        self.refresh_step_buttons()

        controls = tk.Frame(shell, background="#17191f")
        controls.pack(fill="x", pady=(14, 0))
        self._control_button(controls, "Clear pattern", self.clear, "#343b4a").pack(side="left")
        self._control_button(controls, "Export WAV", self.export, "#66522a").pack(side="left", padx=8)
        self._control_button(controls, "Preview audio", self.play, "#275d51").pack(side="left")
        self.status = tk.StringVar(value="Click step pads to build a rhythm")
        tk.Label(controls, textvariable=self.status, bg="#17191f", fg="#aeb8ca", font=("TkDefaultFont", 9)).pack(side="right", padx=4)

    @staticmethod
    def _control_button(parent, text, command, color):
        return tk.Button(parent, text=text, command=command, bg=color, fg="#ffffff", activebackground=color, activeforeground="#ffffff", relief="flat", bd=0, padx=14, pady=8, cursor="hand2", font=("TkDefaultFont", 9, "bold"))

    def toggle_step(self, track: str, step: int) -> None:
        self.steps[track][step].set(not self.steps[track][step].get())
        self.refresh_step_buttons()

    def refresh_step_buttons(self) -> None:
        for (track, step), button in self.step_buttons.items():
            active = self.steps[track][step].get()
            color = self.track_colors[track] if active else ("#343a47" if step % 4 else "#414858")
            button.configure(background=color, activebackground=color, text="●" if active else "")

    def pattern(self) -> dict[str, list[bool]]:
        return {track: [v.get() for v in values] for track, values in self.steps.items()}

    def clear(self) -> None:
        for values in self.steps.values():
            for var in values:
                var.set(False)
        self.refresh_step_buttons()
        self.status.set("Pattern cleared")

    def export(self) -> None:
        name = filedialog.asksaveasfilename(parent=self.window, title="Export beat", defaultextension=".wav", filetypes=(("WAV audio", "*.wav"),))
        if not name:
            return
        try:
            render_wav(self.pattern(), self.bpm.get(), name)
            self.status.set(f"Exported {Path(name).name}")
        except (OSError, ValueError, tk.TclError) as exc:
            messagebox.showerror("Export failed", str(exc), parent=self.window)

    def play(self) -> None:
        try:
            temp = Path(tempfile.gettempdir()) / "modkec-beatmaker-preview.wav"
            render_wav(self.pattern(), self.bpm.get(), temp)
        except (OSError, ValueError, tk.TclError) as exc:
            messagebox.showerror("Preview failed", str(exc), parent=self.window)
            return
        def playback() -> None:
            try:
                if sys.platform == "win32":
                    import winsound
                    winsound.PlaySound(str(temp), winsound.SND_FILENAME | winsound.SND_SYNC)
                else:
                    player = next((shutil.which(cmd) for cmd in (("afplay",) if sys.platform == "darwin" else ("paplay", "aplay", "ffplay")) if shutil.which(cmd)), None)
                    if not player:
                        self.window.after(0, lambda: self.status.set("No supported audio player found; use Export WAV"))
                        return
                    args = [player, str(temp)] if Path(player).name != "ffplay" else [player, "-nodisp", "-autoexit", "-loglevel", "error", str(temp)]
                    subprocess.run(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
                self.window.after(0, lambda: self.status.set("Preview finished"))
            except Exception as exc:
                self.window.after(0, lambda message=str(exc): self.status.set(f"Playback failed: {message}"))
        self.status.set("Playing preview…")
        threading.Thread(target=playback, daemon=True).start()
