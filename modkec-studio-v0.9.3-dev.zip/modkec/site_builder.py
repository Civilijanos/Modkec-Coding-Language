"""Renderer for native Modkec site-builder commands.

Modkec source describes semantic page components. This module emits browser markup,
styles, and small interactions so a site author does not write HTML/CSS/JavaScript.
"""
from __future__ import annotations
import html
from pathlib import Path


def esc(value):
    return html.escape(str(value if value is not None else ""), quote=True)

CSS = r'''
:root{color-scheme:dark;--bg:#0d0c14;--panel:#151421;--panel2:#1c1a2b;--line:#302d43;--text:#f5f3ff;--muted:#aaa6c1;--purple:#a78bfa;--purple2:#7c3aed;--cyan:#6ee7f9;--green:#86efac;--radius:18px;--max:1160px}*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:88px}body{margin:0;background:radial-gradient(ellipse at 75% -15%,#31245a 0,transparent 38%),var(--bg);font:16px/1.6 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--text)}a{color:inherit;text-decoration:none}button,input,select{font:inherit}.wrap{width:min(var(--max),calc(100% - 40px));margin:auto}.topbar{position:sticky;top:0;z-index:20;background:#0d0c14e8;backdrop-filter:blur(18px);border-bottom:1px solid #ffffff10}.nav{min-height:72px;display:flex;align-items:center;gap:26px}.brand{display:flex;align-items:center;gap:11px;font-weight:800;letter-spacing:-.04em;font-size:1.2rem;margin-right:auto}.brand-mark{display:grid;place-items:center;width:36px;height:36px;border-radius:12px;background:linear-gradient(135deg,#c4b5fd,#7c3aed);color:#110c20;font-weight:900}.navlinks{display:flex;gap:24px;color:var(--muted);font-size:.92rem;flex-wrap:wrap}.navlinks a:hover{color:var(--text)}.nav-cta,.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid var(--line);border-radius:11px;padding:10px 15px;font-weight:700;font-size:.9rem;cursor:pointer}.nav-cta,.btn.primary{background:var(--purple);color:#171026;border-color:transparent}.btn.secondary{background:#ffffff05;color:var(--text)}.hero{padding:82px 0 62px}.hero-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:48px;align-items:center}.eyebrow,.kicker{color:var(--cyan);text-transform:uppercase;letter-spacing:.13em;font-size:.76rem;font-weight:800}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--green);margin-right:8px}.hero h1{font-size:clamp(2.5rem,6vw,4.7rem);line-height:1.02;letter-spacing:-.055em;margin:18px 0}.gradient{background:linear-gradient(100deg,#c4b5fd,#6ee7f9);color:transparent;background-clip:text}.hero p,.section-head>p{color:var(--muted);max-width:650px}.actions{display:flex;gap:12px;flex-wrap:wrap;margin:26px 0}.hero-note,.fineprint{font-size:.82rem;color:var(--muted)}.terminal,.card,.callout,.faq{background:linear-gradient(145deg,var(--panel),#12111c);border:1px solid var(--line);border-radius:var(--radius)}.terminal{overflow:hidden;box-shadow:0 28px 90px #0005}.terminal-head{display:flex;gap:7px;align-items:center;padding:14px 17px;border-bottom:1px solid var(--line)}.orb{width:9px;height:9px;border-radius:50%;background:#777}.terminal-title{margin-left:10px;color:var(--muted);font-size:.8rem}.terminal pre,.code{white-space:pre-wrap;overflow-wrap:anywhere;font: .9rem/1.8 ui-monospace,SFMono-Regular,Consolas,monospace}.terminal pre{padding:18px;margin:0}.comment{color:#77748f}.prompt{color:var(--cyan)}.string{color:var(--green)}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:42px}.stat{padding:16px;border:1px solid var(--line);border-radius:14px;background:#ffffff03}.stat strong,.stat span{display:block}.stat span{font-size:.82rem;color:var(--muted);margin-top:3px}section{padding:64px 0}.soft-section{background:#ffffff03;border-block:1px solid #ffffff08}.section-head{display:flex;justify-content:space-between;gap:30px;align-items:end;margin-bottom:26px}.section-head h2{font-size:clamp(1.8rem,4vw,2.65rem);letter-spacing:-.04em;line-height:1.12;margin:8px 0}.section-head>p{max-width:470px;margin:0}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.card{padding:22px;min-width:0}.card-icon{font-size:1.5rem;color:var(--purple)}.card h3{margin:8px 0}.card p{color:var(--muted)}.card-link{color:var(--cyan);font-weight:700}.toolbar{display:flex;gap:12px;margin:20px 0;flex-wrap:wrap}.search{flex:1;min-width:220px}.search input,.filter{width:100%;background:var(--panel);color:var(--text);border:1px solid var(--line);border-radius:11px;padding:12px 14px}.filter{width:auto;min-width:170px}.version-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.version-top{display:flex;justify-content:space-between;gap:12px;align-items:start}.version{font-size:1.7rem;font-weight:850;letter-spacing:-.04em}.badge{font-size:.72rem;background:#a78bfa20;color:#d8ccff;border:1px solid #a78bfa50;padding:4px 8px;border-radius:999px;white-space:nowrap}.badge.green{color:var(--green);background:#86efac12;border-color:#86efac40}.platforms{display:flex;gap:8px;flex-wrap:wrap;margin:16px 0}.platforms span{font-size:.78rem;border:1px solid var(--line);border-radius:8px;padding:4px 8px;color:var(--muted)}.empty{grid-column:1/-1;padding:28px;border:1px dashed #504969;border-radius:14px;color:var(--muted)}.empty strong{display:block;color:var(--text);margin-bottom:5px}.warning{padding:16px 18px;border:1px solid #fbbf2440;background:#fbbf240a;border-radius:12px;color:#e8d5a4}.split{display:grid;grid-template-columns:.8fr 1.2fr;gap:28px}.callout{padding:24px}.code{background:#0a0910;border:1px solid var(--line);border-radius:10px;padding:12px;margin:10px 0}.steps{display:grid;gap:18px}.step{display:grid;grid-template-columns:34px 1fr;gap:14px}.step-num{width:32px;height:32px;display:grid;place-items:center;border:1px solid #a78bfa60;color:var(--purple);border-radius:10px;font-weight:800}.step h3{margin:0}.step p{color:var(--muted);margin:4px 0}.docs-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.command{display:grid;grid-template-columns:minmax(130px,.65fr) 1fr;gap:14px;padding:12px 0;border-bottom:1px solid #ffffff0d}.command:last-child{border-bottom:0}.command code{color:var(--cyan);overflow-wrap:anywhere}.command span{color:var(--muted);font-size:.9rem}.faq{padding:4px 20px}.faq details{border-bottom:1px solid var(--line);padding:15px 0}.faq details:last-child{border:0}.faq summary{font-weight:750;cursor:pointer}.faq p{color:var(--muted)}.footer{padding:28px 0;color:var(--muted);font-size:.85rem}.footer-row{display:flex;justify-content:space-between;gap:24px;flex-wrap:wrap;border-top:1px solid var(--line);padding-top:24px}.footer-links{display:flex;gap:18px;flex-wrap:wrap}.footer strong{color:var(--text)}@media(max-width:800px){.hero-grid,.split{grid-template-columns:1fr}.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.section-head{display:block}.section-head>p{margin-top:12px}.nav{padding:12px 0;align-items:flex-start;flex-wrap:wrap}.navlinks{order:3;width:100%;gap:15px}.nav-cta{display:none}}@media(max-width:560px){.wrap{width:calc(100% - 28px)}.hero{padding:56px 0 38px}.grid,.version-grid,.docs-grid,.stats{grid-template-columns:1fr}.command{grid-template-columns:1fr;gap:4px}.navlinks{font-size:.82rem}section{padding:46px 0}}
'''

JS = r'''
(() => {
 const inputs = document.querySelectorAll('[data-site-search]');
 inputs.forEach(input => input.addEventListener('input', () => {
   const target = document.getElementById(input.dataset.siteSearch);
   if (!target) return;
   const q = input.value.toLowerCase().trim();
   target.querySelectorAll('[data-searchable]').forEach(item => {
     item.hidden = q.length > 0 && !item.textContent.toLowerCase().includes(q);
   });
   const empty = target.querySelector('[data-empty-result]');
   if (empty) empty.hidden = [...target.querySelectorAll('[data-searchable]')].some(item => !item.hidden);
 }));
})();
'''

class SiteBuilder:
    def __init__(self):
        self.title = "Modkec Community Hub"
        self.tagline = "An independent community hub for Modkec."
        self.nav = []
        self.elements = []
        self.current_section = None
        self.footer = None
        self.theme = {'primary': '#a78bfa', 'background': '#0d0c14'}
        self.custom_css = []

    def add(self, kind, *values):
        item = {"kind": kind, "values": list(values)}
        if kind == "section":
            self.elements.append(item)
            self.current_section = item
        elif kind == "footer":
            self.footer = item
        else:
            self.elements.append(item)
        return item

    def render(self):
        title = esc(self.title)
        nav = ''.join(f'<a href="{esc(target)}">{esc(label)}</a>' for label, target in self.nav)
        body = []
        section_open = False
        searchable = {"card", "download", "depot", "command", "faq", "step"}
        for item in self.elements:
            kind, v = item["kind"], item["values"]
            if kind == "section":
                if section_open: body.append('</div></div></section>')
                sid, kicker, heading, description, variant = (v + [""] * 5)[:5]
                cls = ' class="soft-section"' if variant == 'soft' else ''
                body.append(f'<section id="{esc(sid)}"{cls}><div class="wrap"><div class="section-head"><div><div class="kicker">{esc(kicker)}</div><h2>{esc(heading)}</h2></div><p>{esc(description)}</p></div><div class="section-content">')
                section_open = True
            elif kind == "hero":
                heading, description, primary, ptarget, secondary, starget = (v + [""] * 6)[:6]
                body.append(f'<section class="hero" id="home"><div class="wrap"><div class="hero-grid"><div><div class="eyebrow"><span class="dot"></span>The Modkec ecosystem</div><h1>{esc(heading)} <span class="gradient">Modkec.</span></h1><p>{esc(description)}</p><div class="actions"><a class="btn primary" href="{esc(ptarget)}">{esc(primary)} →</a><a class="btn secondary" href="{esc(starget)}">{esc(secondary)} ↗</a></div><div class="hero-note">{esc(self.tagline)}</div></div><div class="terminal"><div class="terminal-head"><span class="orb"></span><span class="orb"></span><span class="orb"></span><span class="terminal-title">hello_world.modkec</span></div><pre><span class="comment"># Your first Modkec program</span>\n<span class="prompt">say</span>(<span class="string">"Hello, world!"</span>)\n\n<span class="prompt">set</span>(project, <span class="string">"something new"</span>)\n<span class="prompt">say</span>(project)\n\n<span class="comment"># Small steps. Real projects.</span></pre></div></div>')
            elif kind == "stat":
                heading, description = (v + [""] * 2)[:2]
                body.append(f'<div class="stat"><strong>{esc(heading)}</strong><span>{esc(description)}</span></div>')
            elif kind == "text":
                content = str(v[0]) if v else ""
                tag = str(v[1]).lower() if len(v) > 1 else "p"
                if tag not in {"p", "h1", "h2", "h3", "blockquote"}: tag = "p"
                body.append(f'<{tag} class="site-text">{esc(content)}</{tag}>')
            elif kind == "button":
                label, target, style = (v + ["", "", "primary"])[:3]
                cls = "primary" if str(style).lower() not in {"secondary", "text"} else str(style).lower()
                body.append(f'<p class="site-button-row"><a class="btn {cls}" href="{esc(target)}">{esc(label)} →</a></p>')
            elif kind == "link":
                label, target = (v + ["", ""])[:2]
                body.append(f'<p><a class="site-link" href="{esc(target)}">{esc(label)} ↗</a></p>')
            elif kind == "image":
                src, alt, width = (v + ["", "", "100%"])[:3]
                width_text = str(width).strip()
                if not (width_text.endswith("%") or width_text.endswith("px")):
                    width_text = "100%"
                body.append(f'<figure class="site-image"><img src="{esc(src)}" alt="{esc(alt)}" loading="lazy" style="width:{esc(width_text)};max-width:100%"><figcaption>{esc(alt)}</figcaption></figure>')
            elif kind == "card":
                heading, description, label, target = (v + [""] * 4)[:4]
                body.append(f'<article class="card" data-searchable><div class="card-icon">◇</div><h3>{esc(heading)}</h3><p>{esc(description)}</p><a class="card-link" href="{esc(target)}">{esc(label)} →</a></article>')
            elif kind == "search":
                target, placeholder = (v + [""] * 2)[:2]
                body.append(f'<div class="toolbar"><label class="search"><input type="search" data-site-search="{esc(target)}" placeholder="{esc(placeholder)}" aria-label="{esc(placeholder)}"></label></div>')
            elif kind == "list_start":
                target = str(v[0]) if v else "site-list"
                layout = str(v[1]) if len(v) > 1 else "grid"
                css_class = "version-grid" if layout == "versions" else "docs-grid" if layout == "docs" else "steps" if layout == "steps" else "faq" if layout == "faq" else "grid"
                body.append(f'<div class="{css_class}" id="{esc(target)}">')
            elif kind == "list_end":
                body.append('</div>')
            elif kind == "download":
                version, name, channel, description, platforms, url, status = (v + [""] * 7)[:7]
                ps = [p.strip() for p in str(platforms).split(',') if p.strip()]
                pub = 'published' in (str(status) + ' ' + str(channel)).lower() or 'github' in str(status).lower()
                phtml = ''.join(f'<span>{esc(p)}</span>' for p in ps)
                label = 'Open release ↗' if str(url).startswith('http') else f'Download v{esc(version)} ↓'
                target = ' target="_blank" rel="noopener"' if str(url).startswith('http') else ' download'
                body.append(f'<article class="version-card card" data-searchable><div class="version-top"><div><div class="version">v{esc(version)}</div><h3>{esc(name)}</h3></div><span class="badge {"green" if pub else ""}">{esc(status or channel)}</span></div><p>{esc(description)}</p><div class="platforms">{phtml}</div><a class="btn {"secondary" if pub else "primary"}" href="{esc(url)}"{target}>{label}</a></article>')
            elif kind == "depot":
                name, category, version, maintainer, description, url = (v + [""] * 6)[:6]
                body.append(f'<article class="card" data-searchable><div class="version-top"><h3>{esc(name)}</h3><span class="badge">{esc(category)}</span></div><p>{esc(description)}</p><p class="fineprint">Version {esc(version)} · By {esc(maintainer)}</p><a class="btn secondary" href="{esc(url)}" target="_blank" rel="noopener">Open project ↗</a></article>')
            elif kind == "empty":
                heading, description = (v + [""] * 2)[:2]
                body.append(f'<div class="empty" data-empty-result><strong>{esc(heading)}</strong>{esc(description)}</div>')
            elif kind == "warning":
                body.append(f'<p class="warning">{esc(v[0] if v else "")}</p>')
            elif kind == "step":
                number, heading, description, code = (v + [""] * 4)[:4]
                body.append(f'<div class="step" data-searchable><div class="step-num">{esc(number)}</div><div><h3>{esc(heading)}</h3><p>{esc(description)}</p><div class="code">{esc(code)}</div></div></div>')
            elif kind == "command":
                group, command, description = (v + [""] * 3)[:3]
                body.append(f'<div class="command" data-searchable data-group="{esc(group)}"><code>{esc(command)}</code><span>{esc(description)}</span></div>')
            elif kind == "faq":
                question, answer = (v + [""] * 2)[:2]
                body.append(f'<details data-searchable><summary>{esc(question)}</summary><p>{esc(answer)}</p></details>')
            elif kind == "code":
                heading, code = (v + [""] * 2)[:2]
                body.append(f'<div class="callout"><h3>{esc(heading)}</h3><div class="code">{esc(code)}</div></div>')
        if section_open: body.append('</div></div></section>')
        stats = ''.join(f'<div class="stat"><strong>{esc(i["values"][0])}</strong><span>{esc(i["values"][1])}</span></div>' for i in self.elements if i['kind'] == 'stat')
        # Stats are placed immediately after the hero, regardless of declaration order.
        body = [x for x in body if not (x.startswith('<div class="stat">'))]
        for i, x in enumerate(body):
            if x.startswith('<section class="hero"'):
                body[i] = x + (f'<div class="stats">{stats}</div></div></section>' if stats else '</div></section>')
                break
        footer = self.footer["values"] if self.footer else ["Community hub prototype · Not an official security certification service.", "https://github.com/Civilijanos/Modkec-Coding-Language"]
        note, repo = (footer + [""] * 2)[:2]
        # Keep theme values constrained to hex colors so they cannot inject markup.
        import re
        primary = self.theme.get('primary', '#a78bfa')
        background = self.theme.get('background', '#0d0c14')
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', primary): primary = '#a78bfa'
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', background): background = '#0d0c14'
        theme_css = f':root{{--purple:{primary};--bg:{background}}}' + '.site-text{max-width:900px}.site-button-row{margin:18px 0}.site-link{color:var(--cyan);font-weight:700}.site-image{margin:24px 0}.site-image img{display:block;height:auto;border-radius:14px;border:1px solid var(--line)}.site-image figcaption{font-size:.8rem;color:var(--muted);margin-top:6px}'
        custom_css = '\n'.join(self.custom_css)
        return ('<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
                '<meta name="theme-color" content="' + esc(background) + '"><title>' + title + '</title><style>' + CSS + theme_css + custom_css + '</style></head><body>'
                '<header class="topbar"><div class="wrap nav"><a class="brand" href="#home"><span class="brand-mark">M</span><span>modkec<span style="color:var(--purple)">.</span></span></a><nav class="navlinks">' + nav + '</nav><a class="nav-cta" href="#downloads">Get Modkec ↗</a></div></header><main>'
                + ''.join(body) + '</main><footer class="footer"><div class="wrap footer-row"><div><strong>modkec.</strong><br>Modular Development Kit for Extensible Coding.<br><span class="fineprint">' + esc(note) + '</span></div><div class="footer-links"><a href="#downloads">Downloads</a><a href="#depots">Depots</a><a href="#docs">Documentation</a><a href="' + esc(repo) + '" target="_blank" rel="noopener">GitHub ↗</a></div></div></footer><script>' + JS + '</script></body></html>\n')


def build_site(site: SiteBuilder, path: str) -> str:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(site.render(), encoding="utf-8")
    return str(target.resolve())
