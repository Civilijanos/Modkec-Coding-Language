"""Small extension registry for optional Modkec translation/export targets.

The first version intentionally registers known target packs instead of executing
arbitrary downloaded Python. Community forks are discoverable in Studio, but are
not trusted or executed automatically.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil

TARGETS = {
    "python": {"label": "Python translation pack", "suffix": ".py"},
    "javascript": {"label": "JavaScript translation pack", "suffix": ".js"},
    "lua": {"label": "Lua translation pack", "suffix": ".lua"},
    "luau": {"label": "Luau translation pack", "suffix": ".luau"},
    "c": {"label": "C translation pack", "suffix": ".c"},
    "html": {"label": "HTML translation pack", "suffix": ".html"},
}

# Built-in native-file support is separate from Modkec translation targets.
# Runtime programs are never bundled by the Studio; status reflects the host system.
NATIVE_LANGUAGES = {
    "python": {"label": "Python", "suffix": ".py", "runtime": "python3 / python"},
    "javascript": {"label": "JavaScript", "suffix": ".js", "runtime": "node"},
    "typescript": {"label": "TypeScript", "suffix": ".ts", "runtime": "tsx"},
    "java": {"label": "Java", "suffix": ".java", "runtime": "java (JDK 11+)"},
    "c": {"label": "C", "suffix": ".c", "runtime": "gcc"},
    "cpp": {"label": "C++", "suffix": ".cpp", "runtime": "g++"},
    "csharp": {"label": "C#", "suffix": ".cs", "runtime": ".NET SDK"},
    "rust": {"label": "Rust", "suffix": ".rs", "runtime": "rustc"},
    "go": {"label": "Go", "suffix": ".go", "runtime": "go"},
    "lua": {"label": "Lua", "suffix": ".lua", "runtime": "lua"},
    "luau": {"label": "Luau", "suffix": ".luau", "runtime": "luau"},
    "ruby": {"label": "Ruby", "suffix": ".rb", "runtime": "ruby"},
    "php": {"label": "PHP", "suffix": ".php", "runtime": "php"},
    "perl": {"label": "Perl", "suffix": ".pl", "runtime": "perl"},
    "r": {"label": "R", "suffix": ".r", "runtime": "Rscript"},
    "julia": {"label": "Julia", "suffix": ".jl", "runtime": "julia"},
    "kotlin": {"label": "Kotlin", "suffix": ".kt", "runtime": "kotlinc + java"},
    "swift": {"label": "Swift", "suffix": ".swift", "runtime": "swift"},
    "dart": {"label": "Dart", "suffix": ".dart", "runtime": "dart"},
    "scala": {"label": "Scala", "suffix": ".scala", "runtime": "scala"},
    "clojure": {"label": "Clojure", "suffix": ".clj", "runtime": "clojure"},
    "haskell": {"label": "Haskell", "suffix": ".hs", "runtime": "runghc"},
    "elixir": {"label": "Elixir", "suffix": ".exs", "runtime": "elixir"},
    "bash": {"label": "Bash / Shell", "suffix": ".sh", "runtime": "bash"},
    "powershell": {"label": "PowerShell", "suffix": ".ps1", "runtime": "pwsh"},
    "html": {"label": "HTML", "suffix": ".html", "runtime": "default browser"},
    "css": {"label": "CSS", "suffix": ".css", "runtime": "default browser / editor"},
    "sql": {"label": "SQL (SQLite)", "suffix": ".sql", "runtime": "sqlite3"},
    "fortran": {"label": "Fortran", "suffix": ".f90", "runtime": "gfortran"},
    "lisp": {"label": "Common Lisp", "suffix": ".lisp", "runtime": "sbcl"},
    "scheme": {"label": "Scheme", "suffix": ".scm", "runtime": "guile"},
    "visual-basic": {"label": "Visual Basic (.NET)", "suffix": ".vb", "runtime": ".NET SDK"},
    "fsharp": {"label": "F#", "suffix": ".fs", "runtime": ".NET SDK"},
    "objective-c": {"label": "Objective-C", "suffix": ".m", "runtime": "clang"},
    "groovy": {"label": "Groovy", "suffix": ".groovy", "runtime": "groovy"},
    "ocaml": {"label": "OCaml", "suffix": ".ml", "runtime": "ocaml"},
    "erlang": {"label": "Erlang", "suffix": ".erl", "runtime": "escript"},
    "octave": {"label": "Octave", "suffix": ".m", "runtime": "octave"},
    "zig": {"label": "Zig", "suffix": ".zig", "runtime": "zig"},
    "cobol": {"label": "COBOL", "suffix": ".cob", "runtime": "cobc"},
    "svg": {"label": "SVG", "suffix": ".svg", "runtime": "default browser"},
}


def contrast_text_color(background: str) -> str:
    """Choose near-black or near-white text for readable contrast."""
    try:
        value = background.lstrip("#")
        if len(value) != 6:
            raise ValueError("expected six hexadecimal digits")
        red, green, blue = (int(value[index:index + 2], 16) for index in (0, 2, 4))
    except (TypeError, ValueError):
        return "#f5f5f5"
    # Perceived brightness is adequate for UI contrast selection and avoids
    # keeping white text on a pale color or black text on a dark one.
    brightness = (299 * red + 587 * green + 114 * blue) / 1000
    return "#171717" if brightness >= 145 else "#f5f5f5"


def settings_path() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "modkec" / "extensions.json"


def extension_directory() -> Path:
    return settings_path().parent / "extensions"


def app_settings_path() -> Path:
    return settings_path().parent / "settings.json"


def _read_app_settings() -> dict:
    try:
        data = json.loads(app_settings_path().read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError, AttributeError):
        return {}


def _valid_color(value: object) -> bool:
    if not isinstance(value, str) or len(value) != 7 or not value.startswith("#"):
        return False
    try:
        int(value[1:], 16)
        return True
    except ValueError:
        return False


def custom_background() -> str | None:
    value = _read_app_settings().get("background")
    return value if _valid_color(value) else None


def custom_button_color() -> str | None:
    value = _read_app_settings().get("button_color")
    return value if _valid_color(value) else None


def _save_app_setting(key: str, value: str) -> None:
    path = app_settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = _read_app_settings()
    data[key] = value
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def save_custom_background(color: str) -> None:
    if not _valid_color(color):
        raise ValueError("Background color must be a hexadecimal color such as #202020")
    _save_app_setting("background", color)


def save_custom_button_color(color: str) -> None:
    if not _valid_color(color):
        raise ValueError("Button color must be a hexadecimal color such as #404040")
    _save_app_setting("button_color", color)


def installed_targets() -> set[str]:
    path = settings_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        targets = data.get("installed_targets", [])
        return {name for name in targets if name in TARGETS}
    except (OSError, ValueError, AttributeError):
        return set()


def save_installed_targets(targets: set[str]) -> None:
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"installed_targets": sorted(targets)}, indent=2), encoding="utf-8")


def install_target(target: str) -> None:
    """Install a target-pack manifest in the user's Modkec extension directory."""
    if target not in TARGETS:
        raise ValueError(f"Unknown translation target: {target}")
    root = extension_directory() / target
    root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "id": f"modkec.translate.{target}",
        "name": TARGETS[target]["label"],
        "version": "0.9.0-dev",
        "type": "translation-target",
        "target": target,
        "backend": "modkec.translator",
    }
    (root / "extension.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    targets = installed_targets()
    targets.add(target)
    save_installed_targets(targets)


def uninstall_target(target: str) -> None:
    """Remove a target-pack manifest without touching user projects."""
    if target not in TARGETS:
        raise ValueError(f"Unknown translation target: {target}")
    root = extension_directory() / target
    if root.exists():
        shutil.rmtree(root)
    targets = installed_targets()
    targets.discard(target)
    save_installed_targets(targets)
