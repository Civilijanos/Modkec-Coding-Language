"""Translate the supported Modkec starter syntax into Python, JavaScript, Lua, or Luau.

This is a deliberately explicit transpiler for the prototype language subset. It does
not evaluate Modkec code and it reports unsupported syntax instead of guessing.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Any

from .engine import ModkecError, _split_args

LANGUAGES = {"python", "javascript", "lua", "luau", "c", "html"}


def _parse_call(line: str) -> tuple[str, list[str]] | None:
    match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)\((.*)\)", line.strip())
    if not match:
        return None
    return match.group(1), _split_args(match.group(2).strip())


def _validate_name(name: str, line_number: int) -> str:
    name = name.strip()
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ModkecError(f"Line {line_number}: '{name}' is not a valid identifier.")
    return name


def _parse_value(raw: str, line_number: int) -> tuple[str, Any]:
    raw = raw.strip()
    if raw == "t":
        return "bool", True
    if raw == "f":
        return "bool", False
    try:
        value = ast.literal_eval(raw)
        if isinstance(value, (str, int, float, bool)) or value is None:
            return "literal", value
    except (ValueError, SyntaxError):
        pass
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", raw):
        return "name", raw
    if re.fullmatch(r"-?\d+(?:\.\d+)?", raw):
        return "literal", float(raw) if "." in raw else int(raw)
    if any(op in raw for op in ("+", "-", "*", "/", "%", ">", "<", "==")):
        return "expression", raw
    raise ModkecError(f"Line {line_number}: unsupported value '{raw}'.")


def _translate_value(raw: str, target: str, line_number: int) -> str:
    kind, value = _parse_value(raw, line_number)
    if kind == "name":
        return str(value)
    if kind == "expression":
        return _translate_expression(value, target, line_number)
    if kind == "bool":
        if target == "python": return "True" if value else "False"
        if target == "c": return "true" if value else "false"
        return "true" if value else "false"
    if value is None:
        return "None" if target == "python" else ("nil" if target in ("lua", "luau") else "NULL" if target == "c" else "null")
    if isinstance(value, str):
        return repr(value) if target == "python" else _js_string(value)
    return repr(value)


def _js_string(value: str) -> str:
    # JSON string syntax is valid JavaScript and avoids quote-escaping mistakes.
    import json
    return json.dumps(value, ensure_ascii=False)


def _translate_expression(expression: str, target: str, line_number: int) -> str:
    """Translate the simple expression subset accepted by the interpreter."""
    try:
        tree = ast.parse(expression.strip(), mode="eval")
    except SyntaxError as exc:
        raise ModkecError(f"Line {line_number}: couldn't parse expression '{expression}'.") from exc

    def visit(node: ast.AST) -> str:
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float, str, bool)):
            return _translate_value(repr(node.value), target, line_number)
        if isinstance(node, ast.Name):
            if node.id == "t": return "True" if target == "python" else "true"
            if node.id == "f": return "False" if target == "python" else "false"
            return node.id
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod)):
            op = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/", ast.FloorDiv: "//", ast.Mod: "%"}[type(node.op)]
            if type(node.op) is ast.FloorDiv and target in ("javascript", "c"):
                return f"floor(({visit(node.left)}) / ({visit(node.right)}))" if target == "c" else f"Math.floor(({visit(node.left)}) / ({visit(node.right)}))"
            return f"({visit(node.left)} {op} {visit(node.right)})"
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd, ast.Not)):
            op = {ast.USub: "-", ast.UAdd: "+", ast.Not: ("not " if target in ("python", "lua", "luau") else "!")}[type(node.op)]
            return f"({op}{visit(node.operand)})"
        if isinstance(node, ast.Compare) and len(node.ops) == 1:
            op_map = {ast.Eq: "==", ast.NotEq: "!=", ast.Gt: ">", ast.GtE: ">=", ast.Lt: "<", ast.LtE: "<="}
            if type(node.ops[0]) not in op_map:
                raise ModkecError(f"Line {line_number}: comparison is not supported.")
            return f"({visit(node.left)} {op_map[type(node.ops[0])]} {visit(node.comparators[0])})"
        if isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
            if target == "python" or target in ("lua", "luau"):
                op = "and" if isinstance(node.op, ast.And) else "or"
            else:
                op = "&&" if isinstance(node.op, ast.And) else "||"
            return "(" + f" {op} ".join(visit(v) for v in node.values) + ")"
        raise ModkecError(f"Line {line_number}: expression contains syntax the translator doesn't support yet.")

    return visit(tree)


def translate(source: str, target: str) -> str:
    """Translate Modkec source into one supported target language."""
    target = target.lower().strip()
    if target == "all":
        sections=[]
        for lang in sorted(LANGUAGES):
            try: result=translate(source, lang)
            except ModkecError as exc: result=f"[Translation unavailable for {lang}: {exc}]\n"
            sections.append(f"===== {lang.upper()} =====\n{result}")
        return "\n\n".join(sections)
    if target not in LANGUAGES:
        raise ModkecError(f"Unknown target '{target}'. Choose: {', '.join(sorted(LANGUAGES))}, or all.")
    if target in ("html", "javascript"):
        web_document = _parse_web_document(source)
        if web_document is not None:
            if target == "html":
                return _render_web_html(web_document)
            return _render_web_javascript(web_document)
    if target == "html":
        return _translate_html(source)

    lines = source.splitlines()
    output: list[str] = []
    declared: set[str] = set()
    action_names: set[str] = set()
    in_action: str | None = None
    in_python_block = False
    indent = 0
    c_main_lines: list[str] = []
    c_function_lines: list[str] = []
    c_globals: list[str] = []

    if target == "c":
        # Predeclare simple top-level variables so translated actions can share them.
        in_definition = False
        seen_globals: set[str] = set()
        for original in lines:
            stripped = original.strip()
            if re.fullmatch(r"(?:action|command)\(.*\)", stripped):
                in_definition = True
                continue
            if stripped == "end()":
                in_definition = False
                continue
            if in_definition:
                continue
            parsed = _parse_call(stripped)
            if not parsed or parsed[0] not in ("set", "store") or len(parsed[1]) != 2:
                continue
            name, raw_value = parsed[1]
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) or name in seen_globals:
                continue
            seen_globals.add(name)
            declared.add(name)
            try:
                kind, value = _parse_value(raw_value, 1)
            except ModkecError:
                kind, value = "expression", raw_value
            c_type = "const char *" if kind == "literal" and isinstance(value, str) else "bool" if kind == "bool" else "double"
            c_globals.append(f"{c_type} {name};")

    def emit(text: str) -> None:
        rendered = ("    " * indent) + text
        if target == "c":
            (c_function_lines if in_action is not None else c_main_lines).append(rendered)
        else:
            output.append(rendered)

    if target == "python":
        output.append("# Generated by Modkec. Review before production use.")
        output.append("import math, random")
    elif target == "javascript":
        output.append("// Generated by Modkec. Review before production use.")
    elif target == "c":
        output.extend(["/* Generated by Modkec. Review before production use. */", "#include <stdio.h>", "#include <stdbool.h>", "#include <math.h>", "#include <string.h>", "#include <stdlib.h>"])
    else:
        output.append("-- Generated by Modkec. Review before production use.")

    for line_number, original in enumerate(lines, start=1):
        line = original.strip()
        if in_python_block:
            if line == "end_python()":
                in_python_block = False
                continue
            if target != "python":
                raise ModkecError(f"Line {line_number}: native Python blocks can only be translated to Python, not {target}.")
            output.append(original.rstrip())
            continue
        if not line or line.startswith("#"):
            continue
        result_match = re.fullmatch(r"(.*?)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)", line)
        result_name = result_match.group(2) if result_match else None
        if result_match:
            line = result_match.group(1).strip()

        if in_action is not None:
            if line == "end()":
                if target == "python":
                    indent -= 1
                else:
                    indent -= 1
                    emit("end" if target in ("lua", "luau") else "}")
                in_action = None
                continue
            _translate_statement(line, line_number, target, emit, declared, action_names, result_name)
            continue

        action_match = re.fullmatch(r"(action|command)\((.*)\)", line)
        if action_match:
            definition_kind, raw_signature = action_match.groups()
            signature = _split_args(raw_signature)
            if not signature:
                raise ModkecError(f"Line {line_number}: {definition_kind}() needs a name and optional parameter names.")
            name = _validate_name(signature[0], line_number)
            params = [_validate_name(param, line_number) for param in signature[1:]]
            if len(set(params)) != len(params):
                raise ModkecError(f"Line {line_number}: duplicate parameter name in {definition_kind} '{name}'.")
            if name in action_names:
                raise ModkecError(f"Line {line_number}: action/command '{name}' is defined more than once.")
            action_names.add(name)
            args_text = ", ".join(params)
            if target == "c":
                params_text = ", ".join(f"double {param}" for param in params) or "void"
                in_action = name
                emit(f"void {name}({params_text}) {{")
                indent += 1
                continue
            if target == "python":
                emit(f"def {name}({args_text}):")
                indent += 1
                shared_names = sorted(declared - set(params))
                if shared_names:
                    emit("global " + ", ".join(shared_names))
            else:
                if target == "javascript": emit(f"function {name}({args_text}) {{")
                elif target == "c": emit(f"void {name}(void) {{")
                else: emit(f"function {name}({args_text})")
                indent += 1
            in_action = name
            continue

        if line == "python()":
            if in_action is not None:
                raise ModkecError(f"Line {line_number}: python() blocks must be at the top level, outside action/command definitions.")
            if target != "python":
                raise ModkecError(f"Line {line_number}: native Python blocks can only be translated to Python, not {target}.")
            in_python_block = True
            continue

        if line == "end_python()":
            raise ModkecError(f"Line {line_number}: end_python() has no matching python() block.")

        if line == "end()":
            raise ModkecError(f"Line {line_number}: end() has no matching action().")

        if line.startswith("if("):
            match = re.fullmatch(r"if\((.*)\)\s*=\s*([tf])\s*,\s*do\(([A-Za-z_][A-Za-z0-9_]*)\)", line)
            if not match:
                raise ModkecError(f"Line {line_number}: expected if(expression)=t, do(action).")
            expression, expected, action = match.groups()
            condition = _translate_expression(expression, target, line_number)
            if expected == "f":
                condition = f"not ({condition})" if target in ("python", "lua", "luau") else f"!({condition})"
            if target == "python":
                emit(f"if {condition}:")
                indent += 1; emit(f"{action}()"); indent -= 1
            elif target in ("javascript", "c"):
                emit(f"if ({condition}) {{ {action}(); }}")
            else:
                emit(f"if {condition} then {action}() end")
            continue

        parsed = _parse_call(line)
        if parsed is None:
            raise ModkecError(f"Line {line_number}: unsupported statement '{line}'.")
        command, args = parsed
        if command == "translate":
            # Translation is a directive: Studio handles the selected target; omit it from generated code.
            continue
        if command == "import":
            if len(args) != 1:
                raise ModkecError(f"Line {line_number}: import() needs one module name.")
            module = args[0].strip().strip("'\"")
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", module):
                raise ModkecError(f"Line {line_number}: invalid module name '{module}'.")
            # Prototype modules currently have no separate target-language dependency.
            marker = "#" if target == "python" else "--" if target in ("lua", "luau") else "//"
            emit(f"{marker} Modkec module: {module}")
            continue
        if command in ("action", "command"):
            raise ModkecError(f"Line {line_number}: {command} definitions must be on their own line.")
        _translate_statement(line, line_number, target, emit, declared, action_names, result_name)

    if in_action is not None:
        raise ModkecError(f"Action '{in_action}' has no matching end().")
    if in_python_block:
        raise ModkecError("Python block has no matching end_python().")
    if target == "c":
        output.extend(c_globals)
        if c_function_lines:
            output.extend(c_function_lines)
        output.append("int main(void) {")
        output.extend("    " + line for line in c_main_lines)
        output.extend(["    return 0;", "}"])
    return "\n".join(output).rstrip() + "\n"


def _translate_statement(line: str, line_number: int, target: str, emit, declared: set[str], action_names: set[str], result_name: str | None = None) -> None:
    # Conditional action calls may also appear inside action/command bodies.
    if line.startswith("if("):
        match = re.fullmatch(r"if\((.*)\)\s*=\s*([tf])\s*,\s*do\(([A-Za-z_][A-Za-z0-9_]*)\)", line)
        if not match:
            raise ModkecError(f"Line {line_number}: expected if(expression)=t, do(action).")
        expression, expected, action = match.groups()
        condition = _translate_expression(expression, target, line_number)
        if expected == "f":
            condition = f"not ({condition})" if target in ("python", "lua", "luau") else f"!({condition})"
        if target == "python":
            emit(f"if {condition}: {action}()")
        elif target in ("javascript", "c"):
            emit(f"if ({condition}) {{ {action}(); }}")
        else:
            emit(f"if {condition} then {action}() end")
        return

    parsed = _parse_call(line)
    if parsed is None:
        raise ModkecError(f"Line {line_number}: unsupported statement '{line}'.")
    command, args = parsed

    if command == "ask":
        if len(args) > 1:
            raise ModkecError(f"Line {line_number}: ask() accepts at most one prompt.")
        prompt = _translate_value(args[0], target, line_number) if args else ("''" if target == "python" else "\"\"")
        out_name = result_name or "answer"
        if target == "python": emit(f"{out_name} = input({prompt})")
        elif target == "javascript": emit(f"const {out_name} = prompt({prompt});")
        elif target == "c":
            emit(f"char {out_name}[1024];")
            emit(f"printf(\"%s\", {prompt});")
            emit(f"if (fgets({out_name}, sizeof {out_name}, stdin)) {out_name}[strcspn({out_name}, \"\\n\")] = 0;")
        else: emit(f"local {out_name} = io.read()")
        declared.add(out_name)
        return

    if command in {"equal", "greater", "less"}:
        if len(args) != 2:
            raise ModkecError(f"Line {line_number}: {command}() needs two values.")
        left, right = (_translate_value(value, target, line_number) for value in args)
        op = {"equal": "==", "greater": ">", "less": "<"}[command]
        expr = f"({left} {op} {right})"
        out_name = result_name or "result"
        if target == "python": emit(f"{out_name} = {expr}")
        elif target == "javascript": emit(f"const {out_name} = {expr};")
        elif target == "c": emit(f"bool {out_name} = {expr};")
        else: emit(f"local {out_name} = {expr}")
        declared.add(out_name)
        return

    if command in {"and", "or", "not"}:
        if command == "not":
            if len(args) != 1:
                raise ModkecError(f"Line {line_number}: not() needs one value.")
            value = _translate_value(args[0], target, line_number)
            expr = f"(not {value})" if target in ("python", "lua", "luau") else f"(!{value})"
        else:
            if len(args) < 2:
                raise ModkecError(f"Line {line_number}: {command}() needs at least two values.")
            values = [_translate_value(value, target, line_number) for value in args]
            op = ("and" if command == "and" else "or") if target in ("python", "lua", "luau") else ("&&" if command == "and" else "||")
            expr = "(" + f" {op} ".join(values) + ")"
        out_name = result_name or "result"
        if target == "python": emit(f"{out_name} = {expr}")
        elif target == "javascript": emit(f"const {out_name} = {expr};")
        elif target == "c": emit(f"bool {out_name} = {expr};")
        else: emit(f"local {out_name} = {expr}")
        declared.add(out_name)
        return

    if command in action_names:
        values = [_translate_value(value, target, line_number) for value in args]
        call = f"{command}({', '.join(values)})"
        if result_name:
            if target == "python": emit(f"{result_name} = {call}")
            elif target == "javascript": emit(f"const {result_name} = {call};")
            elif target == "c": emit(f"double {result_name} = {call};")
            else: emit(f"local {result_name} = {call}")
        else:
            emit(call + (";" if target in ("javascript", "c") else ""))
        return

    if command == "return":
        if len(args) != 1:
            raise ModkecError(f"Line {line_number}: return() needs one value.")
        value = _translate_expression(args[0], target, line_number)
        emit(f"return {value}" + (";" if target in ("javascript", "c") else ""))
        return

    if command in ("set", "store"):
        if len(args) != 2:
            raise ModkecError(f"Line {line_number}: {command}() needs a name and a value.")
        name = _validate_name(args[0], line_number)
        value = _translate_value(args[1], target, line_number)
        if target == "python":
            emit(f"{name} = {value}")
        elif target == "javascript":
            if name in declared:
                emit(f"{name} = {value};")
            else:
                emit(f"let {name} = {value};")
        elif target == "c":
            if name in declared: emit(f"{name} = {value};")
            else:
                kind, parsed = _parse_value(args[1], line_number)
                ctype = "const char *" if kind == "literal" and isinstance(parsed, str) else "bool" if kind == "bool" else "double"
                emit(f"{ctype} {name} = {value};")
        else:
            if name in declared: emit(f"{name} = {value}")
            else: emit(f"local {name} = {value}")
        declared.add(name)
        return

    if command in ("say", "show"):
        if len(args) != 1:
            raise ModkecError(f"Line {line_number}: show() needs one value.")
        value = _translate_value(args[0], target, line_number)
        if target == "python":
            emit(f"print({value})")
        elif target == "javascript":
            emit(f"console.log({value});")
        elif target == "c":
            kind, parsed = _parse_value(args[0], line_number)
            fmt = "%s\\n" if kind == "literal" and isinstance(parsed, str) else "%g\\n"
            emit(f"printf(\"{fmt}\", {value});")
        else:
            emit(f"print({value})")
        return

    if command == "do":
        if len(args) != 1:
            raise ModkecError(f"Line {line_number}: do() needs one action name.")
        name = _validate_name(args[0], line_number)
        emit(f"{name}();" if target in ("javascript", "c") else f"{name}()")
        return

    if command == "get":
        if len(args) != 1:
            raise ModkecError(f"Line {line_number}: get() needs one variable name.")
        name = _validate_name(args[0], line_number)
        if result_name:
            if target == "python": emit(f"{result_name} = {name}")
            elif target in ("javascript", "c"): emit(f"let {result_name} = {name};" if target == "javascript" else f"double {result_name} = {name};")
            else: emit(f"local {result_name} = {name}")
        elif target == "python": emit(f"print({name})")
        elif target == "javascript": emit(f"console.log({name});")
        elif target == "c": emit(f'printf("%g\\n", (double)({name}));')
        else: emit(f"print({name})")
        return

    if command == "delete":
        if len(args) != 1:
            raise ModkecError(f"Line {line_number}: delete() needs one variable name.")
        name = _validate_name(args[0], line_number)
        if target == "python": emit(f"del {name}")
        elif target == "javascript": emit(f"delete {name};")
        elif target == "c": emit(f"/* C has no dynamic variable deletion: {name} */")
        else: emit(f"{name} = nil")
        return

    if command in {"add", "subtract", "multiply", "divide", "mod", "power", "round", "floor", "ceil", "absolute", "min", "max", "random", "percentage", "sqrt"}:
        arity = 1 if command in {"round", "floor", "ceil", "absolute", "sqrt"} else (2 if command in {"add", "subtract", "multiply", "divide", "mod", "power", "min", "max", "random", "percentage"} else 1)
        if len(args) < arity:
            raise ModkecError(f"Line {line_number}: {command}() has too few arguments.")
        vals = [_translate_value(x, target, line_number) for x in args]
        if command in {"add", "subtract", "multiply", "divide", "mod", "power"}:
            op = {"add":"+", "subtract":"-", "multiply":"*", "divide":"/", "mod":"%", "power": ("^" if target in ("lua", "luau") else "**")}[command]
            expr = f"({vals[0]} {op} {vals[1]})"
        elif command == "min": expr = f"min({', '.join(vals)})" if target == "python" else (f"fmin({', '.join(vals)})" if target == "c" else f"math.min({', '.join(vals)})")
        elif command == "max": expr = f"max({', '.join(vals)})" if target == "python" else (f"fmax({', '.join(vals)})" if target == "c" else f"math.max({', '.join(vals)})")
        elif command == "random": expr = f"random.randint({vals[0]}, {vals[1]})" if target == "python" else (f"Math.floor(Math.random()*({vals[1]}-{vals[0]}+1)+{vals[0]})" if target == "javascript" else f"math.random({vals[0]}, {vals[1]})")
        elif command == "percentage": expr = f"(({vals[0]} / {vals[1]}) * 100)"
        else:
            fn = {"round":"round", "floor":"floor", "ceil":"ceil", "absolute":"abs", "sqrt":"sqrt"}[command]
            if target == "python": expr = f"math.{fn}({vals[0]})" if fn in {"floor", "ceil", "sqrt"} else f"{fn}({vals[0]})"
            elif target == "javascript": expr = f"Math.{ {'absolute':'abs'}.get(command,fn) }({vals[0]})"
            elif target == "c": expr = f"{ {'absolute':'fabs'}.get(command,fn) }({vals[0]})"
            else: expr = f"math.{ {'absolute':'abs'}.get(command,fn) }({vals[0]})"
        out_name = result_name or "result"
        if target == "python": emit(f"{out_name} = {expr}")
        elif target == "javascript": emit(f"let {out_name} = {expr};")
        elif target == "c": emit(f"double {out_name} = {expr};")
        else: emit(f"local {out_name} = {expr}")
        declared.add(out_name)
        return

    if command in {"upper", "lower", "length", "trim", "join", "contains_text", "replace", "split", "number", "format"}:
        if target == "c":
            emit(f"/* Text command requires a Modkec text runtime: {line.strip()} */")
            return
        vals = [_translate_value(x, target, line_number) for x in args]
        if command == "upper": expr = f"{vals[0]}.upper()" if target == "python" else f"string.upper({vals[0]})"
        elif command == "lower": expr = f"{vals[0]}.lower()" if target == "python" else f"string.lower({vals[0]})"
        elif command == "length": expr = f"len({vals[0]})" if target == "python" else (f"{vals[0]}.length" if target == "javascript" else f"#{vals[0]}")
        elif command == "trim": expr = f"{vals[0]}.strip()" if target == "python" else f"{vals[0]}.trim()"
        elif command == "join": expr = " + ".join(vals)
        elif command == "contains_text": expr = f"({vals[1]} in {vals[0]})" if target == "python" else f"({vals[0]}.includes({vals[1]}))"
        elif command == "replace": expr = f"{vals[0]}.replace({vals[1]}, {vals[2]})"
        elif command == "split": expr = f"{vals[0]}.split({vals[1]})"
        elif command == "number": expr = f"float({vals[0]})" if target == "python" else f"Number({vals[0]})"
        else: expr = vals[0]
        out_name = result_name or "result"
        if target == "python": emit(f"{out_name} = {expr}")
        elif target == "javascript": emit(f"let {out_name} = {expr};")
        elif target == "c": emit(f"double {out_name} = {expr};")
        else: emit(f"local {out_name} = {expr}")
        declared.add(out_name)
        return

    if command in {"rect", "square", "circle", "line", "text", "image", "button", "p", "move", "resize", "hide", "remove", "interact", "layer", "opacity", "hex", "rgb", "clear", "animate", "fade", "rotate", "play_sound", "stop_sound", "volume", "play_video", "stop_animation"}:
        comment = f"Visele/media command requires the corresponding runtime: {line.strip()}"
        marker = "# " if target == "python" else "// " if target in ("javascript", "c") else "-- "
        emit(marker + comment)
        return

    raise ModkecError(f"Line {line_number}: command '{command}' is not translatable yet.")



_WEB_BLOCKS = {"html": "end_html()", "style": "end_style()", "script": "end_script()"}


def _parse_web_document(source: str) -> dict[str, str] | None:
    """Read Modkec web-source blocks used to generate a complete web page.

    A web source has title("Page title") and one or more raw blocks:
    html() ... end_html(), style() ... end_style(), script() ... end_script().
    Raw blocks are intentionally passed through because HTML, CSS, and JavaScript
    each have their own syntax; Modkec remains the single source file and chooses
    how those parts are assembled for the requested target.
    """
    lines = source.splitlines()
    has_web_block = any(line.strip() in ("html()", "style()", "script()") for line in lines)
    if not has_web_block:
        return None

    blocks: dict[str, list[str]] = {"html": [], "style": [], "script": []}
    seen: set[str] = set()
    state: str | None = None
    title = "Modkec web project"

    for line_number, original in enumerate(lines, start=1):
        line = original.strip()
        if state is not None:
            if line == _WEB_BLOCKS[state]:
                state = None
            else:
                blocks[state].append(original)
            continue
        if not line or line.startswith("#"):
            continue
        if line in ("html()", "style()", "script()"):
            state = line[:-2]
            if state in seen:
                raise ModkecError(f"Line {line_number}: {state}() block is defined more than once.")
            seen.add(state)
            continue
        parsed = _parse_call(line)
        if parsed and parsed[0] == "title" and len(parsed[1]) == 1:
            try:
                value = ast.literal_eval(parsed[1][0])
            except (ValueError, SyntaxError) as exc:
                raise ModkecError(f"Line {line_number}: title() needs a quoted text value.") from exc
            if not isinstance(value, str):
                raise ModkecError(f"Line {line_number}: title() needs a quoted text value.")
            title = value
            continue
        raise ModkecError(f"Line {line_number}: web source only accepts title() and html/style/script blocks outside a block.")

    if state is not None:
        raise ModkecError(f"The {state}() block is missing {_WEB_BLOCKS[state]}.")
    if "html" not in seen:
        raise ModkecError("Web source needs an html() ... end_html() block.")
    return {"title": title, **{name: "\n".join(content).strip("\n") for name, content in blocks.items()}}


def _js_template_literal(value: str) -> str:
    """Escape text for a JavaScript template literal."""
    return value.replace("\\", "\\\\").replace("`", "\\`").replace("${", r"\${")


def _render_web_html(document: dict[str, str]) -> str:
    import html
    title = html.escape(document["title"], quote=True)
    style = document["style"]
    body = document["html"]
    script = document["script"]
    return (
        "<!doctype html>\n<html lang=\"en\">\n<head>\n"
        "  <meta charset=\"utf-8\">\n"
        "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
        "  <meta name=\"theme-color\" content=\"#100e1b\">\n"
        f"  <title>{title}</title>\n"
        "  <style>\n" + style + "\n  </style>\n"
        "</head>\n<body>\n" + body + "\n"
        "<script>\n" + script + "\n</script>\n"
        "</body>\n</html>\n"
    )


def _render_web_javascript(document: dict[str, str]) -> str:
    import json
    title = json.dumps(document["title"], ensure_ascii=False)
    markup = _js_template_literal(document["html"])
    style = json.dumps(document["style"], ensure_ascii=False)
    script = document["script"]
    return (
        "// Generated by Modkec from a web-source file.\n"
        "// Load this file after the document body exists.\n"
        "(() => {\n"
        f"  document.title = {title};\n"
        "  const modkecStyle = document.createElement('style');\n"
        f"  modkecStyle.textContent = {style};\n"
        "  document.head.appendChild(modkecStyle);\n"
        f"  document.body.innerHTML = `{markup}`;\n"
        "  // Modkec web script block follows.\n"
        "  (() => {\n" + script + "\n  })();\n"
        "})();\n"
    )


def _translate_html(source: str) -> str:
    import html
    # Preserve ordinary program logic by embedding the JavaScript translation
    # and rendering say()/show() output in the generated page.
    if any(re.fullmatch(r"(?:action|command)\(.*\)", line.strip()) or line.strip().startswith("if(") for line in source.splitlines()):
        try:
            script = translate(source, "javascript")
        except ModkecError:
            script = ""
        if script:
            escaped_script = script.replace("</script>", "<\\/script>")
            return (
                "<!doctype html>\n<html lang=\"en\">\n<head>\n"
                "  <meta charset=\"utf-8\">\n"
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
                "  <title>Modkec program</title>\n"
                "  <style>body{font-family:system-ui,sans-serif;margin:2rem;line-height:1.5}"
                "#output{white-space:pre-wrap;background:#f3f4f6;padding:1rem;border-radius:.5rem}</style>\n"
                "</head>\n<body>\n<h1>Modkec program output</h1>\n<pre id=\"output\"></pre>\n"
                "<script>\nconst modkecOutput=document.getElementById('output');\n"
                "console.log=(...values)=>{modkecOutput.textContent += values.map(String).join(' ') + '\\n';};\n"
                + escaped_script + "\n</script>\n</body>\n</html>\n"
            )
    body=[]
    for line_number, original in enumerate(source.splitlines(),1):
        line=original.strip()
        if not line or line.startswith("#"): continue
        if line.startswith("import(") or line.startswith("translate("): continue
        parsed=_parse_call(line)
        if parsed:
            command,args=parsed
            if command in ("say","show") and len(args)==1:
                try: val=ast.literal_eval(args[0])
                except Exception: val=args[0]
                body.append(f"  <p>{html.escape(str(val))}</p>")
            elif command in ("set","store","get","delete","comment","action","end"):
                body.append(f"  <!-- Modkec {html.escape(line)} -->")
            elif command=="text" and args:
                try: label=ast.literal_eval(args[0])
                except Exception: label=args[0]
                x=args[1] if len(args)>1 else "10"; y=args[2] if len(args)>2 else "10"
                body.append(f"  <span style=\"position:absolute;left:{html.escape(x)}px;top:{html.escape(y)}px\">{html.escape(str(label))}</span>")
            elif command=="button" and args:
                try: label=ast.literal_eval(args[0])
                except Exception: label=args[0]
                body.append(f"  <button>{html.escape(str(label))}</button>")
            elif command in ("rect","square") and len(args)>=3:
                x,y,w=args[:3]; h=args[3] if command=="rect" and len(args)>3 else w
                body.append(f"  <div style=\"position:absolute;left:{html.escape(x)}px;top:{html.escape(y)}px;width:{html.escape(w)}px;height:{html.escape(h)}px;border:1px solid black\"></div>")
            elif command=="circle" and len(args)>=3:
                x,y,r=args[:3]; body.append(f"  <div style=\"position:absolute;left:{html.escape(x)}px;top:{html.escape(y)}px;width:{html.escape(str(r))}px;height:{html.escape(str(r))}px;border:1px solid black;border-radius:50%\"></div>")
            else:
                body.append(f"  <!-- HTML output does not yet implement: {html.escape(line)} -->")
        elif line.startswith("if("):
            body.append(f"  <!-- Conditional needs a JavaScript runtime: {html.escape(line)} -->")
        else:
            raise ModkecError(f"Line {line_number}: unsupported HTML translation statement '{line}'.")
    return "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>Modkec export</title>\n</head>\n<body>\n" + "\n".join(body) + "\n</body>\n</html>\n"


def export(source: str, target: str, destination: str | Path) -> Path:
    """Translate source and write the generated code to destination."""
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    if target.lower().strip() == "all":
        import zipfile
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            extensions = {"python":"py", "javascript":"js", "lua":"lua", "luau":"luau", "c":"c", "html":"html"}
            for lang, ext in extensions.items():
                try: content = translate(source, lang)
                except ModkecError as exc: content = f"// Translation unavailable for {lang}: {exc}\n"
                archive.writestr(f"program.{ext}", content)
    else:
        path.write_text(translate(source, target), encoding="utf-8")
    return path
