#!/usr/bin/env python3
"""Run a Modkec source file: python run_modkec.py examples/first_program.modkec"""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.pycache_prefix = str(ROOT / ".pytest_cache" / "pycache")
sys.path.insert(0, str(ROOT))
from modkec import ModkecEngine, ModkecError


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a Modkec program")
    parser.add_argument("file", help="Path to a .modkec source file")
    args = parser.parse_args()
    path = Path(args.file)
    try:
        source = path.read_text(encoding="utf-8")
        engine = ModkecEngine(source_name=str(path.resolve()))
        output = engine.run(source)
        if output:
            print(output)
        print(f"\n[Modkec] Finished. Variables: {engine.variables}")
        if engine.imported_modules:
            print(f"[Modkec] Imported modules: {', '.join(sorted(engine.imported_modules))}")
        return 0
    except (OSError, ModkecError) as exc:
        print(f"[Modkec] Error: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
