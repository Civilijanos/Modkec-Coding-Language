#!/usr/bin/env python3
"""Modkec Studio: a small desktop IDE built with Python's standard Tkinter library."""
from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from pathlib import Path
import sys
import re

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from modkec import ModkecEngine, ModkecError  # noqa: E402
from modkec.translator import LANGUAGES, export, translate  # noqa: E402

STARTER = '''# Modkec — first program
say("Hello from Modkec!")
set(score, 12)
import(logic)

action(win)
    say("You win!")
end()

if(score > 10)=t, do(win)
'''

COMMAND_HELP = {
    "say(value)": "Core: display text or a value. Example: say(\"Hello!\")",
    "ask(prompt) -> name": "Core: ask for input and store it in a variable.",
    "set(name, value) / store(name, value)": "Core: set or store a variable for this run.",
    "get(name) / get(name) -> result": "Core: retrieve a variable, printing it or assigning its value.",
    "delete(name)": "Core: remove a variable.",
    "wait(seconds) / stop()": "Core: pause for a short time or stop the program.",
    "import(module)": "Core: load a module. Modules: visele, calculator, logic, actions, data, text, files, web, media, translation.",
    "run(\"intro\")": "Core: run a defined action or another Modkec script. run() can launch the Visele preview flow.",
    "comment(\"note\")": "Core: explanatory note; does not execute anything.",
    "translate(python)": "Translate the current Modkec script to Python, JavaScript, Lua, Luau, C, HTML, or all targets. Use Studio's target selector for the preview.",
    "if(score > 10)=t, do(win)": "Logic: run an action if the condition is true; use =f for false.",
    "else() do(lose)": "Logic: run an alternative action when the previous condition was false.",
    "repeat(5) do(action)": "Logic: run an action a set number of times.",
    "while(alive) do(action)": "Logic: repeat an action while a condition remains true; has a safety iteration limit.",
    "on(start) do(begin)": "Logic: connect an event name to an action; trigger it with trigger(start).",
    "add(5,10) -> result": "Calculator: arithmetic includes add, subtract, multiply, divide, mod, power, round, floor, ceil, absolute, min, max, random, percentage, sqrt.",
    "p(120) hex(FF0000)": "Visele: draw a pixel and set its color. Also supports rect, square, circle, line, c1-c4, hex, rgb, text, image, button, resize, move, hide, show, remove, interact, clear, layer, opacity.",
    "interact(t) run()": "Visele: enable interaction and open the visual preview. Clickable buttons can trigger an event named click.",
    "list(items) / append(items, value)": "Data: create and manipulate lists. Also supports remove_item, count, contains, sort, reverse, object, key, save, load.",
    "dimp(\"data.json\") -> data": "Files: import data from a file; requires import(files). JSON files are parsed as data.",
    "join(\"Hello \", \"world\") -> result": "Text: join, length, upper, lower, replace, contains_text, split, trim, number, format.",
    "read_file(\"notes.txt\") -> contents": "Files: read/write files, check existence, copy, rename, list directories, and create folders. Use trusted scripts only.",
    "open_url(\"https://example.com\")": "Web: open a URL. request/get_page make network requests; network use should be restricted to trusted scripts.",
    "animate(\"box\", 2)": "Media: initial animation/audio command set includes animate, fade, rotate, play_sound, stop_sound, volume, play_video, stop_animation. Runtime integrations are still early.",
}

class ModkecStudio:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Modkec Studio")
        self.root.geometry("1240x820")
        self.root.minsize(900, 620)
        self.current_path: Path | None = None
        self.dirty = False
        self.show_descriptions = tk.BooleanVar(value=True)
        self.target = tk.StringVar(value="python")
        self.status = tk.StringVar(value="Ready")
        self._configure_theme()
        self._build_menu()
        self._build_ui()
        self._load_starter()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_menu(self) -> None:
        menu = tk.Menu(self.root)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label="New", accelerator="Ctrl+N", command=self.new_file)
        file_menu.add_command(label="Open…", accelerator="Ctrl+O", command=self.open_file)
        file_menu.add_command(label="Save", accelerator="Ctrl+S", command=self.save_file)
        file_menu.add_command(label="Save As…", command=self.save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_close)
        menu.add_cascade(label="File", menu=file_menu)
        run_menu = tk.Menu(menu, tearoff=False)
        run_menu.add_command(label="Run Modkec", accelerator="F5", command=self.run_program)
        run_menu.add_command(label="Translate", command=self.translate_program)
        run_menu.add_command(label="Export…", command=self.export_program)
        menu.add_cascade(label="Program", menu=run_menu)
        settings = tk.Menu(menu, tearoff=False)
        settings.add_checkbutton(label="Show command descriptions", variable=self.show_descriptions, command=self._refresh_help)
        menu.add_cascade(label="Settings", menu=settings)
        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label="Command reference", command=lambda: self._show_bottom_tab("COMMANDS"))
        help_menu.add_command(label="Modkec quick start", command=self.show_tutorial)
        help_menu.add_command(label="About Modkec Studio", command=self.show_about)
        menu.add_cascade(label="Help", menu=help_menu)
        self.root.config(menu=menu)
        self.root.bind("<Control-n>", lambda _e: self.new_file())
        self.root.bind("<Control-o>", lambda _e: self.open_file())
        self.root.bind("<Control-s>", lambda _e: self.save_file())
        self.root.bind("<F5>", lambda _e: self.run_program())

    def _configure_theme(self) -> None:
        """Apply a dark, VS Code-inspired palette using only Tkinter/ttk."""
        self.colors = {
            "window": "#1e1e1e", "panel": "#252526", "toolbar": "#333333",
            "editor": "#1e1e1e", "gutter": "#1e1e1e", "gutter_text": "#858585",
            "text": "#d4d4d4", "muted": "#9da0a6", "border": "#3c3c3c",
            "accent": "#0e639c", "accent_hover": "#1177bb", "green": "#4ec9b0",
            "blue": "#569cd6", "purple": "#c586c0", "yellow": "#dcdcaa",
            "orange": "#ce9178", "comment": "#6a9955", "number": "#b5cea8",
        }
        self.root.configure(background=self.colors["window"])
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TFrame", background=self.colors["window"])
        style.configure("Toolbar.TFrame", background=self.colors["toolbar"])
        style.configure("Sidebar.TFrame", background=self.colors["panel"])
        style.configure("TLabel", background=self.colors["window"], foreground=self.colors["text"], font=("Segoe UI", 10))
        style.configure("Toolbar.TLabel", background=self.colors["toolbar"], foreground=self.colors["text"])
        style.configure("Sidebar.TLabel", background=self.colors["panel"], foreground=self.colors["text"])
        style.configure("TButton", background="#3c3c3c", foreground=self.colors["text"], bordercolor="#555555", padding=(10, 5), font=("Segoe UI", 9))
        style.map("TButton", background=[("active", "#505050"), ("pressed", self.colors["accent"])], foreground=[("disabled", "#777777")])
        style.configure("Accent.TButton", background=self.colors["accent"], foreground="#ffffff", bordercolor=self.colors["accent"], padding=(12, 5), font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", self.colors["accent_hover"]), ("pressed", "#094771")])
        style.configure("TCombobox", fieldbackground="#3c3c3c", background="#3c3c3c", foreground=self.colors["text"], arrowcolor=self.colors["text"], bordercolor=self.colors["border"])
        style.map("TCombobox", fieldbackground=[("readonly", "#3c3c3c")], foreground=[("readonly", self.colors["text"])])
        style.configure("TPanedwindow", background=self.colors["window"])
        style.configure("TSeparator", background=self.colors["border"])
        style.configure("Treeview", background="#252526", fieldbackground="#252526", foreground="#cccccc", borderwidth=0, rowheight=25, font=("Segoe UI", 9))
        style.map("Treeview", background=[("selected", "#094771")], foreground=[("selected", "#ffffff")])
        style.configure("Status.TLabel", background="#007acc", foreground="#ffffff", padding=(9, 4), font=("Segoe UI", 9))
        # Native Tk menus do not use ttk styling, so set their palette explicitly.
        self.root.option_add("*Menu.background", self.colors["panel"])
        self.root.option_add("*Menu.foreground", self.colors["text"])
        self.root.option_add("*Menu.activeBackground", self.colors["accent"])
        self.root.option_add("*Menu.activeForeground", "#ffffff")
        self.root.option_add("*Menu.borderWidth", 0)

    def _build_ui(self) -> None:
        """Build a VS Code-like workbench using Tkinter widgets."""
        # Compact command bar across the top.
        top = tk.Frame(self.root, bg="#323233", height=38)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)
        tk.Label(top, text="◈", bg="#323233", fg="#75beff", font=("Segoe UI", 16, "bold")).pack(side="left", padx=(12, 7))
        tk.Label(top, text="Modkec Studio", bg="#323233", fg="#eeeeee", font=("Segoe UI", 10, "bold")).pack(side="left")
        tk.Label(top, text="  •  Workspace", bg="#323233", fg="#bdbdbd", font=("Segoe UI", 9)).pack(side="left", padx=12)
        ttk.Button(top, text="New", command=self.new_file).pack(side="right", padx=(3, 8), pady=5)
        ttk.Button(top, text="Open", command=self.open_file).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Save", command=self.save_file).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Translate", command=self.translate_program).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Preview", command=self.preview_program).pack(side="right", padx=3, pady=5)
        ttk.Button(top, text="Export", command=self.export_program).pack(side="right", padx=3, pady=5)
        ttk.Label(top, text="Target", style="Toolbar.TLabel").pack(side="right", padx=(8, 3))
        self.target_box = ttk.Combobox(top, textvariable=self.target, values=("python", "javascript", "lua", "luau", "c", "html", "all"), state="readonly", width=10)
        self.target_box.pack(side="right", padx=3, pady=5)

        # Main workbench: activity rail, explorer, and editor/terminal area.
        workbench = tk.Frame(self.root, bg=self.colors["window"])
        workbench.pack(fill="both", expand=True)
        rail = tk.Frame(workbench, bg="#333333", width=48)
        rail.pack(side="left", fill="y")
        rail.pack_propagate(False)
        for glyph, hint in (("▤", "Explorer"), ("⌕", "Search"), ("⑂", "Source Control"), ("▣", "Extensions")):
            b = tk.Label(rail, text=glyph, bg="#333333", fg="#c5c5c5", font=("Segoe UI Symbol", 19), width=2, pady=8, cursor="hand2")
            b.pack(fill="x")
            b.bind("<Enter>", lambda e, w=hint: self.status.set(w))
            b.bind("<Leave>", lambda e: self.status.set("Ready"))
        tk.Frame(rail, bg="#007acc", width=3).place(x=0, y=0, relheight=0.12)
        ttk.Separator(workbench, orient="vertical").pack(side="left", fill="y")

        self.panes = ttk.Panedwindow(workbench, orient="horizontal")
        self.panes.pack(side="left", fill="both", expand=True)
        explorer = tk.Frame(self.panes, bg="#252526", width=225)
        self.panes.add(explorer, weight=0)
        tk.Label(explorer, text="EXPLORER", bg="#252526", fg="#bbbbbb", font=("Segoe UI", 9, "bold"), anchor="w", padx=16, pady=12).pack(fill="x")
        tk.Label(explorer, text="MODKEC PROJECT", bg="#252526", fg="#cccccc", font=("Segoe UI", 9, "bold"), anchor="w", padx=12, pady=6).pack(fill="x")
        tree_frame = tk.Frame(explorer, bg="#252526")
        tree_frame.pack(fill="both", expand=True, padx=(7, 2), pady=(0, 8))
        self.file_tree = ttk.Treeview(tree_frame, show="tree", selectmode="browse")
        self.file_tree.pack(fill="both", expand=True)
        self.file_tree.bind("<Double-1>", self._tree_open_selected)
        self._refresh_explorer()

        center = tk.Frame(self.panes, bg=self.colors["window"])
        self.panes.add(center, weight=5)
        # Editor tab strip.
        self.tab_strip = tk.Frame(center, bg="#252526", height=36)
        self.tab_strip.pack(fill="x")
        self.tab_label = tk.Label(self.tab_strip, text="●  Untitled.modkec", bg="#1e1e1e", fg="#ffffff", font=("Segoe UI", 9), padx=14, pady=9)
        self.tab_label.pack(side="left")
        tk.Frame(self.tab_strip, bg="#007acc", height=2).pack(side="bottom", fill="x")

        self.editor_area = tk.Frame(center, bg=self.colors["editor"])
        self.editor_area.pack(fill="both", expand=True)
        self.line_numbers = tk.Text(self.editor_area, width=4, padx=8, takefocus=0, borderwidth=0, state="disabled", wrap="none", background="#1e1e1e", foreground="#858585", font=("Consolas", 11), selectbackground="#1e1e1e")
        self.line_numbers.pack(side="left", fill="y")
        self.editor = tk.Text(self.editor_area, undo=True, wrap="none", font=("Consolas", 11), padx=10, pady=9, background="#1e1e1e", foreground="#d4d4d4", insertbackground="#ffffff", selectbackground="#264f78", selectforeground="#ffffff", borderwidth=0, highlightthickness=0, spacing1=1, spacing3=1)
        self.editor.pack(side="left", fill="both", expand=True)
        scroll_y = ttk.Scrollbar(self.editor_area, orient="vertical", command=self._scroll_editor)
        scroll_y.pack(side="right", fill="y")
        scroll_x = ttk.Scrollbar(center, orient="horizontal", command=self.editor.xview)
        scroll_x.pack(fill="x")
        self.editor.configure(yscrollcommand=self._sync_scroll, xscrollcommand=scroll_x.set)
        self.editor.bind("<<Modified>>", self._on_modified)
        self.editor.bind("<KeyRelease>", self._on_editor_key_release)
        self.editor.bind("<MouseWheel>", lambda _e: self._update_line_numbers())
        self._configure_syntax_tags()

        # Bottom panel with terminal and command reference as switchable tabs.
        self.bottom_panel = tk.Frame(center, bg="#1e1e1e", height=230)
        self.bottom_panel.pack(fill="both", side="bottom")
        self.bottom_panel.pack_propagate(False)
        panel_header = tk.Frame(self.bottom_panel, bg="#252526", height=32)
        panel_header.pack(fill="x")
        panel_header.pack_propagate(False)
        # Open the command reference by default so new users can discover syntax immediately.
        self.panel_choice = tk.StringVar(value="COMMANDS")
        self.panel_tabs = {}
        for name in ("PROBLEMS", "OUTPUT", "COMMANDS"):
            button = tk.Button(panel_header, text=name, relief="flat", bd=0, bg="#252526", fg="#cccccc", activebackground="#333333", activeforeground="#ffffff", font=("Segoe UI", 8, "bold"), command=lambda n=name: self._show_bottom_tab(n), padx=8, pady=5)
            button.pack(side="left", padx=4)
            self.panel_tabs[name] = button
        ttk.Button(panel_header, text="Run  ▶  F5", style="Accent.TButton", command=self.run_program).pack(side="right", padx=8, pady=3)
        self.panel_body = tk.Frame(self.bottom_panel, bg="#1e1e1e")
        self.panel_body.pack(fill="both", expand=True)
        self.output = tk.Text(self.panel_body, height=7, wrap="word", state="disabled", font=("Consolas", 10), padx=9, pady=7, background="#181818", foreground="#cccccc", insertbackground="#ffffff", selectbackground="#264f78", borderwidth=0, highlightthickness=0)
        self.output.pack(fill="both", expand=True)
        self.help_text = tk.Text(self.panel_body, height=7, wrap="word", state="disabled", font=("Consolas", 9), padx=9, pady=7, background="#181818", foreground="#cccccc", insertbackground="#ffffff", selectbackground="#264f78", borderwidth=0, highlightthickness=0)
        self._refresh_help()
        self._show_bottom_tab("COMMANDS")

        # Status bar resembles VS Code's blue bottom strip.
        statusbar = tk.Frame(self.root, bg="#007acc", height=24)
        statusbar.pack(fill="x", side="bottom")
        statusbar.pack_propagate(False)
        tk.Label(statusbar, textvariable=self.status, bg="#007acc", fg="#ffffff", font=("Segoe UI", 9), anchor="w", padx=8).pack(side="left", fill="y")
        tk.Label(statusbar, text="Modkec  |  UTF-8  |  Spaces: 4", bg="#007acc", fg="#ffffff", font=("Segoe UI", 9), padx=8).pack(side="right", fill="y")

    def _refresh_explorer(self) -> None:
        if not hasattr(self, "file_tree"):
            return
        self.file_tree.delete(*self.file_tree.get_children())
        try:
            examples = ROOT / "examples"
            root_id = self.file_tree.insert("", "end", text="examples", open=True, values=(str(examples),))
            if examples.exists():
                for path in sorted(examples.iterdir()):
                    if path.is_file():
                        self.file_tree.insert(root_id, "end", text=path.name, values=(str(path),))
            for path in sorted(ROOT.glob("*.modkec")):
                self.file_tree.insert("", "end", text=path.name, values=(str(path),))
        except OSError:
            pass

    def _tree_open_selected(self, _event=None) -> None:
        selected = self.file_tree.selection()
        if not selected:
            return
        values = self.file_tree.item(selected[0], "values")
        if values:
            self._open_path(Path(values[0]))

    def _open_path(self, path: Path, confirm: bool = True) -> None:
        if not path.is_file():
            return
        if confirm and not self._confirm_discard():
            return
        try:
            source = path.read_text(encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Open failed", str(exc))
            return
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", source)
        self.current_path = path
        self.dirty = False
        self.editor.edit_modified(False)
        self._set_title()
        self.status.set(f"Opened {path.name}")
        self._highlight_syntax()
        self._update_tab_label()

    def _update_tab_label(self) -> None:
        if hasattr(self, "tab_label"):
            label = self.current_path.name if self.current_path else "Untitled.modkec"
            self.tab_label.configure(text=f"●  {'*' if self.dirty else ''}{label}")

    def _show_bottom_tab(self, name: str) -> None:
        self.panel_choice.set(name)
        for tab_name, button in getattr(self, "panel_tabs", {}).items():
            active = tab_name == name
            button.configure(
                bg="#37373d" if active else "#252526",
                fg="#ffffff" if active else "#cccccc",
                relief="flat",
            )
        for widget in self.panel_body.winfo_children():
            widget.pack_forget()
        if name == "COMMANDS":
            if self.show_descriptions.get():
                self.help_text.pack(fill="both", expand=True)
            else:
                self.help_text.configure(state="normal")
                self.help_text.delete("1.0", "end")
                self.help_text.insert("1.0", "Command descriptions are hidden. Enable them under Settings.")
                self.help_text.configure(state="disabled")
                self.help_text.pack(fill="both", expand=True)
        else:
            self.output.pack(fill="both", expand=True)

    def _configure_syntax_tags(self) -> None:
        palette = self.colors
        self.editor.tag_configure("comment", foreground=palette["comment"], font=("Consolas", 11, "italic"))
        self.editor.tag_configure("string", foreground=palette["orange"])
        self.editor.tag_configure("command", foreground=palette["yellow"])
        self.editor.tag_configure("keyword", foreground=palette["purple"], font=("Consolas", 11, "bold"))
        self.editor.tag_configure("number", foreground=palette["number"])
        self.editor.tag_configure("module", foreground=palette["blue"])

    def _on_editor_key_release(self, _event=None) -> None:
        self._update_line_numbers()
        self._highlight_syntax()

    def _highlight_syntax(self) -> None:
        """Lightweight syntax coloring for Modkec source."""
        if not hasattr(self, "editor"):
            return
        source = self._source()
        for tag in ("comment", "string", "command", "keyword", "number", "module"):
            self.editor.tag_remove(tag, "1.0", "end")
        patterns = (
            ("comment", r"#[^\n]*"),
            ("string", r""""(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'"""),
            ("keyword", r"\b(?:action|end|if|else|do|return|import|t|f)\b"),
            ("module", r"\b(?:visele|logic|actions|calculator|calculations|data|text|files|web|media|translation)\b"),
            ("number", r"(?<![A-Za-z_])\b\d+(?:\.\d+)?\b"),
            ("command", r"\b(?:say|ask|set|store|get|delete|wait|stop|run|comment|translate|export|p|rect|square|circle|line|hex|rgb|text|image|button|resize|move|hide|show|remove|interact|clear|layer|opacity|add|subtract|multiply|divide|mod|power|round|floor|ceil|absolute|min|max|random|percentage|sqrt|repeat|while|on|trigger|cancel|list|append|remove_item|count|contains|sort|reverse|object|key|save|load|dimp|join|length|upper|lower|replace|contains_text|split|trim|number|format|read_file|write_file|file_exists|copy_file|rename_file|list_files|create_folder|open_url|request|get_page|send|listen|timer|animate|fade|rotate|play_sound|stop_sound|volume|play_video|stop_animation)\b"),
        )
        for tag, pattern in patterns:
            for match in re.finditer(pattern, source):
                # Don't color syntax inside comments or quoted strings.
                start, end = match.span()
                if tag not in ("comment", "string") and (self.editor.tag_names()):
                    index = f"1.0+{start}c"
                    existing = self.editor.tag_names(index)
                    if "comment" in existing or "string" in existing:
                        continue
                self.editor.tag_add(tag, f"1.0+{start}c", f"1.0+{end}c")

    def _load_starter(self) -> None:
        self.editor.insert("1.0", STARTER)
        self.editor.edit_modified(False)
        self.dirty = False
        self._update_line_numbers()
        self._highlight_syntax()

    def _scroll_editor(self, *args) -> None:
        self.editor.yview(*args)
        self.line_numbers.yview(*args)

    def _sync_scroll(self, first: str, last: str) -> None:
        self.line_numbers.yview_moveto(first)
        self._update_line_numbers()

    def _update_line_numbers(self) -> None:
        count = int(self.editor.index("end-1c").split(".")[0])
        text = "\n".join(str(i) for i in range(1, count + 1))
        self.line_numbers.configure(state="normal")
        self.line_numbers.delete("1.0", "end")
        self.line_numbers.insert("1.0", text)
        self.line_numbers.configure(state="disabled")

    def _on_modified(self, _event=None) -> None:
        if self.editor.edit_modified():
            self.dirty = True
            self._set_title()
            self.editor.edit_modified(False)
            self._update_line_numbers()

    def _set_title(self) -> None:
        label = self.current_path.name if self.current_path else "Untitled.modkec"
        self.root.title(f"{'*' if self.dirty else ''}{label} — Modkec Studio")
        self._update_tab_label()

    def _source(self) -> str:
        return self.editor.get("1.0", "end-1c")

    def _write_output(self, text: str) -> None:
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text.rstrip() + "\n")
        self.output.configure(state="disabled")

    def _refresh_help(self) -> None:
        self.help_text.configure(state="normal")
        self.help_text.delete("1.0", "end")
        if self.show_descriptions.get():
            for command, description in COMMAND_HELP.items():
                self.help_text.insert("end", command + "\n", "heading")
                self.help_text.insert("end", description + "\n\n")
            self.help_text.tag_configure("heading", font=("Segoe UI", 9, "bold"), foreground=self.colors["green"])
        else:
            self.help_text.insert("1.0", "Command descriptions are hidden. Enable them under Settings to see the reference.")
        self.help_text.configure(state="disabled")

    def _confirm_discard(self) -> bool:
        if not self.dirty:
            return True
        answer = messagebox.askyesnocancel("Unsaved changes", "Save changes before continuing?")
        if answer is None:
            return False
        if answer:
            return self.save_file()
        return True

    def new_file(self) -> None:
        if not self._confirm_discard():
            return
        self.editor.delete("1.0", "end")
        self.current_path = None
        self.dirty = False
        self._set_title()
        self.status.set("New file")

    def open_file(self) -> None:
        if not self._confirm_discard():
            return
        name = filedialog.askopenfilename(title="Open Modkec file", filetypes=(("Modkec files", "*.modkec"), ("Text files", "*.txt"), ("All files", "*")))
        if not name:
            return
        self._open_path(Path(name), confirm=False)

    def save_file(self) -> bool:
        if self.current_path is None:
            return self.save_as()
        try:
            self.current_path.write_text(self._source(), encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc))
            return False
        self.dirty = False
        self._set_title()
        self.status.set(f"Saved {self.current_path.name}")
        return True

    def save_as(self) -> bool:
        name = filedialog.asksaveasfilename(title="Save Modkec file", defaultextension=".modkec", filetypes=(("Modkec files", "*.modkec"), ("All files", "*")))
        if not name:
            return False
        self.current_path = Path(name)
        return self.save_file()

    def _ask_input(self, prompt: str) -> str:
        """Collect ask() input through Tkinter instead of Python's console readline."""
        value = simpledialog.askstring("Modkec Input", prompt, parent=self.root)
        return "" if value is None else value

    def run_program(self) -> None:
        try:
            engine = ModkecEngine(input_fn=self._ask_input)
            result = engine.run(self._source())
            lines = [result] if result else ["Program finished without printed output."]
            lines += ["", f"[Modkec] Finished. Variables: {engine.variables}"]
            if engine.imported_modules:
                lines.append(f"[Modkec] Imported modules: {', '.join(sorted(engine.imported_modules))}")
            self._write_output("\n".join(lines))
            self.status.set("Run completed")
            if engine.visuals:
                self._show_visual_preview(engine)
        except ModkecError as exc:
            self._write_output(f"[Modkec] Error: {exc}")
            self.status.set("Run failed")
        except Exception as exc:
            self._write_output(f"[Modkec] Runtime error: {type(exc).__name__}: {exc}")
            self.status.set("Run failed")

    def preview_program(self) -> None:
        try:
            engine = ModkecEngine()
            engine.run(self._source())
        except ModkecError as exc:
            self._write_output(f"[Modkec] Error: {exc}")
            self.status.set("Preview failed")
            return
        if not engine.visuals:
            messagebox.showinfo("Visele Preview", "No visual elements were created. Add import(visele) and commands such as rect(10,10,100,60) or text(\"Hello\").")
            return
        self._show_visual_preview(engine)

    def _show_visual_preview(self, engine) -> None:
        window = tk.Toplevel(self.root)
        window.title("Visele Preview — Modkec Studio")
        window.geometry("820x560")
        canvas = tk.Canvas(window, width=800, height=500, background="white", highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=8, pady=8)
        for item in sorted(engine.visuals, key=lambda v: v.get("layer", 0)):
            if item.get("hidden"):
                continue
            kind = item.get("kind")
            color = item.get("color", "#000000")
            if kind == "pixel":
                x, y = item.get("x", 0), item.get("y", 0)
                canvas.create_rectangle(x, y, x+1, y+1, fill=color, outline=color)
            elif kind in ("rect", "square"):
                x, y, w, h = item.get("x", 0), item.get("y", 0), item.get("w", 50), item.get("h", 50)
                canvas.create_rectangle(x, y, x+w, y+h, fill=color, outline=color)
            elif kind == "circle":
                x, y, r = item.get("x", 0), item.get("y", 0), item.get("r", 10)
                canvas.create_oval(x-r, y-r, x+r, y+r, fill=color, outline=color)
            elif kind == "line":
                canvas.create_line(item.get("x1",0), item.get("y1",0), item.get("x2",50), item.get("y2",50), fill=color, width=2)
            elif kind == "text":
                canvas.create_text(item.get("x",10), item.get("y",20), text=item.get("text", ""), fill=color, anchor="nw")
            elif kind == "image":
                x,y=item.get("x",10),item.get("y",10)
                canvas.create_rectangle(x,y,x+100,y+60,outline=color)
                canvas.create_text(x+50,y+30,text=f"Image: {item.get('path','')}",fill=color)
            elif kind == "button":
                x,y,w,h=item.get("x",10),item.get("y",10),item.get("w",100),item.get("h",35)
                tag=canvas.create_rectangle(x,y,x+w,y+h,fill="#e8e8e8",outline=color,width=2,tags=("visele_button",))
                text_tag=canvas.create_text(x+w/2,y+h/2,text=item.get("text", "Button"),fill="#111111",tags=("visele_button",))
                if item.get("interactive"):
                    label=item.get("text", "Button")
                    def clicked(_event, label=label):
                        action=engine.events.get("click")
                        if action:
                            try:
                                engine._run_action(action)
                                self._write_output("\n".join(engine.output) or f"Clicked: {label}")
                            except ModkecError as exc:
                                self._write_output(f"[Modkec] Click event error: {exc}")
                        else:
                            self._write_output(f"Clicked: {label} (define on(click) do(action) to handle it)")
                    canvas.tag_bind(tag, "<Button-1>", clicked)
                    canvas.tag_bind(text_tag, "<Button-1>", clicked)
        self.status.set("Visele preview opened")

    def translate_program(self) -> None:
        target = self.target.get()
        try:
            generated = translate(self._source(), target)
            self._write_output(f"[Modkec] Translated to {target}:\n\n{generated}")
            self.status.set(f"Translated to {target}")
        except ModkecError as exc:
            self._write_output(f"[Modkec] Translation error: {exc}")
            self.status.set("Translation failed")

    def export_program(self) -> None:
        target = self.target.get()
        extensions = {"python": ".py", "javascript": ".js", "lua": ".lua", "luau": ".luau", "c": ".c", "html": ".html", "all": ".zip"}
        suggested = (self.current_path.stem if self.current_path else "program") + extensions[target]
        name = filedialog.asksaveasfilename(title=f"Export {target} code", initialfile=suggested, defaultextension=extensions[target], filetypes=((f"{target} files", f"*{extensions[target]}"), ("All files", "*")))
        if not name:
            return
        try:
            path = export(self._source(), target, name)
            self._write_output(f"[Modkec] Exported {target} code to:\n{path}")
            self.status.set(f"Exported {path.name}")
        except (OSError, ModkecError) as exc:
            self._write_output(f"[Modkec] Export error: {exc}")
            self.status.set("Export failed")

    def show_tutorial(self) -> None:
        messagebox.showinfo("Modkec quick start", "1. Write commands in the source editor.\n\n2. Click Run or press F5 to execute the supported Modkec subset.\n\n3. Choose Python, JavaScript, Lua, Luau, C, HTML, or all targets, then click Translate to preview generated code.\n\n4. Click Export to save generated code.\n\nExample:\nstore(score, 0)\nset(score, 12)\nshow(score)\n\nCore commands are available without imports. Module commands require their module, for example import(visele), import(calculator), or import(files). Visele commands can be previewed in Studio. Some advanced web/media features still need runtime integration.")

    def show_about(self) -> None:
        messagebox.showinfo("About Modkec Studio", "Modkec Studio v0.7 development build\nModular Development Kit for Extensible Coding\n\nA beginner-focused editor, interpreter, and code translator prototype. Built with Python and Tkinter; no third-party Python packages are required.")

    def on_close(self) -> None:
        if self._confirm_discard():
            self.root.destroy()


def main() -> None:
    root = tk.Tk()
    ModkecStudio(root)
    root.mainloop()

if __name__ == "__main__":
    main()
