# Modkec Studio v0.6

**Modkec** means **Modular Development Kit for Extensible Coding**. This is an early, runnable prototype built around the original starter command list. It is not yet a production-ready language or a complete implementation of every listed module.

## Run on Linux (default)

Python 3.10+ is recommended. Studio uses Python's built-in Tkinter library; no pip packages are needed.

1. Extract the ZIP.
2. Open a terminal in the extracted `modkec` folder.
3. Run:

```bash
./run_studio.sh
```

If the launcher is not executable, run `sh run_studio.sh` instead. If Tkinter is missing on Debian/Ubuntu/Linux Mint:

```bash
sudo apt install python3-tk
```

You can also start the IDE directly with `python3 studio.py`.

If Tkinter is missing:

```bash
sudo apt install python3-tk
```

Run a source file from the project folder:

```bash
python3 run_modkec.py examples/first_program.modkec
```

Translate a source file to Python, JavaScript, Lua, Luau, C, HTML, or all targets:

```bash
python3 translate_modkec.py examples/first_program.modkec python
python3 translate_modkec.py examples/first_program.modkec javascript
python3 translate_modkec.py examples/first_program.modkec lua
python3 translate_modkec.py examples/first_program.modkec luau
python3 translate_modkec.py examples/first_program.modkec c
python3 translate_modkec.py examples/first_program.modkec html
python3 translate_modkec.py examples/first_program.modkec all
python3 translate_modkec.py examples/first_program.modkec python --export output/first_program.py
python3 translate_modkec.py examples/first_program.modkec all --export output/all-targets.zip
```

## Studio

The v0.6 interface is a more substantial VS Code-inspired workbench: a vertical activity rail, project explorer with example files, editor tab strip, syntax highlighting, line numbers, a bottom panel for output and command reference, a run control, and a blue status bar. It is built with Python and Tkinter and has no third-party package requirements. The same source package runs on Linux and Windows when Python 3 and Tkinter are installed.

- Edit `.modkec` files; New, Open, Save, and Save As are available.
- Run with the Run button or F5.
- Choose Python, JavaScript, Lua, Luau, C, HTML, or all targets, then Translate or Export.
- Command descriptions are visible by default and can be toggled in Settings.
- Run a program that creates Visele elements to open the visual preview, or use the Visele Preview button.

## Core commands (no import required)

- `say("Hello!")` displays a value.
- `ask("Your name?") -> name` asks for input.
- `set(score, 100)` assigns or updates a variable.
- `store(score, 100)` currently behaves like a variable assignment; persistence is not implemented.
- `get(score)` prints a variable; `get(score) -> result` copies it to another variable.
- `delete(score)` removes a variable.
- `wait(2)` pauses for the requested seconds (capped at 30 seconds in this prototype).
- `stop()` ends the current program.
- `import(logic)` loads a module for the current program.
- `run("intro")` runs a named action or a relative script path.
- `comment("Player setup")` is an explanatory note.
- `translate(python)` emits translated code to the output panel. Supported targets are Python, JavaScript, Lua, and Luau. Saving translated code is done through Studio's Export feature or the CLI's `--export` option.

Actions use the original block style:

```text
action(win)
    say("You win!")
end()
if(score > 10)=t, do(win)
```

## Modules and commands

### Visele — `import(visele)`

`p`, `rect`, `square`, `circle`, `line`, `c1`, `c2`, `c3`, `c4`, `hex`, `rgb`, `text`, `image`, `button`, `resize`, `move`, `hide`, `show`, `remove`, `interact`, `clear`, `layer`, `opacity`.

Visele creates visual instructions that Studio can preview. The preview draws pixels, shapes, lines, text, and placeholder image boxes. Button clicks can invoke an action registered as `on(click) do(action_name)` after `interact(t)` enables interaction. Image-file decoding, opacity compositing, and a full event system are not implemented yet. `interact(t) run()` is accepted as the enable-and-preview sequence.

Example: `python3 run_modkec.py examples/visele_demo.modkec` opens a visual preview only when run through Studio; in the CLI, visual commands are recorded without opening a window.

### Calculations — `import(calculator)`

`add`, `subtract`, `multiply`, `divide`, `mod`, `power`, `round`, `floor`, `ceil`, `absolute`, `min`, `max`, `random`, `percentage`, `sqrt`.

Example: `add(5,10) -> result`

### Logic — `import(logic)`

`if`, `else`, `equal`, `greater`, `less`, `and`, `or`, `not`, `repeat`, `while`, `break`, `on`, `wait_until`.

Example: `if(score > 10)=t, do(win)` or `repeat(5) do(action_name)`.

### Actions and functions — `import(actions)`

`action`, `do`, `return`, `input`, `call`, `event`, `trigger`, `cancel`, plus `end()` to close an action block. Actions can be defined with `action(name)` and closed with `end()`.

### Data — `import(data)`

`list`, `append`, `remove_item`, `count`, `contains`, `sort`, `reverse`, `object`, `key`, `save`, `load`.

### Text — `import(text)`

`join`, `length`, `upper`, `lower`, `replace`, `contains_text`, `split`, `trim`, `number`, `format`.

### Files — `import(files)`

`read_file`, `write_file`, `file_exists`, `copy_file`, `rename_file`, `list_files`, `create_folder`, `dimp`. `dimp("data.json") -> data` imports JSON data (or returns raw text if it is not valid JSON) and requires `import(files)`.

**Security:** file and network commands can access resources on the machine or network. Only run scripts you trust. A permission prompt/sandbox system is still a planned improvement.

### Web — `import(web)`

`open_url`, `request`, `get_page`, `send`, `listen`, `timer`. `open_url`, GET/other basic requests, and timed action callbacks have initial implementations; `send` and `listen` need service/event adapters and return a clear error for now.

### Animation and audio — `import(media)`

`animate`, `fade`, `rotate`, `play_sound`, `stop_sound`, `volume`, `play_video`, `stop_animation`. These commands are recorded as media actions; a real media playback/animation runtime is still needed. `import(animation)` is accepted as an alias for `import(media)`.

### Translation tools — `import(translation)`

`check()` performs basic action-block structure checks, and `explain()` lists a short description of each command in the current script. These are early helper functions, not a complete compiler or static analyzer.

## Translation status

The translator supports core commands, actions, simple conditions, arithmetic, and some text operations across Python, JavaScript, Lua, and Luau. C and HTML targets are included for a smaller subset. C action blocks and conditional action calls are not yet supported; HTML output is a static starter page and does not preserve program logic. Some Visele/media operations are emitted as comments noting that a target-language runtime is required. `translate(all)` shows every target and reports unavailable translations per target; exporting all targets creates a ZIP. This is an early transpiler, not a promise of perfect semantic equivalence.

## Examples

- `examples/first_program.modkec` — core commands and a conditional action.
- `examples/visele_demo.modkec` — shapes, colors, text, a button, and interaction preview.
- `examples/calculator_demo.modkec` — arithmetic and result variables.
- `examples/dimp_demo.modkec` — importing a JSON file with `dimp()`.

## Tests

```bash
python3 -m unittest discover -s tests -v
```

## License

MIT. See `LICENSE`.

## Windows setup (optional)

1. Install Python 3 for Windows from <https://www.python.org/downloads/windows/>. During setup, enable **Add python.exe to PATH**. Tkinter is normally included with the standard Python installer.
2. Extract the ZIP file to a normal folder (for example, your Desktop or Downloads folder).
3. Double-click `run_studio.bat` to open Modkec Studio.
4. Open an example from the `examples` folder and click **Run**.

The Windows launchers are `run_studio.bat`, `run_modkec.bat`, and `translate_modkec.bat`. Linux is the default platform for this package; Windows launchers are included for convenience. For example, from Command Prompt in the extracted folder, run:

```bat
run_modkec.bat examples\first_program.modkec
translate_modkec.bat examples\first_program.modkec --target python
```

This is a Windows-compatible source package, not a compiled `.exe`; Python 3 must be installed. The same Modkec prototype limitations listed above still apply.

## Input with `ask()`

In Studio, `ask("Prompt") -> answer` opens a native input dialog instead of reading from the terminal. Plain integer and decimal answers are converted to numbers, so a response such as `7` can be compared with a numeric variable. Other responses remain text. Cancelling the dialog returns an empty string.
