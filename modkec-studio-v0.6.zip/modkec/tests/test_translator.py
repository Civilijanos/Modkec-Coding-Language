import unittest
from modkec.translator import translate
from modkec.engine import ModkecError

class TranslatorTests(unittest.TestCase):
    def test_targets(self):
        source='say("Hello")\nset(score, 12)\nadd(score, 1) -> next_score'
        for target in ('python','javascript','lua','luau'):
            with self.subTest(target=target):
                code=translate(source,target)
                self.assertIn('Hello',code)
                self.assertIn('next_score',code)

    def test_original_condition(self):
        source='action(win)\n say("win")\nend()\nif(score > 10)=t, do(win)'
        self.assertIn('if',translate(source,'python'))


    def test_c_and_html_basic_targets(self):
        source='say("Hello")\nset(score, 12)\nsay(score)'
        self.assertIn('#include <stdio.h>', translate(source, 'c'))
        self.assertIn('<p>Hello</p>', translate(source, 'html'))

    def test_all_targets_returns_sections(self):
        code=translate('say("Hi")', 'all')
        for label in ('PYTHON','JAVASCRIPT','LUA','LUAU','C','HTML'):
            self.assertIn(label, code)

    def test_unknown_target(self):
        with self.assertRaises(ModkecError): translate('say("x")','unknown')

if __name__ == '__main__':
    unittest.main()
