@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 studio.py
    goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
    python studio.py
    goto :end
)
echo Python 3 was not found.
echo Install Python 3 from https://www.python.org/downloads/windows/
echo During installation, enable the option to add Python to PATH.
pause
:end
if not "%errorlevel%"=="0" pause
endlocal
