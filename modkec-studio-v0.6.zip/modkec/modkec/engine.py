"""Modkec starter interpreter. Implements the user's initial command specification."""
from __future__ import annotations
import ast, json, math, operator, random, re, shutil, time, webbrowser
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

class ModkecError(Exception): pass

BINOPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
CMPS = {ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Gt: operator.gt, ast.GtE: operator.ge, ast.Lt: operator.lt, ast.LtE: operator.le}
MODULE_ALIASES = {'calculations':'calculator', 'vis ele':'visele', 'visual':'visele', 'animation':'media'}
MODULE_COMMANDS = {
 'visele': {'p','rect','square','circle','line','c1','c2','c3','c4','hex','rgb','text','image','button','resize','move','hide','show','remove','interact','clear','layer','opacity'},
 'calculator': {'add','subtract','multiply','divide','mod','power','round','floor','ceil','absolute','min','max','random','percentage','sqrt'},
 'logic': {'if','else','equal','greater','less','and','or','not','repeat','while','break','on','wait_until'},
 'actions': {'action','do','return','input','call','event','trigger','cancel','end'},
 'data': {'list','append','remove_item','count','contains','sort','reverse','object','key','save','load'},
 'text': {'join','length','upper','lower','replace','contains_text','split','trim','number','format'},
 'files': {'read_file','write_file','file_exists','copy_file','rename_file','list_files','create_folder','dimp'},
 'web': {'open_url','request','get_page','send','listen','timer'},
 'media': {'animate','fade','rotate','play_sound','stop_sound','volume','play_video','stop_animation'},
 'translation': {'translate','export','check','explain'}
}

def split_args(text: str) -> list[str]:
    out=[]; start=0; depth=0; quote=None; escaped=False
    for i,ch in enumerate(text):
        if quote:
            if escaped: escaped=False
            elif ch=='\\': escaped=True
            elif ch==quote: quote=None
        elif ch in "'\"": quote=ch
        elif ch in '([': depth+=1
        elif ch in ')]': depth-=1
        elif ch==',' and depth==0: out.append(text[start:i].strip()); start=i+1
    tail=text[start:].strip()
    if tail: out.append(tail)
    return out

_split_args = split_args  # Backwards-compatible name used by the translator.

def call_parts(line: str):
    m=re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\((.*)\)',line.strip())
    return (m.group(1),split_args(m.group(2))) if m else (None,[])

def split_commands(line: str) -> list[str]:
    """Split adjacent command calls like `p(120) hex(FF0000)` without splitting quoted text."""
    if re.match(r"^(repeat|while|on|timer)\(.*\)\s+do\(", line.strip()) or re.match(r"^else\(\)\s+do\(", line.strip()): return [line.strip()]
    parts=[]; start=0; depth=0; quote=None; escaped=False; i=0
    while i < len(line)-1:
        ch=line[i]
        if quote:
            if escaped: escaped=False
            elif ch=='\\': escaped=True
            elif ch==quote: quote=None
        elif ch in ("'", '\"'): quote=ch
        elif ch=='(': depth+=1
        elif ch==')':
            depth-=1
            if depth==0 and line[i+1].isspace():
                j=i+1
                while j<len(line) and line[j].isspace(): j+=1
                if re.match(r'[A-Za-z_][A-Za-z0-9_]*\(',line[j:]):
                    parts.append(line[start:i+1].strip()); start=j; i=j; continue
        i+=1
    tail=line[start:].strip()
    if tail: parts.append(tail)
    return parts

COMMAND_DESCRIPTIONS = {
 'say':'display text or values','ask':'request user input','set':'set a value','store':'store a value for this run','get':'retrieve a value','delete':'remove a variable','wait':'pause execution','stop':'stop the program','import':'load a module','run':'run another script or action','comment':'add a note','translate':'translate this script to another language','export':'save translated code from Studio',
 'p':'place a pixel','rect':'draw a rectangle','square':'draw a square','circle':'draw a circle','line':'draw a line','text':'draw text','image':'place an image','button':'create a button','move':'move the last or named element','resize':'resize the last or named element','hide':'hide a visual element','show':'show a visual element or display a value','remove':'remove a visual element','interact':'enable visual interaction','clear':'clear visual elements','layer':'set drawing order','opacity':'set visual opacity','hex':'set a hexadecimal color','rgb':'set an RGB color',
 'add':'add values','subtract':'subtract values','multiply':'multiply values','divide':'divide values','mod':'calculate a remainder','power':'raise a value to a power','round':'round a number','floor':'round down','ceil':'round up','absolute':'calculate absolute value','min':'find the smallest value','max':'find the largest value','random':'generate a random number','percentage':'calculate a percentage','sqrt':'calculate a square root',
 'if':'run an action when a condition matches','else':'run an alternative action','equal':'compare equality','greater':'compare greater-than','less':'compare less-than','and':'combine conditions','or':'combine conditions','not':'reverse a condition','repeat':'repeat an action','while':'repeat while a condition is true','break':'exit a loop','on':'connect an event to an action','wait_until':'wait for a condition',
 'action':'define a reusable action','do':'execute an action','return':'return a result','input':'receive an action value','call':'call an action','event':'define an event','trigger':'trigger an event','cancel':'cancel an action',
 'list':'create a list','append':'add a list item','remove_item':'remove a list item','count':'count items','contains':'check list membership','sort':'sort a list','reverse':'reverse a list','object':'create a data object','key':'retrieve an object key','save':'save data','load':'load saved data','dimp':'import data from a file',
 'join':'combine text','length':'count characters','upper':'uppercase text','lower':'lowercase text','replace':'replace part of text','contains_text':'search text','split':'split text','trim':'trim whitespace','number':'convert text to a number','format':'insert values into text',
 'read_file':'read a file','write_file':'write a file','file_exists':'check whether a file exists','copy_file':'copy a file','rename_file':'rename a file','list_files':'list files in a folder','create_folder':'create a folder','open_url':'open a web address','request':'send a web request','get_page':'retrieve page data','send':'send data to a service','listen':'listen for a message','timer':'schedule a timed action',
 'animate':'animate an element','fade':'fade an element','rotate':'rotate an element','play_sound':'play audio','stop_sound':'stop audio','volume':'set audio volume','play_video':'play a video','stop_animation':'stop an animation','check':'check basic script structure','explain':'describe commands in this script'
}

@dataclass
class ModkecEngine:
    input_fn: Callable[[str],str] = input
    variables: dict[str,Any] = field(default_factory=dict)
    actions: dict[str,list[tuple[int,str]]] = field(default_factory=dict)
    imported_modules: set[str] = field(default_factory=set)
    output: list[str] = field(default_factory=list)
    visuals: list[dict[str,Any]] = field(default_factory=list)
    media_actions: list[dict[str,Any]] = field(default_factory=list)
    events: dict[str,str] = field(default_factory=dict)
    _active_action: str|None = None
    _last_condition: bool|None = None
    _break_loop: bool = False
    _return_value: Any = None
    source_name: str|None = None

    def run(self, source: str) -> str:
        self.output=[]; self.visuals=[]; self.media_actions=[]; self._active_action=None; self._source_text=source
        lines=source.splitlines()
        for number, original in enumerate(lines,1):
            line=original.strip()
            if not line or line.startswith('#'): continue
            if self._active_action is not None:
                if line=='end()': self._active_action=None
                else: self.actions[self._active_action].append((number,line))
                continue
            try: self._execute_line(line,number)
            except _StopProgram: break
            except _BreakLoop as e: raise ModkecError(f'Line {number}: break() can only be used inside repeat() or while().') from e
            except ModkecError as e: raise ModkecError(f'Line {number}: {e}') from e
        if self._active_action: raise ModkecError(f"Action '{self._active_action}' has no matching end().")
        return '\n'.join(self.output)

    def _value(self, raw: str):
        raw=raw.strip()
        if raw in self.variables: return self.variables[raw]
        if raw=='t': return True
        if raw=='f': return False
        if raw in ('nil','null','none'): return None
        try: return ast.literal_eval(raw)
        except (ValueError,SyntaxError): pass
        if re.fullmatch(r'-?\d+(?:\.\d+)?',raw): return float(raw) if '.' in raw else int(raw)
        if any(op in raw for op in ('+', '-', '*', '/', '%', '>', '<', '[', '==')):
            return self._expr(raw)
        if raw.startswith('[') or raw.startswith('{'):
            try: return ast.literal_eval(raw)
            except Exception: pass
        raise ModkecError(f"Unknown value '{raw}'. Use a quoted string, number, t/f, or an existing variable.")

    def _expr(self, raw: str):
        try: tree=ast.parse(raw.strip(),mode='eval')
        except SyntaxError as e: raise ModkecError(f"Couldn't parse expression '{raw}'.") from e
        def visit(n):
            if isinstance(n,ast.Expression): return visit(n.body)
            if isinstance(n,ast.Constant) and isinstance(n.value,(int,float,str,bool)): return n.value
            if isinstance(n,ast.Subscript):
                container=visit(n.value); index=visit(n.slice)
                return container[index]
            if isinstance(n,ast.Name):
                if n.id=='t': return True
                if n.id=='f': return False
                if n.id in self.variables: return self.variables[n.id]
                raise ModkecError(f"Unknown variable '{n.id}'. Set it before using it.")
            if isinstance(n,ast.BinOp) and type(n.op) in BINOPS: return BINOPS[type(n.op)](visit(n.left),visit(n.right))
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.USub,ast.UAdd,ast.Not)):
                v=visit(n.operand); return -v if isinstance(n.op,ast.USub) else (+v if isinstance(n.op,ast.UAdd) else not v)
            if isinstance(n,ast.Compare) and len(n.ops)==1 and type(n.ops[0]) in CMPS: return CMPS[type(n.ops[0])](visit(n.left),visit(n.comparators[0]))
            if isinstance(n,ast.BoolOp):
                vals=[bool(visit(x)) for x in n.values]; return all(vals) if isinstance(n.op,ast.And) else any(vals)
            raise ModkecError('Unsupported expression.')
        try: return visit(tree)
        except (TypeError,ValueError,ZeroDivisionError,OverflowError) as e: raise ModkecError(f'Expression failed: {e}') from e

    def _need(self, module: str, command: str):
        if module not in self.imported_modules: raise ModkecError(f"{command}() requires import({module}).")
    def _name(self, raw):
        n=raw.strip()
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',n): raise ModkecError(f"'{n}' is not a valid variable or action name.")
        return n
    def _result(self, line, value):
        m=re.fullmatch(r'(.*?)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)\s*',line)
        if m: self.variables[m.group(2)]=value; return True
        return False
    def _execute_line(self,line,number):
        chained=split_commands(line)
        if len(chained)>1:
            for command_line in chained: self._execute_line(command_line,number)
            return
        # Result assignment: command(args) -> result
        core=line
        result_name=None
        m=re.fullmatch(r'(.*?)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)\s*',line)
        if m: core=m.group(1).strip(); result_name=m.group(2)
        # Original conditional syntax from the user's design.
        if core.startswith('if('):
            m=re.fullmatch(r'if\((.*)\)\s*=\s*([tf])\s*,\s*do\(([A-Za-z_][A-Za-z0-9_]*)\)',core)
            if not m: raise ModkecError('Use if(score > 10)=t, do(win).')
            condition=self._expr(m.group(1)); expected=m.group(2)=='t'; self._last_condition=bool(condition)==expected
            if self._last_condition: self._run_action(m.group(3))
            return
        # The compact control-flow syntax from the original specification.
        m=re.fullmatch(r'(repeat|while|on|timer)\((.*)\)\s+do\(([A-Za-z_][A-Za-z0-9_]*)\)',core)
        if m:
            control, raw, action = m.groups()
            self._need('web' if control=='timer' else 'logic', control)
            if control=='repeat':
                count=int(self._value(raw))
                for _ in range(max(0,min(count,10000))):
                    try: self._run_action(action)
                    except _BreakLoop: break
                return
            if control=='while':
                iterations=0
                while bool(self._expr(raw)) and iterations<10000:
                    try: self._run_action(action)
                    except _BreakLoop: break
                    iterations+=1
                if iterations>=10000: raise ModkecError('while() stopped after 10,000 iterations to prevent a runaway loop.')
                return
            if control=='on': self.events[raw.strip()]=action; return
            if control=='timer': time.sleep(max(0,min(float(self._value(raw)),30))); self._run_action(action); return
        if core.startswith('else()'):
            m=re.fullmatch(r'else\(\)\s+do\(([A-Za-z_][A-Za-z0-9_]*)\)',core)
            if not m: raise ModkecError('Use else() do(action_name).')
            self._need('logic','else')
            if self._last_condition is False: self._run_action(m.group(1))
            return
        cmd,args=call_parts(core)
        if cmd is None: raise ModkecError(f"Expected a command such as set(score, 10), got '{line}'.")
        # Action declarations are block syntax.
        if cmd=='action':
            if len(args)!=1: raise ModkecError('action() needs one action name.')
            name=self._name(args[0]); self.actions[name]=[]; self._active_action=name; return
        if cmd=='end': raise ModkecError('end() only closes an action definition.')
        # Core commands are always available.
        if cmd in ('set','store'):
            if len(args)!=2: raise ModkecError(f'{cmd}() needs a name and value.')
            name=self._name(args[0])
            try: value=self._value(args[1])
            except ModkecError: value=self._expr(args[1])
            self.variables[name]=value; return
        if cmd=='get':
            if len(args)!=1: raise ModkecError('get() needs one variable name.')
            value=self.variables.get(args[0].strip())
            if args[0].strip() not in self.variables: raise ModkecError(f"Variable '{args[0]}' does not exist.")
            if result_name: self.variables[result_name]=value
            else: self.output.append(str(value))
            return
        if cmd=='delete':
            if len(args)!=1: raise ModkecError('delete() needs one variable name.')
            self.variables.pop(args[0].strip(),None); return
        if cmd in ('say','show'):
            if len(args)!=1: raise ModkecError(f'{cmd}() needs one value.')
            raw=args[0]
            if cmd=='show' and 'visele' in self.imported_modules:
                try: candidate=str(self._value(raw))
                except ModkecError: candidate=raw.strip()
                matched=[v for v in self.visuals if v.get('name')==candidate or v.get('text')==candidate]
                if matched:
                    for v in matched: v['hidden']=False
                    return
            val=self._value(raw); self.output.append(str(val)); return
        if cmd=='ask':
            prompt=str(self._value(args[0])) if args else ''
            val=self.input_fn(prompt+' ')
            # Convert plain numeric answers so ask("Guess?") can be compared
            # directly with numeric variables; leave other answers as text.
            if isinstance(val, str):
                answer=val.strip()
                if re.fullmatch(r'-?(?:0|[1-9]\d*)', answer):
                    try: val=int(answer)
                    except ValueError: pass
                elif re.fullmatch(r'-?(?:0|[1-9]\d*)\.\d+', answer):
                    try: val=float(answer)
                    except ValueError: pass
            self.variables[result_name or 'answer']=val; return
        if cmd=='wait':
            if len(args)!=1: raise ModkecError('wait() needs seconds.')
            time.sleep(max(0,min(float(self._value(args[0])),30))); return
        if cmd=='stop': raise _StopProgram()
        if cmd=='comment': return
        if cmd=='import':
            if len(args)!=1: raise ModkecError('import() needs one module name.')
            module=args[0].strip().strip("'\"").lower()
            module=MODULE_ALIASES.get(module,module.replace(' ','') if module!='vis ele' else 'visele')
            known={'visele','calculator','logic','actions','data','text','files','web','media','translation'}
            if module not in known: raise ModkecError(f"Unknown module '{module}'. Available: {', '.join(sorted(known))}.")
            self.imported_modules.add(module); return
        if cmd=='run':
            if len(args)==0:
                if 'visele' not in self.imported_modules: raise ModkecError('run() without an argument is for running a Visele interaction preview; use run("intro") for an action or script.')
                return
            if len(args)!=1: raise ModkecError('run() needs an action name or script path.')
            name=str(self._value(args[0])) if args[0].startswith(('"',"'")) else args[0].strip()
            if name in self.actions: self._run_action(name)
            else:
                path=Path(name)
                if not path.is_file(): raise ModkecError(f"No action or script named '{name}' was found.")
                nested=ModkecEngine(input_fn=self.input_fn); nested.run(path.read_text(encoding='utf-8'))
                self.output.extend(nested.output); self.variables.update(nested.variables); self.visuals.extend(nested.visuals)
            return
        if cmd=='translate':
            if len(args)!=1: raise ModkecError('translate() needs a target language, such as translate(python).')
            target=args[0].strip().strip("'\"").lower()
            from .translator import translate
            try: generated=translate(self._source_text,target)
            except ModkecError: raise
            self.output.append(generated.rstrip())
            return
        if cmd=='export':
            raise ModkecError("Use translate(language) in Modkec code. Save generated code with Studio Export.")
        # command module lookup
        module=next((mod for mod,commands in MODULE_COMMANDS.items() if cmd in commands),None)
        if module:
            self._need(module,cmd)
            value=self._module_command(module,cmd,args)
            if result_name: self.variables[result_name]=value
            elif value is not _NO_OUTPUT and value is not None: self.output.append(str(value))
            return
        raise ModkecError(f"Unknown command '{cmd}'. Check the command reference or import its module.")

    def _run_action(self,name):
        if name not in self.actions: raise ModkecError(f"Action '{name}' hasn't been defined. Define it with action({name}) ... end().")
        for number,line in self.actions[name]:
            try: self._execute_line(line,number)
            except _ReturnAction as returned: return returned.value
            except _StopProgram: raise

    def _module_command(self,module,cmd,a):
        if module=='visele' and cmd=='hex':
            raw=a[0].strip().strip("'\"#") if a else ''
            if not re.fullmatch(r'[0-9a-fA-F]{6}',raw): raise ModkecError('hex() expects six hexadecimal digits, for example hex(FF0000).')
            color='#'+raw; self.variables['_visele_color']=color
            if self.visuals: self.visuals[-1]['color']=color
            return _NO_OUTPUT
        if module=='data' and cmd in ('list','object'):
            if len(a)!=1: raise ModkecError(f'{cmd}() needs a variable name.')
            name=self._name(a[0]); value=[] if cmd=='list' else {}; self.variables[name]=value; return _NO_OUTPUT
        if module=='actions' and cmd in ('do','call','trigger','cancel','event'):
            if len(a)!=1: raise ModkecError(f'{cmd}() needs one action or event name.')
            name=a[0].strip().strip("'\"")
            if cmd=='do': self._run_action(name); return _NO_OUTPUT
            if cmd=='call': return self._run_action(name)
            if cmd=='trigger': self._run_action(self.events.get(name,name)); return _NO_OUTPUT
            if cmd=='cancel': self.variables['_cancelled_'+name]=True; return _NO_OUTPUT
            return name
        if module=='actions' and cmd=='input':
            if len(a)!=1: raise ModkecError('input() needs one variable name.')
            return self.variables.get(a[0].strip(), '')
        vals=[self._value(x) for x in a]
        if module=='calculator':
            ops={'add':lambda:vals[0]+vals[1],'subtract':lambda:vals[0]-vals[1],'multiply':lambda:vals[0]*vals[1],'divide':lambda:vals[0]/vals[1],'mod':lambda:vals[0]%vals[1],'power':lambda:vals[0]**vals[1],'round':lambda:round(vals[0]),'floor':lambda:math.floor(vals[0]),'ceil':lambda:math.ceil(vals[0]),'absolute':lambda:abs(vals[0]),'min':lambda:min(vals),'max':lambda:max(vals),'random':lambda:random.randint(int(vals[0]),int(vals[1])),'percentage':lambda:vals[0]/vals[1]*100,'sqrt':lambda:math.sqrt(vals[0])}
            try: return ops[cmd]()
            except (IndexError,ZeroDivisionError,ValueError,TypeError) as e: raise ModkecError(f'{cmd}() failed: {e}') from e
        if module=='logic':
            if cmd=='equal': return vals[0]==vals[1]
            if cmd=='greater': return vals[0]>vals[1]
            if cmd=='less': return vals[0]<vals[1]
            if cmd=='and': return all(vals)
            if cmd=='or': return any(vals)
            if cmd=='not': return not vals[0]
            if cmd=='else':
                if self._last_condition is False and len(a)==1: self._run_action(str(a[0]))
                return _NO_OUTPUT
            if cmd=='repeat':
                count=int(vals[0]); action=a[1].strip() if len(a)>1 else ''
                if action.startswith('do('): action=action[3:-1]
                if not action: raise ModkecError('Use repeat(5, do(action_name)).')
                for _ in range(max(0,min(count,10000))): self._run_action(action)
                return _NO_OUTPUT
            if cmd=='while':
                action=a[1].strip() if len(a)>1 else ''
                if action.startswith('do('): action=action[3:-1]
                iterations=0
                while bool(self._expr(a[0])) and iterations<10000:
                    self._run_action(action); iterations+=1
                if iterations>=10000: raise ModkecError('while() stopped after 10,000 iterations to prevent a runaway loop.')
                return _NO_OUTPUT
            if cmd=='break': raise _BreakLoop()
            if cmd=='on':
                m=re.fullmatch(r'on\(([^)]+)\)\s*do\(([^)]+)\)',','.join(a))
                if m: self.events[m.group(1)]=m.group(2); return _NO_OUTPUT
                if len(a)==2: self.events[str(vals[0])]=str(vals[1]); return _NO_OUTPUT
                raise ModkecError('Use on(start, begin) to connect an event to an action.')
            if cmd=='wait_until':
                tries=0
                while not bool(self._expr(a[0])) and tries<300: time.sleep(.1); tries+=1
                if tries>=300: raise ModkecError('wait_until() timed out after 30 seconds.')
                return _NO_OUTPUT
        if module=='actions':
            if cmd in ('do','call','trigger'):
                name=str(vals[0]); name=self.events.get(name,name) if cmd=='trigger' else name
                self._run_action(name); return _NO_OUTPUT
            if cmd=='return': raise _ReturnAction(vals[0] if vals else None)
            if cmd=='input':
                if len(a)!=1: raise ModkecError('input() needs a variable name.')
                return self.variables.get(str(a[0]),'')
            if cmd=='event':
                if len(a)!=1: raise ModkecError('event() needs an event name.')
                return str(vals[0])
            if cmd=='cancel': self.variables['_cancelled_'+str(vals[0])]=True; return _NO_OUTPUT
        if module=='data':
            if cmd=='list': return list(vals)
            if cmd=='append': vals[0].append(vals[1]); return _NO_OUTPUT
            if cmd=='remove_item':
                try: vals[0].remove(vals[1])
                except ValueError: pass
                return _NO_OUTPUT
            if cmd=='count': return len(vals[0])
            if cmd=='contains': return vals[1] in vals[0]
            if cmd=='sort': vals[0].sort(); return _NO_OUTPUT
            if cmd=='reverse': vals[0].reverse(); return _NO_OUTPUT
            if cmd=='object': return {}
            if cmd=='key': return vals[0].get(vals[1]) if isinstance(vals[0],dict) else None
            if cmd=='save':
                self._need('files',cmd); Path(str(vals[0])).write_text(json.dumps(vals[1],indent=2),encoding='utf-8'); return _NO_OUTPUT
            if cmd=='load':
                self._need('files',cmd); return json.loads(Path(str(vals[0])).read_text(encoding='utf-8'))
            if cmd=='dimp':
                self._need('files',cmd); return json.loads(Path(str(vals[0])).read_text(encoding='utf-8'))
        if module=='text':
            if cmd=='join': return ''.join(str(x) for x in vals)
            if cmd=='length': return len(str(vals[0]))
            if cmd=='upper': return str(vals[0]).upper()
            if cmd=='lower': return str(vals[0]).lower()
            if cmd=='replace': return str(vals[0]).replace(str(vals[1]),str(vals[2]))
            if cmd=='contains_text': return str(vals[1]) in str(vals[0])
            if cmd=='split': return str(vals[0]).split(str(vals[1]))
            if cmd=='trim': return str(vals[0]).strip()
            if cmd=='number':
                s=str(vals[0]); return float(s) if '.' in s else int(s)
            if cmd=='format':
                s=str(vals[0])
                for k,v in self.variables.items(): s=s.replace('{'+k+'}',str(v))
                return s
        if module=='files':
            if cmd=='dimp':
                path=Path(str(vals[0])); raw=path.read_text(encoding='utf-8')
                try: return json.loads(raw)
                except json.JSONDecodeError: return raw
            if cmd=='read_file': return Path(str(vals[0])).read_text(encoding='utf-8')
            if cmd=='write_file': Path(str(vals[0])).write_text(str(vals[1]),encoding='utf-8'); return _NO_OUTPUT
            if cmd=='file_exists': return Path(str(vals[0])).is_file()
            if cmd=='copy_file': shutil.copy2(str(vals[0]),str(vals[1])); return _NO_OUTPUT
            if cmd=='rename_file': Path(str(vals[0])).rename(str(vals[1])); return _NO_OUTPUT
            if cmd=='list_files': return [p.name for p in Path(str(vals[0])).iterdir()]
            if cmd=='create_folder': Path(str(vals[0])).mkdir(parents=True,exist_ok=True); return _NO_OUTPUT
        if module=='web':
            if cmd=='open_url': webbrowser.open(str(vals[0])); return _NO_OUTPUT
            if cmd in ('request','get_page'):
                import urllib.request
                if cmd=='request': method,url=str(vals[0]).upper(),str(vals[1])
                else: method,url='GET',str(vals[0])
                req=urllib.request.Request(url,method=method)
                with urllib.request.urlopen(req,timeout=10) as response: return response.read(1_000_000).decode('utf-8','replace')
            if cmd=='send': raise ModkecError('send() needs a service-specific connection adapter; it is not enabled in this starter.')
            if cmd=='listen': raise ModkecError('listen() needs a runtime event source; it is not enabled in this starter.')
            if cmd=='timer':
                seconds=float(vals[0]); action=a[1].strip() if len(a)>1 else ''
                if action.startswith('do('): action=action[3:-1]
                time.sleep(max(0,min(seconds,30))); self._run_action(action); return _NO_OUTPUT
        if module=='visele':
            if cmd=='clear': self.visuals=[]; return _NO_OUTPUT
            if cmd=='rgb':
                color='#%02x%02x%02x'%tuple(max(0,min(255,int(v))) for v in vals[:3]); self.variables['_visele_color']=color
                if self.visuals: self.visuals[-1]['color']=color
                return _NO_OUTPUT
            if cmd in ('c1','c2','c3','c4'): self.variables['_'+cmd]=vals[0]; return _NO_OUTPUT
            if cmd=='p':
                x=int(vals[0]); y=int(vals[1]) if len(vals)>1 else 0
                self.visuals.append(dict(kind='pixel',x=x,y=y,color=self.variables.get('_visele_color','#000000'),layer=0)); return _NO_OUTPUT
            if cmd in ('rect','square','circle','line','text','image','button'):
                kind=cmd; item={'kind':kind,'color':self.variables.get('_visele_color','#000000'),'layer':0,'opacity':100,'hidden':False,'interactive':False}
                if cmd=='rect': item.update(x=int(vals[0]),y=int(vals[1]),w=int(vals[2]),h=int(vals[3]))
                elif cmd=='square': item.update(x=int(vals[0]),y=int(vals[1]),w=int(vals[2]),h=int(vals[2]))
                elif cmd in ('circle',): item.update(x=int(vals[0]),y=int(vals[1]),r=int(vals[2]))
                elif cmd=='line': item.update(x1=int(vals[0]),y1=int(vals[1]),x2=int(vals[2]),y2=int(vals[3]))
                elif cmd=='text': item.update(text=str(vals[0]),x=int(vals[1]) if len(vals)>1 else 10,y=int(vals[2]) if len(vals)>2 else 20)
                elif cmd in ('image','button'): item.update(name=str(vals[0]),path=str(vals[0]),text=str(vals[0]),x=int(vals[1]) if len(vals)>1 else 10,y=int(vals[2]) if len(vals)>2 else 10,w=100,h=35)
                self.visuals.append(item); return _NO_OUTPUT
            if cmd in ('move','resize','hide','show','remove','interact','layer','opacity'):
                # Modify the most recently created item when no element name is supplied.
                target=None; extras=[]
                if cmd in ('move','resize') and len(vals)>=2: extras=vals
                elif cmd in ('hide','show','remove') and vals:
                    target=next((v for v in self.visuals if v.get('name')==str(vals[0]) or v.get('text')==str(vals[0])),None)
                elif vals: extras=vals
                item=target or (self.visuals[-1] if self.visuals else None)
                if cmd=='interact':
                    enabled=bool(vals[0]) if vals else True
                    for v in self.visuals: v['interactive']=enabled
                    return _NO_OUTPUT
                if item is None: raise ModkecError(f'{cmd}() needs an existing visual element.')
                if cmd=='move': item.update(x=int(vals[0]),y=int(vals[1]))
                elif cmd=='resize': item.update(w=int(vals[0]),h=int(vals[1]))
                elif cmd=='hide': item['hidden']=True
                elif cmd=='show': item['hidden']=False
                elif cmd=='remove': self.visuals.remove(item)
                elif cmd=='layer': item['layer']=int(vals[0])
                elif cmd=='opacity': item['opacity']=max(0,min(100,int(vals[0])))
                return _NO_OUTPUT
        if module=='translation':
            if cmd=='check':
                depth=0
                for line_no, raw in enumerate(self._source_text.splitlines(),1):
                    line=raw.strip()
                    if not line or line.startswith('#') or line.startswith('if(') or line.startswith(('repeat(', 'while(', 'on(')): continue
                    if line.startswith('action('): depth+=1
                    elif line=='end()': depth-=1
                    if depth<0: raise ModkecError(f'Line {line_no}: end() has no matching action().')
                if depth: raise ModkecError('An action definition is missing end().')
                return 'Basic structure checks passed. This is not a full static analysis.'
            if cmd=='explain':
                notes=[]
                for raw in self._source_text.splitlines():
                    line=raw.strip()
                    if not line or line.startswith('#'): continue
                    command,_=call_parts(line)
                    if command: notes.append(f'{command}(): {COMMAND_DESCRIPTIONS.get(command, "command or module instruction")}.')
                    elif line.startswith('if('): notes.append('if: checks a condition and may run an action.')
                    else: notes.append(f'{line}: control-flow or combined command.')
                return '\n'.join(notes) if notes else 'The program is empty.'
        if module=='media':
            self.media_actions.append({'command':cmd,'args':vals}); return _NO_OUTPUT
        raise ModkecError(f'{cmd}() is listed but not implemented yet.')

class _StopProgram(Exception): pass
class _BreakLoop(Exception): pass
class _ReturnAction(Exception):
    def __init__(self, value): self.value=value
_NO_OUTPUT=object()
