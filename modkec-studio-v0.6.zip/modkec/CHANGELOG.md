# Changelog

## v0.6 — redesigned workbench and cross-platform package

- Rebuilt the layout with a VS Code-inspired activity rail, project explorer, editor tab strip, bottom output/commands panel, and status bar.
- Added double-click opening of example files from the project explorer.
- Kept the codebase cross-platform: Linux launcher remains the default, and a Windows batch launcher is included.
- Kept the existing language engine, translator, and command behavior unchanged.

## v0.5 — modern Studio interface

- Added a VS Code-inspired dark interface with a blue accent toolbar and status bar.
- Added lightweight syntax coloring for Modkec commands, keywords, modules, strings, comments, and numbers.
- Improved editor typography, line-number gutter, command-reference sidebar, and output panel.


## v0.4.1 — input prompt fix

- Fixed Studio `ask()` calls by collecting input through a native Tkinter dialog instead of Python console readline.
- Numeric answers are automatically converted to integers or decimals, allowing direct comparisons with numeric variables.
- Added a regression test for the Treasure Hunter game flow and improved runtime-error reporting in Studio.


## v0.4 — original starter language implementation

- Replaced the earlier placeholder interpreter with implementations of the original core commands and broad starter module command sets.
- Added Visele drawing instructions and a Studio visual preview for pixels, shapes, lines, text, placeholder images, and buttons.
- Added calculator operations, list/object basics, text helpers, file commands, JSON `dimp()`, event/action support, and basic web requests.
- Added `translate(language)` to the language and expanded translator targets to Python, JavaScript, Lua, Luau, C (basic subset), HTML (static subset), and `all`.
- Added all-target ZIP export, examples, command reference documentation, and automated tests.
- Kept advanced media playback, full module runtime equivalence, and system/network permission prompts as known limitations.
