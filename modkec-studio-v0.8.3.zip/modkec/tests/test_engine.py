import unittest
from pathlib import Path
from modkec.engine import ModkecEngine, ModkecError

ROOT = Path(__file__).resolve().parents[1]

class EngineTests(unittest.TestCase):
    def run_source(self, source, input_value='test'):
        engine = ModkecEngine(input_fn=lambda prompt: input_value)
        output = engine.run(source)
        return engine, output

    def test_core_say_set_get_delete(self):
        engine, output = self.run_source('say("Hi")\nset(score, 100)\nget(score)\ndelete(score)')
        self.assertEqual(output, 'Hi\n100')
        self.assertNotIn('score', engine.variables)

    def test_ask_result_assignment(self):
        engine, _ = self.run_source('ask("Name?") -> name')
        self.assertEqual(engine.variables['name'], 'test')

    def test_action_and_original_condition_syntax(self):
        source = 'set(score, 12)\nimport(logic)\naction(win)\n say("You win!")\nend()\nif(score > 10)=t, do(win)'
        _, output = self.run_source(source)
        self.assertEqual(output, 'You win!')

    def test_calculator(self):
        _, output = self.run_source('import(calculator)\nadd(5,10) -> total\nsay(total)')
        self.assertEqual(output, '15')

    def test_visele_chain_and_preview_instructions(self):
        source = 'import(visele)\np(120) hex(FF0000)\nrect(10,10,100,100)\ninteract(t) run()'
        engine, _ = self.run_source(source)
        self.assertEqual(len(engine.visuals), 2)
        self.assertEqual(engine.visuals[0]['color'], '#FF0000')
        self.assertTrue(all(item.get('interactive') for item in engine.visuals))

    def test_media_animation_commands_create_runtime_tracks(self):
        source = 'import(visele)\nimport(media)\nrect(10,20,40,30)\nanimate("x", 10, 210, 2)\nfade(100, 20, 1)\nrotate(90, 0.5)'
        engine, _ = self.run_source(source)
        self.assertEqual(len(engine.animations), 3)
        self.assertEqual(engine.animations[0]['property'], 'x')
        self.assertEqual(engine.animations[0]['start'], 10.0)
        self.assertEqual(engine.animations[0]['end'], 210.0)
        self.assertEqual(engine.visuals[0]['x'], 10.0)

    def test_animation_can_target_named_text_and_stop(self):
        source = 'import(visele)\nimport(media)\ntext("Title", 5, 5)\nanimate("Title", "y", 5, 50, 1)\nstop_animation("Title")'
        engine, _ = self.run_source(source)
        self.assertEqual(engine.animations, [])

    def test_dimp_json(self):
        source = 'import(files)\ndimp("examples/data.json") -> data\nsay(data["project"])'
        _, output = self.run_source(source)
        self.assertEqual(output, 'Modkec')


    def test_treasure_hunter_guess_actions(self):
        source = """# TREASURE HUNTER
import(logic)
import(actions)
say("=== TREASURE HUNTER ===")
say("Guess the secret number from 1 to 10!")
say("You have 3 chances.")
set(secret, 7)
set(won, 0)
action(win)
    say("YOU WIN! The treasure is yours!")
    set(won, 1)
end()
action(lose)
    say("GAME OVER! The chest stays locked.")
    say("The secret number was 7.")
end()
action(third_guess)
    say("Last chance!")
    ask("Guess 3: " ) -> guess
    if(guess == secret)=t, do(win)
    if(won == 0)=t, do(lose)
end()
action(second_guess)
    say("Not quite! Try again.")
    ask("Guess 2: " ) -> guess
    if(guess == secret)=t, do(win)
    if(won == 0)=t, do(third_guess)
end()
ask("Guess 1: " ) -> guess
if(guess == secret)=t, do(win)
if(won == 0)=t, do(second_guess)
"""
        answers = iter(["2", "4", "7"])
        engine = ModkecEngine(input_fn=lambda _prompt: next(answers))
        output = engine.run(source)
        self.assertIn("YOU WIN! The treasure is yours!", output)
        self.assertEqual(engine.variables["won"], 1)

    def test_parameterized_action_and_return(self):
        source = """import(actions)
action(add_numbers, left, right)
    return(left + right)
end()
call(add_numbers, 20, 22) -> answer
say(answer)
"""
        engine, output = self.run_source(source)
        self.assertEqual(output, '42')
        self.assertNotIn('left', engine.variables)
        self.assertNotIn('right', engine.variables)

    def test_custom_command_definition_and_direct_call(self):
        source = '''command(greet, name)
    say(name)
end()
greet("Modkec")'''
        engine, output = self.run_source(source)
        self.assertEqual(output, 'Modkec')
        self.assertIn('greet', engine.custom_commands)

    def test_custom_command_can_return_value(self):
        source = '''import(actions)
command(double, value)
    return(value * 2)
end()
double(21) -> answer
say(answer)'''
        _, output = self.run_source(source)
        self.assertEqual(output, '42')

    def test_python_block_requires_import(self):
        with self.assertRaisesRegex(ModkecError, r'requires import\(py\)'):
            self.run_source('python()\nprint("hi")\nend_python()')

    def test_import_py_executes_block_and_shares_variables(self):
        source = '''set(start, 4)
import(py)
python()
answer = start * 3
print("python output", answer)
end_python()
say(answer)'''
        engine, output = self.run_source(source)
        self.assertEqual(output, 'python output 12\n12')
        self.assertEqual(engine.variables['answer'], 12)

    def test_python_block_reports_errors(self):
        source = 'import(py)\npython()\nraise ValueError("bad")\nend_python()'
        with self.assertRaisesRegex(ModkecError, 'ValueError: bad'):
            self.run_source(source)

    def test_safe_expression_functions_and_membership(self):
        source = "set(items, [2, 4, 6])\nset(total, sum(items))\nset(size, len(items))\nset(found, 4 in items)\nsay(total)\nsay(size)\nsay(found)"
        _, output = self.run_source(source)
        self.assertEqual(output, '12\n3\nTrue')

    def test_indexed_assignment_and_increment(self):
        source = "set(items, [1, 2, 3])\nset(items[1], 9)\nincrement(score, 2)\nincrement(score, 3)\ndecrement(score)\nsay(items[1])\nsay(score)"
        _, output = self.run_source(source)
        self.assertEqual(output, '9\n4')

    def test_action_argument_count_error(self):
        source = "import(actions)\naction(greet, name)\n    say(name)\nend()\ncall(greet)"
        with self.assertRaisesRegex(ModkecError, 'expects 1 argument'):
            self.run_source(source)

    def test_module_requires_import(self):
        with self.assertRaisesRegex(ModkecError, r'requires import\(calculator\)'):
            self.run_source('add(1,2) -> result')

    def test_repeat_action(self):
        source = 'import(logic)\nset(n, 0)\naction(inc)\n set(n, n + 1)\nend()\nrepeat(3) do(inc)\nsay(n)'
        _, output = self.run_source(source)
        self.assertEqual(output, '3')

    def test_import_alias(self):
        engine, _ = self.run_source('import(vis ele)\nrect(1,2,3,4)')
        self.assertIn('visele', engine.imported_modules)


    def test_event_trigger(self):
        source = 'import(logic)\nimport(actions)\naction(begin)\n    say("started")\nend()\non(start) do(begin)\ntrigger(start)'
        _, output = self.run_source(source)
        self.assertEqual(output, 'started')

    def test_action_return_value(self):
        source = 'import(actions)\naction(calculate)\n    return(42)\nend()\ncall(calculate) -> answer\nsay(answer)'
        _, output = self.run_source(source)
        self.assertEqual(output, '42')

    def test_stop(self):
        _, output = self.run_source('say("before")\nstop()\nsay("after")')
        self.assertEqual(output, 'before')

if __name__ == '__main__':
    unittest.main()
