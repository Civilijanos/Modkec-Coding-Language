## v0.8.3
- Implemented timed Visele preview animations for element position, size, radius, opacity, and rotation.
- Implemented `fade()`, `rotate()`, and target-specific or global `stop_animation()` behavior in the Studio preview.
- Expanded native website building with semantic text, buttons, images, links, theme colors, and custom CSS commands.
- Added tests for animation tracks, stopping animations, and generated native-site components.

# Changelog

## v0.8.2
- Fixed Python translation for `ask()`, `equal()`, `greater()`, `less()`, `and()`, `or()`, and `not()` commands.
- Added translation support for conditional action calls inside action/command bodies.
- Preserved Modkec shared-variable behavior in generated Python functions by emitting global declarations for variables already defined before an action.
- Added regression tests that compile and run a translated calculator, including modulus, invalid-operation, and division-by-zero cases.
- Verified Python export writes syntactically valid Python files.

## v0.8.1
- Added a native Modkec website builder under `import(web)` using semantic `site_*` commands.
- Added standalone HTML generation with generated responsive styling and search interactions; website authors do not write raw HTML/CSS/JavaScript.
- Added `examples/community_hub.modkec` and automated site-builder tests.

## v0.8.0
- Added `command(name, parameters...) ... end()` for user-defined commands that can be called directly.
- Added a Studio menu wizard: Program → Create Custom Command…
- Added opt-in Python blocks using `import(py)`, `python() ... end_python()`.
- Python blocks share variables with Modkec and forward `print()` output to the Studio output.
- Added Python-target passthrough in the translator; non-Python targets reject native Python blocks explicitly.
- Added custom-command and Python interop examples and automated tests.

## v0.7.2
- Added web-source blocks for assembling HTML/CSS/JavaScript into HTML pages or JavaScript bundles.
- Retained the v0.7 language-core improvements.
